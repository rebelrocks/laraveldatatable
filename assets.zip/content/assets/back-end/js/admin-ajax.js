$(document).ready(function (){
	
	//Generate csrf token for ajax request
    /*$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

	//Ajax for update wordlist public status
	$('#wordliststatus').on('click', function () {


	});*/	

});


//Generate csrf token for ajax request
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

//Ajax for update wordlist public status
function updateStatus(elem){

	var status = $(elem).attr("data-status");
	var idval = $(elem).attr("data-id");	
	var id = $(elem).attr("data-val");	
	$.ajax({
        type: "POST",
        url: appURL+"/wordlists/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+idval).html(inactive); 
					$("#atag"+idval).attr("data-status","0");
					$("#atag"+idval).removeClass('btn-success');		
					$("#atag"+idval).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+idval).html(active); 
					$("#atag"+idval).attr("data-status","1");
					$("#atag"+idval).removeClass('btn-danger');		
					$("#atag"+idval).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}

//Ajax for update ad public status
function updateadStatus(elem){
// alert('dfsd');
	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/ads/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}


//Ajax for update page cms public status
function updatecmsStatus(elem){

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/pages/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}

//Ajax for update email template public status
function updateemailtemplateStatus(elem){

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/emailtemplates/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}

//Ajax for update user public status
function updateuserStatus(elem){
	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/users/res_status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}


//Ajax for update email template public status
function updateadlanguageStatus(elem){

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/languages/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}


function updateadDishStatus(elem){
	// alert('dsf');

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/dishes/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });

}

function updateadDealStatus(elem){
	// alert();

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/deals/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}


function updateproviderStatus(elem){

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/providerdeals/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}


function updateReStatus(elem){

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/res_status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}


function updateProviderStatus(elem){

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/res_provider_status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}

function updateRestaturantTypeStatus(elem){

	var status = $(elem).attr("data-status");
	var id = $(elem).attr("data-id");	
	$.ajax({
        type: "POST",
        url: appURL+"/restauranttypes/status/"+id,
        data: {id:id,status:status},
        success: function(data){
            if(data.success!=''){
            	if(status == 1){	
					$("#atag"+id).html(inactive); 
					$("#atag"+id).attr("data-status","0");
					$("#atag"+id).removeClass('btn-success');		
					$("#atag"+id).addClass('btn-danger');						
				}

				if(status == 0){
					$("#atag"+id).html(active); 
					$("#atag"+id).attr("data-status","1");
					$("#atag"+id).removeClass('btn-danger');		
					$("#atag"+id).addClass('btn-success');
				}
			}else if(data.error!=''){
				alert(data.error);
			}
        }
    });
}
