$(document).ready(function (){

	//Date time JS Start
	$(".datepicker").datetimepicker({
        format: "LT",
        locale: 'fr',
        icons: {
            time: "fa fa-clock-o",
            date: "fa fa-calendar",
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down",
            previous: "fa fa-chevron-left",
            next: "fa fa-chevron-right",
            today: "fa fa-screenshot",
            clear: "fa fa-trash",
            close: "fa fa-remove"
        }
    });
    //Date time JS End

    //Test Email Section Hide & Show JS Start
    $('input[type=checkbox]').change(function() {
        if($(this).attr('id') == 'testEmail'){
            if($(this).prop('checked')){
                $('#testEmail').val('1');
                $('#test_email').css('display','block');
                $('#send_test_email').css('display','block');
                
                $('#searchInput').removeAttr('required');
                $('#min_age').removeAttr('required');
                $('#max_age').removeAttr('required');
            }else{
                $('#testEmail').val('0');
                $('#test_email').css('display','none');                        
                $('#send_test_email').css('display','none');                        
                $('#searchInput').attr('required');
                $('#max_age').attr('required');
            }
        }else if($(this).attr('id') == 'testEventEmail'){
            if($(this).prop('checked')){
                $('#testEventEmail').val('1');
                $('#test_event_email').css('display','block');
            }else{
                $('#testEventEmail').val('0');
                $('#test_event_email').css('display','none');
            }
        }
    });
    //Test Email Section Hide & Show JS End

    //Generate csrf token for ajax request
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#rad').on('change keyup', function() {
		var sanitized = $(this).val().replace(/[^0-9]/g, '');
		$(this).val(sanitized);
	});	
	
	//User Count for sending Newsletter JS Start
    var checkteck = 0;

    $('#address').focusout(function(e) {
		$("#userCount").hide();
		$("#spingif").show();
		setTimeout(function(){
			var lat = jQuery('#latitude').val();
			var lng = jQuery('#longitude').val();
			var rad = jQuery('#rad').val();
			var minAge = jQuery('#min_age').val();
			var maxAge = jQuery('#max_age').val();
			
			$.ajax({
				type: 'POST', 
				data: {lat:lat,lng:lng,rad:rad,minAge:minAge,maxAge:maxAge},
				url: ajax_user_count,
				success: function(response){
					$("#spingif").hide();
					$("#userCount").show();
					$("#userCount").html(response);
				}
			});

		},1000);
    });

   	$('#rad, #min_age, #max_age').unbind('keyup input paste').bind('keyup input paste',function(e){	
		
		if(checkteck == 1){
			checkteck = 0;
			return false;
		}
		checkteck = 1;
		
		if($('#testEmail').val() == 0){
			
			if($("#address").val() == ''){
				alert("please select an address");
                return false;
			}
			
			$("#userCount").hide();
			$("#spingif").show();

			setTimeout(function(){
				var lat = jQuery('#latitude').val();
				var lng = jQuery('#longitude').val();
				var rad = jQuery('#rad').val();
				var minAge = jQuery('#min_age').val();
				var maxAge = jQuery('#max_age').val();
				$.ajax({
					type: 'POST', 
					data: {lat:lat,lng:lng,rad:rad,minAge:minAge,maxAge:maxAge},
					url: ajax_user_count,
					success: function(response){
						$("#spingif").hide();
						$("#userCount").show();
						$("#userCount").html(response);
					}
				});
			},1000);
		}
	});
 	//User Count for sending Newsletter JS End
    
});


	//Sending newsletter JS Start
	var timer;
	
	function sendMsg(){
		//SendMsg();
		$('#savebtn').attr('disabled','disabled');
		return false;
	}
	
	$(document).ready(function (){

		$('.sendtestEmailIDID').on('click', function () {

			//var $subject = $(".tab-pane.active input:text.subject").val();
			//var $subject = $(".tab-pane.active .subject").val();
			var $thisbutton = $(this).data('id');
			var $subject = $(".tab-pane.active input:text.subject").val();
			var testemaillanguage = $(".tab-pane.active .testemaillanguage").val();
			//var emailcontent = 'content_'+testemaillanguage;
			//var content_English = 'content_'+testemaillanguage;
			//var myContent = CKEDITOR.instances.content_English.getData();
			//alert(myContent);
			alert($subject);
		});

		/*$("#savebtn").on('click', function () {

			var pageNo = $('#pageNo').val();
			var content = $('#content').val();
			var latitude = $('#latitude').val();
			var longitude = $('#longitude').val();
			var rad = $('#rad').val();
			var subject = $('#subject').val();
			var testEmail = $('#testEmail').val();
			var notificationemail = $('#notificationemail').val();	

			var w_monday = $('#monday').val();
			var w_tuesday = $('#tuesday').val();
			var w_wednesday = $('#wednesday').val();
			var w_thursday = $('#thursday').val();
			var w_friday = $('#friday').val();
			var w_saturday = $('#saturday').val();
			var w_sunday = $('#sunday').val();
			
			var minAge = $('#min_age').val();
			var maxAge = $('#max_age').val();

			var address = $("#address").val();
			
			if($('#testEmail').val() == 0){
				if(minAge != '' && maxAge == ''){
					alert("Max Age is required!");
					return false;
				}else if(minAge == '' && maxAge != ''){
					alert("Min Age is required!");
					return false;
				}else if(minAge != '' && maxAge != '' && parseInt(minAge) > parseInt(maxAge)){
					alert("Min Age is not greater then Max Age.");
					return false;
				}
			
				if(address == null || address == '')		
				{
					alert("User not found for specific address test test");
					return false;
				}
				
				if(w_monday == '' && w_tuesday == '' && w_wednesday == '' && w_thursday == '' && w_friday == '' && w_saturday == '' && w_sunday == ''){
					alert("Please select anyone of them");
					return false;
				}
			
			}

			if(subject == null || subject == ''){
				alert("Please provide subject.");
	            return false;
			}
			
			if(content == null || content  == ''){
				alert("Please provide description.");
	            return false;
			}

			if(testEmail == 1 && notificationemail == ''){

				alert("Please provide email.");
	            return false;	
			}

			//Serialize form data
			var newslettersForm = $("#newslettersForm").serialize();
			$.ajax({

				url: ajax_send_newsletter,
				type: "post",
				data: newslettersForm,
				success: function (respData) {
					
					var obj = JSON.parse(respData);
					console.log(obj);
					
					if(obj.totalPage == pageNo){
						timer = window.setInterval(completed, 1000, obj.notif_id);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					console.log(textStatus, errorThrown);
				}
			});
		});*/
	});

	//Sending newsletter JS End

	

	