<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notificationtext extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'notificationtexts';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];


    /**
     * Get the languagecode.
     * @return \Illuminate\Database\Eloquent\Realtions\belongsTo
     */
    public function languagecode()
    {
        return $this->belongsTo('App\Models\Languagecode', 'language')->withDefault([
                'name' => '-',
                'code' => '-'
            ]);
    }
}
