<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Newsnotification extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];
}
