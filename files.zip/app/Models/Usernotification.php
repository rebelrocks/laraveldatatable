<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Usernotification extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'user_notifications';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];
	
	public function getUserImages(){
		return $this->hasMany(UserImage::class, 'user_id', 'form_user_id');
	}
}
