<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];
	
	public function usermeta(){
		return $this->hasMany(User::class, 'user_id');
    }
	
	public function user_image(){
		return $this->hasMany('App\UserImage');
    }

}
