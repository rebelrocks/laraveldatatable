<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Contactenquiry extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'contact_enquiries';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['object', 'message'];
}
