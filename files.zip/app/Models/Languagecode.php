<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Languagecode extends Model
{
	/**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'languagecodes';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];

    
    /**
     * Get the languagecode record associated with the language code.
     */
    public function languageword($word_id)
    {
        return $this->hasOne('App\Models\Wordlist', 'languagecode_id')->where('word_id', $word_id);
    }

}
