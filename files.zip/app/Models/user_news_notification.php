<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class user_news_notification extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'user_news_notifications';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];
}
