<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wordlist extends Model
{
    /**
     * Get the language code.
     *
     * @return \Illuminate\Database\Eloquent\Realtions\belongsTo
     */
    public function languagecode()
    {
        return $this->belongsTo('App\Models\Languagecode', 'languagecode_id')->withDefault([
                'name' => '-',
                'code' => '-'
            ]);
    }

    /**
     * Get the languagecode record associated with the language code.
     */
    public function getwordDetail()
    {
        return $this->hasOne('App\Models\Wordlist', 'word_id');
    }
}
