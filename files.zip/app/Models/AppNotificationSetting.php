<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppNotificationSetting extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    public $timestamps = false;
    
    protected $table = 'app_notification_settings';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];
}
