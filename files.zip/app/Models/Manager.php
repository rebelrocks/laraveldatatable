<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manager extends Model
{    
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'managers';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];

    /**
     * Get the languagecode record associated with the language code.
     */
    public function sitepermission()
    {
        return $this->hasOne('App\Models\Site_permission', 'manager_id');
    }
    
}
