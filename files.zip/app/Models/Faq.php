<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'faq';
    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];
	
	public function getLanguage()
    {
        return $this->belongsTo('App\Models\Languagecode', 'languagecode_id')->withDefault();
    }
}
