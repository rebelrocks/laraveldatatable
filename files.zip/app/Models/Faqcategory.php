<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Traits\LanguagecodeTrait;

class Faqcategory extends Model
{
    use LanguagecodeTrait;

	const CREATED_AT = 'created';
    const UPDATED_AT = 'modified';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'faq_categories';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];


    /**
     * Get the parent category.
     */
    public function parentcategory()
    {
        return $this->belongsTo('App\Models\Faqcategory', 'category_id');
    }


    /**
     * Get the category deatail.
     */
    public function categorydetail()
    {
        return $this->belongsTo('App\Models\Faqcategory', 'parent_id', 'languagecode_id');
    }


    /**
     * Get the language code.
     *
     * @return \Illuminate\Database\Eloquent\Realtions\belongsTo
     */
    public function languagecode()
    {
        return $this->belongsTo('App\Models\Languagecode', 'languagecode_id')->withDefault([
                'name' => '-',
                'code' => '-'
            ]);
    }


    public function subcategories()
    {
        //return $this->hasMany('App\Models\Faqcategory', 'category_id')->where('category_id', 1)->where('languagecode_id', 2);
        $languagecode_id = $this->defaultlanguageId();
        
        return $this->hasMany(Faqcategory::class)->where('languagecode_id', $languagecode_id);
    }


    public function categories()
    {
        $languagecode_id = $this->defaultlanguageId();
        
        return $this->hasMany(Faqcategory::class)->where('languagecode_id', $languagecode_id);
    }


    public function childrenCategories()
    {
        $languagecode_id = $this->defaultlanguageId();

        return $this->hasMany(Faqcategory::class)->where('languagecode_id', $languagecode_id)->with('categories');
    }

}
