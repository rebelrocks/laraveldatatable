<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

use App\Traits\LanguagecodeTrait;

class ChecklanguageCode implements Rule
{
    use LanguagecodeTrait;

    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        return array_key_exists($value, $this->codelists());
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return trans('messages.The selected language code does not exist');
    }
}
