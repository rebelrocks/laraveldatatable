<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\User;
use Helper;

class ResetPassword extends Notification
{
    use Queueable;

    public $user;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        
        $get_email_template  = Helper::resetpasswordEmailtemplate($this->user->id);

        $app_name = Helper::getapplicationName();

        $subject =  str_replace('##SITE_NAME##', $app_name, Helper::getforgotpasswordsubject()->subject);

        //$subject = sprintf('%s: You\'ve got a new message from %s!', config('app.name'), $this->fromUser->name);
        //$greeting = sprintf('Hello %s!', $notifiable->name);

        $from_email = Helper::getforgotpasswordsubject()->from_email;

        return (new MailMessage)
                ->markdown('mail.password.resetpassword')
                ->from($from_email)
                ->subject($subject);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
