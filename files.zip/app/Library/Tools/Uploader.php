<?php

namespace App\Library\Tools;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Image;
use Helper;

/**
*
* Uploader
*
* @author Snapey
* @category Media
* @link 
* @copyright 2020
*
*/
class Uploader
{
	
	/**
	 * Upload single file
	 */
	public static function uploadsinglefile($file, $uplode_image_path)
	{

		$salt_image  = time().rand(1111, 9999);

        $image_name = $salt_image.'.'.$file->getClientOriginalExtension();

        // open an image file
        $get_image_size = getimagesize($file->getRealPath());
        $width = $get_image_size[0];
        $height = $get_image_size[1];
        $canvas = Image::canvas($width, $height);
        $thumb_image = Image::make($file->getRealPath())->resize($width, $canvas, function($constraint){
            $constraint->aspectRatio();
        });

        $canvas->insert($thumb_image, 'fit');
        // now you are able to resize the instance
        $thumb_image->save($uplode_image_path.'/'.$image_name, 80);

        return $image_name;
	}
	
}