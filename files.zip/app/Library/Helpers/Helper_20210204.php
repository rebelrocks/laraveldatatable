<?php

// This class file to define all general functions
namespace App\Library\Helpers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\URL;
use Carbon\Carbon;
use App\User;
use App\Models\Setting;
use App\Models\Emailtemplate;
use App\Models\Sociallink;
use App\Models\Site_permission;
use App\Models\Wordlist;
use App\Models\Notificationtext;
use App\Models\Page;
use App\Models\Ad;

/**
* Helper Class
*/
class Helper
{

    /************ Make Database date readable ************/
    public static function date_ago($date)
    {
        return Carbon::createFromFormat('Y-m-d H:i:s', $date)->diffForHumans();
    }

    /*********** Date format IN d/m/Y ***************/
    public static function dateformatDmy($date)
    {
        return Carbon::parse($date)->format('d/m/Y');
    }

    /*********** Date format IN d/m/Y ***************/
    public static function date_string($date)
    {
        return Carbon::parse($date)->format('d/m/Y');
    }

    /*********** Date format ***************/
    public static function dateFormat($date)
    {
        return Carbon::parse($date)->format('M-d-Y');
    }

    /*********** Date format ***************/
    public static function timeFormat($time)
    {
        return Carbon::parse($time)->format('h:i:s A');
    }

    /*********** Month Date format ***************/
    public static function dateFormatMonth($date)
    {
        return Carbon::parse($date)->format('M');
    }

    /*********** Date format ***************/
    public static function dateformatDate($date)
    {
        return Carbon::parse($date)->format('d');
    }


    /*********** Week format ***************/
    public static function weekFormat($date)
    {
        return Carbon::parse($date)->format('l');
    }

    /*********** Time format ***************/
    public static function formatTime($time)
    {
        return Carbon::parse($time)->format('H:i');
    }

    /**
     * String Date
     */
    public static function dateToFormatted($date)
    {
        return Carbon::parse($date)->toFormattedDateString(); 
    }


    /*********** Created date format ***************/
    public static function createdformatDate($date)
    {
        return Carbon::parse($date)->format('H:i');
    }


    /**
    * Get application name
    * @return string
    */
    public static function getapplicationName()
    {
        $get_app_name = Helper::siteSettings();

        return $get_app_name['site.name'] ?? 'Demo App';
    }


     /**
    * Get application site url
    * @return string
    */
    public static function applicationsiteURl()
    {
        $url = Setting::where('name', 'site.url')->first(['name', 'value']);

        return $url->value ?? '';
    }



    /**
     * reset password Email template.
     *
     * @param  Request  $request
     * @param  string  $email
     * @return Response
     */
    public static function resetpasswordEmailtemplate($user='')
    {
        
    }



    public static function forgetpasswordemailtemplate()
    {
        
    }



    /**
     * reset password Email detail.
     *
     * @return Response
     */
    public static function getforgotpasswordsubject()
    {
        return Emailtemplate::where('title', 'forgot_password')->first();
    }



    /**
     * Check site permissions
     * @return true or false
     */
    public static function checkPermission($role_id, $manager, $permission)
    {
        $permission_count = DB::table('managers')
                           ->join('site_permissions', 'site_permissions.manager_id', '=', 'managers.id')
                           ->where('site_permissions.role_id', $role_id)
                           ->where('managers.name', $manager)
                           ->where('site_permissions.'.$permission, 1)
                           ->count();

        if($permission_count)                                   
        
            return true;
        

            return false;
    }

    /**
     * Get word detail
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */ 
    public static function getwordDetail($word_id, $languagecode_id)
    {
        return Wordlist::where('wordlist_id', $word_id)
                ->where('languagecode_id', $languagecode_id)
                ->first();
    }

    /**
     * Get template detail
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */ 
    public static function gettemplateDetail($slug, $languagecode_id)
    {
        return Emailtemplate::where('slug', $slug)->where('languagecode_id', $languagecode_id)->first();
    }

    /**
     * Get notification text detail
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */ 
    public static function notificationtextDetail($parent_id, $languagecode_id)
    {
        return Notificationtext::where('notificationtext_id', $parent_id)->where('language', $languagecode_id)->first();
    }

    /**
     * Get cmd page detail
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */ 
    public static function cmspageDetail($parent_id, $languagecode_id)
    {
        return Page::where('page_id', $parent_id)->where('languagecode_id', $languagecode_id)->first();
    }


    /**
     * Get site setting detail
     *
     * @return \Illuminate\Http\Response
     */
    public static function siteSettings()
    {
        $names = [];
        $values = [];
        
        $settings = Setting::all(['name','value'])->toArray();
        
        foreach($settings as $thing)
        {
            $names[] = $thing['name'];
            $values[] = $thing['value'];
        }
        
        return array_combine($names, $values);
    }     
	
	/**
     * Get ads detail
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */ 
    public static function adsDetail($ad_id, $languagecode_id)
    {
        return Ad::where('ad_id', $ad_id)
                ->where('languagecode_id', $languagecode_id)
                ->first();
    }

    public static function blankIfNull($value)
    {
        if ($value == null || $value == "NULL" || $value == NULL ) 
        {
                $value = '';
        }
        return  $value;
    }
	
	// Convert a date or timestamp into French.
	public static function dateToFrench($date, $format) 
	{
		$english_days = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
		$french_days = array('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche');
		$english_months = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
		$french_months = array('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre');
		return str_replace($english_months, $french_months, str_replace($english_days, $french_days, date($format, strtotime($date) ) ) );
	}
	
	public static function colourBrightness($hex, $percent)
	{
		// Work out if hash given
		$hash = '';
		if (stristr($hex, '#')) {
			$hex = str_replace('#', '', $hex);
			$hash = '#';
		}
		/// HEX TO RGB
		$rgb = [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
		//// CALCULATE
		for ($i = 0; $i < 3; $i++) {
			// See if brighter or darker
			if ($percent > 0) {
				// Lighter
				$rgb[$i] = round($rgb[$i] * $percent) + round(255 * (1 - $percent));
			} else {
				// Darker
				$positivePercent = $percent - ($percent * 2);
				$rgb[$i] = round($rgb[$i] * (1 - $positivePercent)); // round($rgb[$i] * (1-$positivePercent));
			}
			// In case rounding up causes us to go to 256
			if ($rgb[$i] > 255) {
				$rgb[$i] = 255;
			}
		}
		//// RBG to Hex
		$hex = '';
		for ($i = 0; $i < 3; $i++) {
			// Convert the decimal digit to hex
			$hexDigit = dechex($rgb[$i]);
			// Add a leading zero if necessary
			if (strlen($hexDigit) == 1) {
				$hexDigit = "0" . $hexDigit;
			}
			// Append to the hex string
			$hex .= $hexDigit;
		}
		return $hash . $hex;
	}
}
