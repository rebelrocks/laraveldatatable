<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use \Mailjet\Resources;
use Aws\Ses\SesClient;
use Aws\Exception\AwsException;
use Helper;
use App\Models\Emailtemplate;
use App\Models\Sociallink;
use App\Traits\Sociallink\SociallinkTrait;
use App\User;

class MailgetController extends Controller
{
   use SociallinkTrait;

    public function index()
    {

    	$emailtemplate  = Emailtemplate::where('id', 1)->first();

        $image_path = url('application/public/uploads/emailtemplates');

        $header_image = $image_path.'/'.$emailtemplate->header_image;

        //Get user detail 
        $getuser = User::where('id', 283)->first();
       	$first_name  = $getuser->first_name ?? '';
       	
       	$email  = $getuser->email ?? '';

       	$reset_link_url = url(config('app.url').route('password.reset', ['token' => $this->token(), 'email' => $email], false));

       	//replace template var with value
        $token = array(
            '##MAIN_COLOR##'  => '#'.$emailtemplate->main_color,
            '##HEADER_IMAGE##' => $header_image,
            '##FIRST_NAME##' => ucwords($first_name),
            '##SUPPORT_EMAIL##' => $emailtemplate->from_email,
            '##SITE_NAME##' => Helper::getapplicationName(),
            '##SECONDARY_COLOR##' => '#'.$emailtemplate->secondary_color,
            '##CONTACT_EMAIL##' => $emailtemplate->reply_to_email,
            '##YEAR##' => date('Y'),
            '##FB_LINK##' => $this->fbpage(),
            '##TWITTER_LINK##' => $this->twitterpage(),
            '##INSTA_LINK##' => $this->instagrampage(),
            '##WEBSITE##' => $this->websitepageurl(),
            '##LINKEDIN_LINK##' => $this->linkedinpageurl(),
            '##PWD_LINK##' => $reset_link_url,
        );

        $pattern = '[%s]';

        foreach($token as $key=>$val)
        {
            $varMap[sprintf($key)] = $val;
        }
        
        $emailContent = strtr($emailtemplate['description'],$varMap);
		
		$ses_client = SesClient::factory(array(
				'version'=> 'latest',
				'region' => 'eu-west-2',
				'credentials' => array(
					'key' => 'AKIAVS3LDQGOHYIIDP6F',
					'secret'  => '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'
				) 
			));
		
		$subject =  $emailtemplate->subject;
		$sender_name = 'B2Cvertical';
		$from_mail = 'noreply@55.agency';
		$FromAddresses = "$sender_name <$from_mail>";
		try {
			$result = $ses_client->sendEmail([
			'Source'=>$FromAddresses,
			'Destination' => ['ToAddresses' => [$email,],],
			'Message' => ['Body' => ['Html' => ['Charset' => 'UTF-8','Data' => $emailContent,],
						'Text' => ['Charset' => 'UTF-8','Data' => "",],],
				'Subject' => ['Charset' => 'UTF-8','Data' => $subject,],],
			]);
			
		} catch (\Exception $e) {
			echo $e->getMessage();exit;
		}
					
    	try {
    		

			$app_name = Helper::getapplicationName();
        	$subject =  str_replace('##SITE_NAME##', $app_name, Helper::getforgotpasswordsubject()->subject);
				
	    	$mj = new \Mailjet\Client(getenv('MJ_APIKEY_PUBLIC'), getenv('MJ_APIKEY_PRIVATE'));
			
			$body = [
			    'FromEmail' => "noreply@55.agency",
			    'FromName' => "B2Cvertical",
			    'Subject' => $subject,
			    'Text-part' => "",
			    'Html-part' => $emailContent,
			    'Recipients' => [
			        [
			            'Email' => request('email')
			        ]
			    ]
			];

			$response = $mj->post(Resources::$Email, ['body' => $body]);
			
			//$response->success() && var_dump($response->getData());

			return view('welcome');

		} catch (\Exception $e) {
    		

    	}	

		
    }




    /** 
     * Get user by email
     * @return \Illuminate\Http\Response
     */
    private function getuserdetailbyEmail($email)
    {
    	return User::where('email', $email)->first(['id', 'email', 'first_name', 'last_name']);
    }



    /**
     * Generate ramdom token number
     * @return \Illuminate\Http\Response
     */
    private function token()
    {
    	return Str::random(60);
    }


}
