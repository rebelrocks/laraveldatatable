<?php

namespace App\Http\Controllers\Admin\Settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\File;
use App\Traits\UploadTrait;
use App\Traits\GeneralsettingTrait;
use App\User;
use App\Models\Setting;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;

class SettingsController extends Controller
{

    use checkermissionsTrait, UploadTrait, GeneralsettingTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'settings', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $settings = Setting::where('status', true)->orderBy('sort', 'asc')->get();

        return view('admin.settings.settings', compact('settings'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'settings', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //check login background image exit or not
        $getimage = $this->siteSettings();

        $login_background_required = $getimage['site.login_background'] ? 'nullable' : 'required';
        
        $request->validate([
            'name.*' => 'required',
            'files.*' => 'nullable|image|mimes:jpeg,jpg,png,gif|max:2048',

        ],[
            'name.*' => trans('messages.This field is required'),
        ]);
        
        $settings = request('name');

        $loginbackground = $request->file('loginbackground');

        if(is_array($settings)){

            //Update setting
            foreach ($settings as $key => $value)
            {
                Setting::where('id', $key)->update(['value' => $value]);
            }

            //Update files
            $files = $request->file('files');

            $images_id = request('images_id');

            if($request->hasFile('files')){

                foreach ($request->file('files') as $fileKey => $fileObject ){
                    
                    $img_id = $images_id[$fileKey] ?? '';

                    if(!empty($img_id))
                    {
                        // make sure each file is valid
                        if ($fileObject->isValid()) {

                            $get_image_detail = Setting::find($img_id);

                            $uplode_image_path = public_path('uploads/settings');

                            //Unlik file
                            if(!empty($get_image_detail->value) && File::exists($uplode_image_path.'/'.$get_image_detail->value))
                            {
                                unlink($uplode_image_path.'/'.$get_image_detail->value);
                            }

                            //Upload new file
                            $photo  = $files[$fileKey];

                            $get_image =  $this->uploadOne($photo, $uplode_image_path);
                            
                            Setting::where('id', $img_id)->update(['value' => $get_image]);
                        }
                    }  
                }
            }


        }
        
        return back()->with('success', trans('messages.your_setting_has_been_updated'));

    }



    public function changeEnv($data = array()){
        
        if(count($data) > 0){

            // Read .env-file
            $env = file_get_contents(base_path() . '/.env');

            // Split string on every " " and write into array
            $env = preg_split('/\s+/', $env);;

            // Loop through given data
            foreach((array)$data as $key => $value){

                // Loop through .env-data
                foreach($env as $env_key => $env_value){

                    // Turn the value into an array and stop after the first split
                    // So it's not possible to split e.g. the App-Key by accident
                    $entry = explode("=", $env_value, 2);

                    // Check, if new key fits the actual .env-key
                    if($entry[0] == $key){
                        // If yes, overwrite it with the new one
                        $env[$env_key] = $key . "=" . $value;
                    } else {
                        // If not, keep the old one
                        $env[$env_key] = $env_value;
                    }
                }
            }

            // Turn the array back to an String
            $env = implode("\n", $env);

            // And overwrite the .env with the new data
            file_put_contents(base_path() . '/.env', $env);

            return true;

        } else {
            return false;
        }
    }
}
