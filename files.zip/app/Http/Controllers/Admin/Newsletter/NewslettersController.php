<?php

namespace App\Http\Controllers\Admin\Newsletter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use \Mailjet\Resources;
use Carbon\Carbon;
use App\Models\Emailtemplate;
use App\Models\Sociallink;
use App\Traits\Sociallink\SociallinkTrait;
use App\Traits\GeneralsettingTrait;
use App\Traits\Newsletter\NewsletterTrait;
use App\Traits\checkermissionsTrait;
use App\Traits\Mailjet\MailjetTrait;
use App\Models\Newsnotification;
use App\Models\Newsletterhistory;
use App\Models\user_news_notification;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Helper;
use App\User;

class NewslettersController extends Controller
{
    use SociallinkTrait, GeneralsettingTrait, NewsletterTrait, MailjetTrait, checkermissionsTrait, LanguagecodeTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $defaultlanguage = $this->getdefaultlanguage();
        $newsletters = Newsnotification::where('languagecode_id', $defaultlanguage->id)
                        ->latest()
                        ->paginate(20);
        return view('admin.newsletters.newsletters', compact('newsletters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecodes = $this->languagecodes();

        return view('admin.newsletters.create', compact('languagecodes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        
        $request->validate([
            'address' => 'required|string|max:255',
            'subject.*' => 'nullable|required_if:local.*,1|string|max:255',
            'min_age' => 'required|numeric',
            'max_age' => 'required|numeric',
            'rad' => 'required|numeric',
            'content.*' => 'nullable|required_if:local.*,1|string',
        ],[
            'subject.*.required_if' => trans('messages.This field is required'),
            'content.*.required_if' => trans('messages.This field is required'),
        ]);

        $pageNo = request('pageNo') ? : 1;
        $testEmail = request('testEmail');
        $testEmailstatus = request('testEmailstatus');
        $address = request('address');
        $lat = request('latitude');
        $lng = request('longitude');
        $subject = request('subject');
        $minAge = request('min_age');
        $maxAge = request('max_age');
        $rad = request('rad');
        $testEmail_ = request('testEmail_status');
        $notificationemail = request('notificationemail');
        $content = request('content');
        $monday = request('monday');
        $tuesday = request('tuesday');
        $wednesday = request('wednesday');
        $thursday = request('thursday');
        $friday = request('friday');
        $saturday = request('saturday');
        $sunday = request('sunday');


        //Get support email
        $support_email_id = $this->getsupportEmail()->value ?? '';
        //Get contact email
        $contact_email_id = $this->getcontactEmail()->value ?? '';
        //Get sender email
        $senderemail = $this->getsenderEmail()->value ?? '';
        //Get application name
        $appname = Helper::getapplicationName();

        $having = '';
    
        if(!empty($minAge) && !empty($maxAge)){
            $having = " AND age >= $minAge AND age <= $maxAge";
        }

        $users = DB::select("SELECT *,YEAR(CURDATE()) - YEAR(dob) AS age, (3959 * acos(cos( radians('$lat')) * cos( radians( `latitude` ) ) * cos( radians( `longitude` ) - radians( '$lng' )) + sin(radians('$lat')) * sin(radians(`latitude`)))) as distance FROM users where users.status=1 AND users.is_unsubscribe_news = 0 AND id NOT IN (1,2,3) Having `distance` < $rad $having");

        $pageno = $pageNo;

        $languagecode = request('languagecode');

        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);
        $default_subject = '';
        $default_description = '';
        $newsnotification_id = '';

        foreach ($languagecode as $key => $value) {

            //Check if title is empty
            if(empty($subject[$key])){
                $default_subject = $subject[$lang_name];
            }
            
            //Check if description is empty
            if(empty($content[$key])){
                $default_description = $content[$lang_name];
            }

            $n_title = isset($subject[$key]) ? $subject[$key] : $default_subject;
            $n_description = isset($content[$key]) ? $content[$key] : $default_description;

            if(!empty($n_title) && !empty($n_description) && !empty($value)){

                //Save newsletter detail 
                $create = Newsnotification::create([
                    'languagecode_id' => $value,
                    'address' => $address,
                    'latitude' => $lat,
                    'longitude' => $lng,
                    'title' => $n_title,
                    'description' => $n_description,
                    'monday' => $monday,
                    'tuesday' => $tuesday,
                    'wednesday' => $wednesday,
                    'thursday' => $thursday,
                    'friday' => $friday,
                    'saturday' => $saturday,
                    'sunday' => $sunday,        
                ]);

                //Get Parent ID
                $parent_id = $request->session()->get('parent_id');

                if(empty($request->session()->get('parent_id'))){

                    // Via a request instance...
                    $parent_id =  $request->session()->put('parent_id', $create->id);

                }

                //Check parent ID value
                if(empty($parent_id)){
                    $parent_id = $create->id;   
                }
                
                //Update parent ID
                Newsnotification::where('id', $create->id)->update([
                    'newsnotification_id' => $parent_id
                ]);

                $newsnotification_id = $create->id; //Get last insert ID
            }

        }

        $notidata = DB::select("SELECT *, (3959 * acos(cos( radians('$lat')) * cos( radians( `latitude` ) ) * cos( radians( `longitude` ) - radians( '$lng' )) + sin(radians('$lat')) * sin(radians(`latitude`)))) as distance FROM users where users.status=1 AND users.is_unsubscribe_news = 0 AND id NOT IN (1,2,3) Having `distance` < $rad");
        
        if(count($notidata))
        {

            if(!empty($monday) || !empty($tuesday) || !empty($wednesday) || !empty($thursday) || !empty($friday) || !empty($saturday) || !empty($sunday)){
                
                foreach($notidata as $user)
                {

                    //Save user news notification detail
                    $user_news_notification = user_news_notification::create([
                        'user_id' => $user->id,
                        'newsnotification_id' => $newsnotification_id,
                    ]);

                }

            }else{

                foreach($notidata as $user)
                {

                    $to = $user->email;

                    //Save user news notification detail
                    $user_news_notification = user_news_notification::create([
                        'user_id' => $user->id,
                        'newsnotification_id' => $newsnotification_id,
                    ]);

                    try {

                            if(config('app.email_send')==true){
                                //Send email
                                //$this->mailjetEmail($senderemail, $appname, $subject, $content, $to);
                            }

                        /*$newsletterhistory = Newsletterhistory::create([
                            'user_id' => $user->id,
                            'newsnotification_id' => $newsnotification_id,
                            'address' => $address,
                            'lat' => $lat,
                            'lng' => $lng,
                            'subject' => $subject,
                            'radius' => $rad,
                            'msg' => $content,
                            'email_template' => $content,
                            'monday' => $monday,
                            'tuesday' => $tuesday,
                            'wednesday' => $wednesday,
                            'thursday' => $thursday,
                            'friday' => $friday,
                            'saturday' => $saturday,
                            'sunday' => $sunday,
                            'status' => 1,
                        ]);*/

                    } catch (\Exception $e) {

                        /*$newsletterhistory = Newsletterhistory::create([
                            'user_id' => $user->id,
                            'newsnotification_id' => $newsnotification_id,
                            'address' => $address,
                            'lat' => $lat,
                            'lng' => $lng,
                            'subject' => $subject,
                            'radius' => $rad,
                            'msg' => $content,
                            'email_template' => $content,
                            'monday' => $monday,
                            'tuesday' => $tuesday,
                            'wednesday' => $wednesday,
                            'thursday' => $thursday,
                            'friday' => $friday,
                            'saturday' => $saturday,
                            'sunday' => $sunday,
                            'status' => 0,
                        ]);*/
                        
                    }
                }
            }         
        }
        
        // Forget session value...
        $request->session()->forget('parent_id');

        return redirect()->back()->with('success', trans('messages.newsletter_send_successfully'));
    }

    /**
     * Display the newshistory.
     *
     * @return \Illuminate\Http\Response
     */
    public function newshistory()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $defaultlanguage = $this->getdefaultlanguage();
        $newsletterhistories = Newsnotification::where('languagecode_id', $defaultlanguage->id)
                                ->latest()
                                ->paginate(20);
        return view('admin.newsletters.newsletterhistory', compact('newsletterhistories'));
    }

    /**
     * Display the newsletter user list.
     *
     * @return \Illuminate\Http\Response
     */
    public function userlist($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $newsletterhistories = Newsletterhistory::where('newsnotification_id', $id)->latest()->paginate(20);
        return view('admin.newsletters.userlist', compact('newsletterhistories'));
    }

    /**
     * Display the view news status.
     *
     * @return \Illuminate\Http\Response
     */
    public function viewnewsstatus($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $percentage = 0;
        $total = 0;
        $totalSend = 0;
        $totalFail = 0;

        $total = Newsletterhistory::where('newsnotification_id', $id)->count();
        
        $totalSend = Newsletterhistory::where('newsnotification_id', $id)->where('status', 1)->count();
        
        $totalFail = Newsletterhistory::where('newsnotification_id', $id)->where('status', 0)->count();
            
        if($total > 0){
            $percentage = ($totalSend/$total)*100;
        }

        return view('admin.newsletters.view', compact('percentage', 'total', 'totalSend', 'totalFail'));
    }

    /**
     * Send newsletter email cron.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function sendnewsletterEmail()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Get support email
        $support_email_id = $this->getsupportEmail()->value ?? '';
        //Get contact email
        $contact_email_id = $this->getcontactEmail()->value ?? '';
        //Get sender email
        $senderemail = $this->getsenderEmail()->value ?? '';

        
        //Get week day name
        $getweekDay = strtolower(Carbon::now()->format( 'l' ));
        
        //Get current time
        $getcurrentTime = Carbon::now()->format('H:i');

        //Get app name
        $appname = Helper::getapplicationName();

        //Get newsletter subscriber user list
        $users = user_news_notification::all();
        
        foreach ($users as $user) 
        {

            $useremail = User::find($user->user_id);

            if(!empty($useremail->email))
            {
                $newsdetail = Newsnotification::where('id', $user->newsnotification_id)
                            ->where($getweekDay, '!=', NULL)
                            ->first(['id', 'address', 'latitude', 'longitude', 'title', 'description', $getweekDay, 'created_at', 'updated_at']);

                if(!empty($newsdetail)){

                    //Convert data in array format
                    $getcrondetail = $newsdetail->toArray();
                    
                    $cron_time = '';

                    if(!empty($getcrondetail[$getweekDay])){

                        $cron_time = $getcrondetail[$getweekDay];
                    }

                    if(!empty($cron_time) && $cron_time==$getcurrentTime){
                        
                        try {
                            if(config('app.email_send')==true){
                                //Send email
                                //$this->mailjetEmail($senderemail, $appname, $newsdetail->title, $newsdetail->description, $useremail->email);
                            }
                            //Add newsleter history when mail send successfully.
                            $this->createnewsletterHistory($useremail->id, $newsdetail->id, $newsdetail->address, $newsdetail->latitude, $newsdetail->longitude, $newsdetail->title, $newsdetail->description, $newsdetail->monday, $newsdetail->tuesday, $newsdetail->wednesday, $newsdetail->thursday,  $newsdetail->friday, $newsdetail->saturday, $newsdetail->sunday, 1);
                            
                        } catch (\Exception $e) {

                            //Add newsleter history when email send faild.
                            $this->createnewsletterHistory($useremail->id, $newsdetail->id, $newsdetail->address, $newsdetail->latitude, $newsdetail->longitude, $newsdetail->title, $newsdetail->description, $newsdetail->monday, $newsdetail->tuesday, $newsdetail->wednesday, $newsdetail->thursday,  $newsdetail->friday, $newsdetail->saturday, $newsdetail->sunday, 0);
                        }    
                    }                    
                }                
            }
        }

        return redirect(route('create_newsletter'))->with('success', trans('messages.email_sent_successfully'));
    }


    /**
     * Send test newsletter email.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sendtestnewsletterEmail(Request $request)
    {
        if($request->ajax()){

            //Get support email
            $support_email_id = $this->getsupportEmail()->value ?? '';
            //Get contact email
            $contact_email_id = $this->getcontactEmail()->value ?? '';
            //Get sender email
            $senderemail = $this->getsenderEmail()->value ?? '';

            $subject = request('subject');

            $emailtemplate = request('desc');

            $email = request('notificationemail');

            //Get app name
            $appname = Helper::getapplicationName();

            if(config('app.email_send')==true){
                //Send email
               $response = $this->mailjetEmail($senderemail, $appname, $subject, $emailtemplate, $email);
            }

            return response()->json(['success' => 'Test email sended successfully.', 'apiresponse' => $response->getData()]);
        }

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'newsletters', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
    }

    /**
     * User Count for sending Newsletter.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function usercount(Request $request)
    {
        $lat = request('lat');
        $lng = request('lng');
        $rad = request('rad');
        $minAge = request('minAge');
        $maxAge = request('maxAge');

        if($lat == '' || $lng == ''){
            echo 0;
            exit;
        }

        if(empty($rad) && $rad <= 0){
            echo 0;
            exit;
        }

        $having = '';
        
        if(!empty($minAge) && !empty($maxAge)){
            $having = " AND age >= $minAge AND age <= $maxAge";
        }

        $candidates = DB::select("SELECT *,YEAR(CURDATE()) - YEAR(dob) AS age, (3959 * acos(cos( radians('$lat')) * cos( radians( `latitude` ) ) * cos( radians( `longitude` ) - radians( '$lng' )) + sin(radians('$lat')) * sin(radians(`latitude`)))) as distance FROM users where users.status=1 AND users.is_unsubscribe_news = 0 AND id NOT IN (1,2) Having `distance` < $rad $having");
        
        return count($candidates);
    }


    //Generate notification history
    private function createnewsletterHistory($user_id, $newsnotification_id, $address, $latitude, $longitude, $subject, $msg, $monday, $tuesday, $wednesday, $thursday, $friday, $saturday, $sunday, $status)
    {


       Newsletterhistory::create([
            'user_id' => $user_id,
            'newsnotification_id' => $newsnotification_id,
            'address' => $address,
            'lat' => $latitude,
            'lng' => $longitude,
            'subject' => $subject,
            'msg' => $msg,
            'email_template' => $msg,
            'monday' => $monday,
            'tuesday' => $tuesday,
            'wednesday' => $wednesday,
            'thursday' => $thursday,
            'friday' => $friday,
            'saturday' => $saturday,
            'sunday' => $sunday,
            'status' => $status,
        ]);

       return 'success';

    }

}
