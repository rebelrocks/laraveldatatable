<?php

namespace App\Http\Controllers\Admin\Faqcategory;

use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Models\Faqcategory;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Traits\checkermissionsTrait;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Session;
use App\Traits\Faqcategory\FaqcategoryTrait;

class FaqcategoriesController extends Controller
{
    use checkermissionsTrait, LanguagecodeTrait, FaqcategoryTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function index($id=null)
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'faqcategories', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }


        //Get default language code ID
        $default_lng_id = $this->defaultlanguageId();
        //Get default category ID List
        $defaultcatID =  $this->defaultcatID();
        //Get parent category ID For child category
        $parentcatID = '';

        if(!empty($id))
        {
            if(!is_numeric($id))
            {
                return redirect(route('faqcategories'));    
            }
            
            //Get category detail for default language
            // $categorybylang = $this->faqcategorybyLanguage($id, $default_lng_id);
            //Count category for default language
            $countfaqcategories = Faqcategory::where('category_id', $id)
                                ->whereLanguagecode_id($default_lng_id)
                                ->count();

            //Check category if not found
            if(!$countfaqcategories)
            {
                $id = $categorybylang->parent_id ?? '';
            }

            //Faqcategory id if empty redirect main category Page
            if(!$id)
            {
                return redirect(route('faqcategories'));
            }

            //Get the child category List
            $faqcategories = Faqcategory::where('category_id', $id)
                        ->whereLanguagecode_id($default_lng_id)
                        ->orderBy('short_order', 'asc')
                        ->paginate(20);

            //Parent category detail
            $parent_category = Faqcategory::where('id', $id)->where('category_id', '!=', false)->first(['id', 'parent_id', 'category_id']);
            $parentcatID = $parent_category->category_id ?? '';

        }
        else
        {
            $faqcategories = Faqcategory::whereLanguagecode_id($default_lng_id)
                        ->orderBy('short_order', 'asc')
                        ->paginate(20);

        }

        // echo '<pre>'; print_r($faqcategories);die;
        return view('admin.faqcategories.faqcategories', compact('faqcategories', 'id', 'parentcatID'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'faqcategories', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $default_lng_detail = $this->getdefaultlanguage();
        //Language code list
        $languagecodes = $this->languagecodes();        
        //Get default language ID
        $default_lng_id = $this->defaultlanguageId();     
        $defaultcatID =  $this->defaultcatID();   
        //Get default language
        $default_lng = strtolower($default_lng_detail->name);
        $faqcategories = Faqcategory::whereLanguagecode_id($default_lng_id)
                        ->orderBy('short_order', 'asc')
                        ->paginate(20);

        $data = [
            'languagecodes' => $languagecodes,
            'default_lng_detail' => $default_lng_detail,
            'default_lng_id' => $default_lng_id,
            'default_lng' => $default_lng,
        ];

        return view('admin.faqcategories.create', compact('faqcategories','data','languagecodes','default_lng_id','default_lng','default_lng_detail') );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'faqcategories', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Validation request data
        $request->validate([
            'name.*' => 'nullable|required_if:local.*,1|string|max:191',
            'status.*' => 'boolean',
        ]);

        //Data request
        $category = request('category');
        $languagecode = request('languagecode');

        //Get array first value.
        // $first = Arr::first($category, function ($value, $key) {
        //     return $value;
        // });

        $cat_level = NULL;

        //Get cat level
        // if(!in_array($first, $this->defaultcatID())){
        //     $cat_level = 3;            
        // }

        //Get second level category
        // if(in_array($first, $this->defaultcatID())){
        //     $cat_level = 2;
        // }

        //Request data
        $name = request('name');
        $status = request('status');
        $local = request('local');

        $default_lng = $this->getdefaultlanguage();
        $lang_id = $default_lng->id;

        $default_name = '';
        $default_status = '';
        $default_category = '';

        foreach ($languagecode as $key => $value)
        {
            //Check if name is empty
            if(empty($name[$key]))
            {
                $default_name = $name[$lang_id];
            }

            //Check if category is empty
            if(empty($category[$key]))
            {
                $default_category = $category[$lang_id];
            }

            //Check if status is empty
            if(!empty($status[$key]))
            {
                $default_status = $status[$lang_id] ?? false;
            }

            $cat_name = $name[$key] ?? $default_name;
            $cat_status = $status[$key] ?? $default_status;
            $parent_category = $category[$key] ?? $default_category;

            if(!empty($cat_name) && !empty($value))
            {
                $countRow = DB::table('faq_categories')->count();
                $create = Faqcategory::create([
                    'category_id' => $parent_category,
                    'languagecode_id' => $value,
                    'title' => ucfirst(strtolower($cat_name)),
                    'category_level' => $cat_level,
                    'status' => $cat_status,
                    'short_order' => $countRow,
                    'slug' => Str::slug($cat_name),
                ]);
                //Get Parent ID
                $parent_id = $request->session()->get('parent_id');
                //Put parent id in session if parent ID empty
                if(empty($request->session()->get('parent_id')))
                {
                    // Via a request instance...
                    $parent_id =  $request->session()->put('parent_id', $create->id);
                }

                //Check parent ID value if empty
                if(empty($parent_id))
                {
                    $parent_id = $create->id;   
                }
                //Update parent ID
                Faqcategory::where('id', $create->id)->update([
                    'parent_id' => $parent_id
                ]);
            }

        }
        
        // Forget session value...
        $request->session()->forget('parent_id');

        return redirect(route('faqcategories'))->with('success', trans('messages.faqcategory_has_been_successfully_added'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, $lng_id)
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'faqcategories', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $detail = Faqcategory::where('id', $id)->where('languagecode_id', $lng_id)->count();

        if(!$detail){

            abort(404);

        }
        return true;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id, $category_id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, $category_id=null)
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'faqcategories', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        //check category ID exit or not
        $default_lng_detail = $this->getdefaultlanguage();        

        $cat_detail  = Faqcategory::findOrFail($id);
        
        $faqcategories = Faqcategory::where('status', 1)->get();

        $languagecodes = $this->languagecodes();
        $current_lng_id = $default_lng_detail->id;
        $current_lng = strtolower($default_lng_detail->name);

        $data = [
            'languagecodes' => $languagecodes,
            'default_lng_detail' => $default_lng_detail,
            'current_lng_id' => $current_lng_id,
            'current_lng' => $current_lng,
            'faqcategories' => $faqcategories,
            'cat_detail' => $cat_detail,
        ];

        return view('admin.faqcategories.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id, $category_id=null)
    {

        if(!$this->checkPermission(Auth::user()->role_id, 'faqcategories', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        //check category ID exit or not
        $default_lng_detail = $this->getdefaultlanguage();
        /*$this->show($id, $default_lng_detail->id);
        if($id!=1 && $id!=2 && $id!=3 && $id!=4 && $id!=5 && $id!=6){
            $this->show($category_id, $default_lng_detail->id);
        }*/

        $request->validate([
            'name.*' => 'nullable|required_if:local.*,1|string|max:191',
            'status.*' => 'boolean',
        ]);

        //Faqcategory detail
        $categorydetail = Faqcategory::findOrFail($id);

        if(request('category'))
        {

            $category = request('category');
            
            //$languagecode = request('languagecode');
            $first = Arr::first($category, function ($value, $key) {
                return $value;
            });
            
            //Get category language parent Id
            $categorybylang = Faqcategory::where('id', $id)
                            ->whereLanguagecode_id($default_lng_detail->id)
                            ->first();

            $parent_id = $id;

            if($categorybylang){
                $categorybylang = $categorybylang->toArray();
                $parent_id = $categorybylang['parent_id'];
            }

            //check second level category            
            if($first==1 || $first==2 || $first==3 || $first==4 || $first==5 || $first==6){
                //check second level category

                $levelsecondcount = Faqcategory::where('parent_id', '!=', $parent_id)
                                    ->where('category_id', $first)
                                    ->groupBy('languagecode_id')
                                    ->count();
                
                if($levelsecondcount==2){

                    return back()->with('error', trans('messages.oops'));
                    exit();

                }


            }
             
            if($first!=1 && $first!=2 && $first!=3 && $first!=4 && $first!=5 && $first!=6){  
                //check third level category
                //whereNotIn('id', [1, 4])->
                $levelthirdcount = Faqcategory::where('parent_id', '!=', $parent_id)
                                    ->where('category_id', $first)
                                    ->groupBy('languagecode_id')
                                    ->count();
                if($levelthirdcount==3){

                    return back()->with('error', trans('messages.oops'));
                    exit();

                }

            }

        }else{

            $category[$default_lng_detail->id] = $id;

        }

        //Request data
        $languagecode = request('languagecode');
        $name = request('name');
        $status = request('status');
        $local = request('local');
        $cat_id = request('cat_id');

        $default_lng = $this->getdefaultlanguage();

        $lang_id = $default_lng->id;

        $default_name = '';
        $default_status = '';
        $default_category = '';

        foreach ($languagecode as $key => $value)
        {

            //Check if name is empty
            if(empty($name[$key])){
                $default_name = $name[$lang_id];
            }

            //Check if category is empty
            if(empty($category[$key])){
                $default_category = $category[$lang_id];
            }

            if(!empty($status[$key])){
                $default_status = $status[$lang_id] ?? false;
            }

            $cat_name = $name[$key] ?? $default_name;
            $cat_status = $status[$key] ?? $default_status;
            $parent_category = $category[$key] ?? $default_category;

            if(!empty($cat_name) && !empty($value)){

                if(empty($cat_id[$key])){

                    $create = Faqcategory::create([
                        'category_id' => $parent_category,
                        'languagecode_id' => $value,
                        'title' => $cat_name,
                        'status' => $cat_status,
                        'parent_id' => request('parent_id'),
                        'slug' => Str::slug($cat_name),
                    ]);

                }else{

                    if(!empty($cat_id[$key])){
                        $update = Faqcategory::where('id', $cat_id[$key])->update([
                            'languagecode_id' => $value,
                            'title' => $cat_name,
                            'status' => $cat_status,
                            'slug' => Str::slug($cat_name),
                        ]);
                    }

                }
            }

        }
        
        if($categorydetail->category_id){

            return redirect(route('faqcategories', $categorydetail->category_id))->with('success', trans('messages.faqcategory_has_been_updated'));
            exit();
        }

        return redirect(route('faqcategories'))->with('success', trans('messages.faqcategory_has_been_updated'));
        exit();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'faqcategories', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $category = Faqcategory::findOrFail($id);

        //Delete category    
        Faqcategory::where('category_id', $id)->delete();
        Faqcategory::where('parent_id', $category->parent_id)->delete();
        DB::table('faq')->where('faq_category_id',$id)->delete();

        return redirect()->back()->with('success', trans('messages.the_faqcategory_has_been_deleted'));
        exit();                        
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function status(Request $request, $id)
    {
        if($request->ajax()){

            $output = array('success' => '', 'error' => '');

            $status = request('status') ? false : true;
            $cat_id = request('id');
            $featuredFaqcategory = Faqcategory::where('id', $id)->first(['id', 'parent_id']);
			$parent_id=$featuredFaqcategory->parent_id;
            $update = Faqcategory::where('parent_id', $parent_id)->update(['status' => $status]);
            if($update){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }


    /**
     * Update the table row sorting.
     *
     * @return \Illuminate\Http\Response
     */
    public function sortTable(Request $request)
    {
        if($request->ajax()){

            $position = request('position');
            $i = 1;
            foreach ($position as $k => $id) 
            {
                Faqcategory::where('parent_id', $id)->update(['short_order' => $i]);
                $i++;
            }
            
            return response()->json(['success' => 'Update successfully.']);
            exit;

        }
    }

    /**
     * Get the default language code ID
     *
     * @return \Illuminate\Http\Response
     */
    private function defaultlanguageId()
    {
        $languagecode_id = Languagecode::where('is_default', true)->first('id')->toArray();

        return $languagecode_id['id'];
    }


    /**
     * Check second level category
     *
     * @return \Illuminate\Http\Response
     */
    private function checksecondlevelFaqcategory($first)
    {
        if($first==1 || $first==2 || $first==3 || $first==4 || $first==5 || $first==6){

            $count = Faqcategory::where('category_id', $first)
                                ->groupBy('languagecode_id')
                                ->count();
            if($count==2){                
                return false;
            }            
        }
        return true;
    }


    /**
     * Check third level category
     *
     * @return \Illuminate\Http\Response
     */
    private function checkthirdlevelFaqcategory($first)
    {
        if($first!=1 || $first!=2 || $first!=3 || $first!=4 || $first!=5 || $first!=6){
            $count = Faqcategory::where('category_id', $first)
                                ->groupBy('languagecode_id')
                                ->count();
            if($count==3){
                return false;
            }            
        }
        return true;
    }
}
