<?php

namespace App\Http\Controllers\Admin\Ads;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Traits\UploadTrait;
use Carbon\Carbon;
use App\Models\Ad;
use App\Traits\checkermissionsTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;

class AdsController extends Controller
{
    use checkermissionsTrait, UploadTrait, LanguagecodeTrait;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'ads', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $defaultlanguage = $this->getdefaultlanguage();
        $ads = Ad::whereLanguagecode_id($defaultlanguage->id)->latest()->get();

        return view('admin.ads.ads', compact('ads'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'ads', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecodes = $this->languagecodes();
		$optionsAr = array(
			'1' => 'SplashScreen',

		);
		
        return view('admin.ads.create', compact('languagecodes','optionsAr'));
    }


    private function validateadsData(Request $request)
    {
        $validatedata = $request->validate([
            'title.*' => 'nullable|required_if:local.*,1|string|max:191',
            'start_date' => 'required|date_format:d/m/Y',
            'end_date' => 'required|date_format:d/m/Y',
            'fullwidth_image.*' => 'required|image|mimes:jpeg,jpg,png|dimensions:width=750,height=1624',
            'android_fullwidth_image.*' => 'required_if:local.*,1|image|mimes:jpeg,jpg,png|dimensions:width=720,height=1280',
            'location' => 'required|string',
            'latitude' => 'required',
            'longitude' => 'required',
            'radius' => 'required',
            'url.*' => 'nullable|required_if:local.*,1|active_url',
        ]);

        return $validatedata;
    }

    private function validateadsupdateData(Request $request, $fullwidth_image, $android_fullwidth_image)
    {
        $validatedata = $request->validate([
            'title' => 'required|string|max:191',
            'start_date' => 'required|date_format:d/m/Y',
            'end_date' => 'required|date_format:d/m/Y',
            'fullwidth_image' => $fullwidth_image.'|image|mimes:jpeg,jpg,png|dimensions:width=750,height=1624',
            'android_fullwidth_image.*' => $android_fullwidth_image.'|image|mimes:jpeg,jpg,png|dimensions:width=720,height=1280',
            'location' => 'required|string',
            'latitude' => 'required',
            'longitude' => 'required',
            'radius' => 'required',
            'url' => 'required|active_url',
        ]);

        return $validatedata;
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'ads', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Validate request data
        $this->validateadsData($request);

        //Request data
        $title = request('title');
        $ad_type = request('ad_type');
		$start_date = request('start_date');
        $end_date = request('end_date');
		$banner = $request->file('banner');
        $fullwidth_image = $request->file('fullwidth_image');
        $android_fullwidth_image = $request->file('android_fullwidth_image');
        $location = request('location');
        $latitude = request('latitude');
        $longitude = request('longitude');
        $radius = request('radius');
        $url = request('url');

        $status = request('status') ? true : false;

        //Date format change
        $new_start_date = Carbon::createFromFormat('d/m/Y', $start_date)->format('Y-m-d') ? : NULL;
        $new_end_date = Carbon::createFromFormat('d/m/Y', $end_date)->format('Y-m-d') ? : NULL;
		
        $uplode_image_path = public_path('uploads/ads');
        $languagecode = request('languagecode');        
        $defaultlanguage = $this->getdefaultlanguage();
        $lang_name = strtolower($defaultlanguage->name);

        $default_title = '';
        $default_url = '';
        $default_fullwidth_image = '';
        $default_android_fullwidth_image = '';
		
        foreach ($languagecode as $key => $value) {

            //Check if title is empty
            if(empty($title[$key])){
                $default_title = $title[$lang_name];
            }

            //Check if url is empty
            if(empty($url[$key])){
                $default_url = $url[$lang_name];
            }

            //Check if fullwidth image is empty
            if(empty($fullwidth_image[$key])){
                $default_fullwidth_image = $fullwidth_image[$lang_name];
            }

            //Check if android fullwidth image is empty
            if(empty($android_fullwidth_image[$key])){
                $default_android_fullwidth_image = $android_fullwidth_image[$lang_name];
            }

            if(!empty($value)){

                //ads image uploads
				$banner_img  = $banner[$key] ?? '';
                $fullwidth_img  = $fullwidth_image[$key] ?? '';                
                $android_fullwidth_img  = $android_fullwidth_image[$key] ?? '';
                
                $get_fullwidth_image = NULL;

                $get_android_fullwidth_image = NULL;

                // Check if a header image has been uploaded
				if (isset($banner_img) && !empty($banner_img)){
                    $get_banner_image =  $this->uploadimageCompress($banner_img, $uplode_image_path);
                }else{
                    $get_banner_image =  "";
                }
				
                if (isset($fullwidth_img) && !empty($fullwidth_img)){
                    $get_fullwidth_image =  $this->uploadimageCompress($fullwidth_img, $uplode_image_path);
                }else{
                    //$get_fullwidth_image =  $this->uploadimageCompress($default_fullwidth_image, $uplode_image_path);
					$get_fullwidth_image =  "";
                }
                
                if (isset($android_fullwidth_img) && !empty($android_fullwidth_img)) {
                    $get_android_fullwidth_image =  $this->uploadimageCompress($android_fullwidth_img, $uplode_image_path);
                }else{
                    //$get_android_fullwidth_image =  $this->uploadimageCompress($default_android_fullwidth_image, $uplode_image_path);
					$get_android_fullwidth_image =  "";
                }
                
                //end

                $ad_title = isset($title[$key]) ? $title[$key] : $default_title;
                $ad_url = isset($url[$key]) ? $url[$key] : $default_url;
                
                $create = Ad::create([
                    'languagecode_id' => $value,
                    'ad_type' => $ad_type,
                    'title' => $ad_title,
					'banner' => $get_banner_image,
                    'fullwidth_image' => $get_fullwidth_image,
                    'android_fullwidth_image' => $get_android_fullwidth_image,
                    'start_date' => $new_start_date,
                    'end_date' => $new_end_date,
                    'latitude' => $latitude,
                    'longitude' => $longitude,
                    'location' => $location,
                    'radius' => $radius,
                    'url' => $ad_url,
                    'status' => $status,
                ]);

                //Get Parent ID
                $parent_id = $request->session()->get('parent_id');

                if(empty($request->session()->get('parent_id'))){

                    // Via a request instance...
                    $parent_id =  $request->session()->put('parent_id', $create->id);

                }

                //Check parent ID value
                if(empty($parent_id)){
                    $parent_id = $create->id;   
                }
                
                //Update parent ID
                Ad::where('id', $create->id)->update([
                    'ad_id' => $parent_id
                ]);

            }
        }

        // Forget session value...
        $request->session()->forget('parent_id');
        
        return redirect(route('manage_ads'))->with('success', trans('messages.Add has been successfully added'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'ads', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $ad = Ad::findOrFail($id);
		$languagecodes = $this->languagecodes();
		$optionsAr = array(
			'1' => 'SplashScreen',
		);
		
        return view('admin.ads.edit', compact('ad','languagecodes','optionsAr'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'ads', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $ad_detail = Ad::findOrFail($id);

        if(!$ad_detail){
            return abort(404);
        }

        $check_fullwidth_image = $ad_detail->fullwidth_image ? 'nullable' : 'required';
        $check_android_fullwidth_image = $ad_detail->android_fullwidth_image ? 'nullable' : 'required';

        //Validate request data
        $this->validateadsupdateData($request, $check_fullwidth_image, $check_android_fullwidth_image);
        
        //Request data
        $title = request('title');
        $start_date = request('start_date');
        $end_date = request('end_date');
        $fullwidth_image = $request->file('fullwidth_image');
        $android_fullwidth_image = $request->file('android_fullwidth_image');
        $location = request('location');
        $latitude = request('latitude');
        $longitude = request('longitude');
        $radius = request('radius');
        $url = request('url');

        $status = request('status') ? true : false;
        
        $fullwidth_image_name = $ad_detail->fullwidth_image ? : NULL;
        
        $android_fullwidth_image_name = $ad_detail->android_fullwidth_image ? : NULL;
        
        $uplode_image_path = public_path('uploads/ads');

        if($request->hasFile('fullwidth_image')){ 
            //Unlik file
            if(!empty($ad_detail->fullwidth_image) && File::exists($uplode_image_path.'/'.$ad_detail->fullwidth_image)){
                unlink($uplode_image_path.'/'.$ad_detail->fullwidth_image);
            } 

            $fullwidth_image_name =  $this->uploadimageCompress($fullwidth_image, $uplode_image_path);
        }

        if($request->hasFile('android_fullwidth_image')){

            //Unlik file
            if(!empty($ad_detail->android_fullwidth_image) && File::exists($uplode_image_path.'/'.$ad_detail->android_fullwidth_image))
            {
                unlink($uplode_image_path.'/'.$ad_detail->android_fullwidth_image);
            }

            $android_fullwidth_image_name =  $this->uploadimageCompress($android_fullwidth_image, $uplode_image_path);
        }

        if(!empty($start_date)){
            $start_date = Carbon::createFromFormat('d/m/Y', $request->start_date)->format('Y-m-d');
        }

        if(!empty($end_date)){
            $end_date = Carbon::createFromFormat('d/m/Y', $request->end_date)->format('Y-m-d');
        }

        Ad::where('id', $id)->update([
            'ad_type' => 1,
            'title' => $title,
            'fullwidth_image' => $fullwidth_image_name,
            'android_fullwidth_image' => $android_fullwidth_image_name,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'location' => $location,
            'radius' => $radius,
            'url' => $url,
            'status' => $status,
        ]);


        return redirect(route('manage_ads'))->with('success', trans('messages.Your adsentity has been updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'ads', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $ad_detail = Ad::findOrFail($id);

        if(!$ad_detail){

            return abort(404);

        }

        $uplode_image_path = public_path('uploads/ads');

        //Unlik file
        if(!empty($ad_detail->fullwidth_image) && File::exists($uplode_image_path.'/'.$ad_detail->fullwidth_image))
        {
            unlink($uplode_image_path.'/'.$ad_detail->fullwidth_image);
        }

        //Unlik file
        if(!empty($ad_detail->android_fullwidth_image) && File::exists($uplode_image_path.'/'.$ad_detail->android_fullwidth_image))
        {
            unlink($uplode_image_path.'/'.$ad_detail->android_fullwidth_image);
        }

        Ad::where('ad_id', $id)->delete();

        return redirect(route('manage_ads'))->with('success', trans('messages.The Add has been deleted'));

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function status(Request $request, $id)
    {
        if($request->ajax()){

            //Check permission access or not
            if(!$this->checkPermission(Auth::user()->role_id, 'ads', 'is_edit'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                    exit();
            }

            $output = array('success' => '', 'error' => '');

            $status = request('status') ? false : true;
            $ad_id = request('id');
            
            $update = Ad::where('id', $id)->update(['status' => $status]);
            if($update){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }
}
