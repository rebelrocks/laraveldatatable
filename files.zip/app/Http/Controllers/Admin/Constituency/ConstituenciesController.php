<?php

namespace App\Http\Controllers\Admin\Actualites;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Traits\UploadTrait;
use Carbon\Carbon;
use App\Models\Constituency;
use App\Traits\checkermissionsTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Helper;

class ConstituenciesController extends Controller
{
    use checkermissionsTrait, UploadTrait, LanguagecodeTrait;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $defaultlanguage = $this->getdefaultlanguage();
        $actualites = Constituency::whereLanguagecode_id($defaultlanguage->id)->orderBy('short_order','ASC')->get();

        return view('admin.actualites.actualites', compact('actualites'));
    }

    public function ajax_get_actualites(Request $request){

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $defaultlanguage = $this->getdefaultlanguage();
        if(request()->ajax()) {

            $draw = request('draw');

            $row = request('start');

            $rowperpage = request('length'); // Rows display per page

            $columnIndex = request('order')['0']['column']; // Column index
            
            $columnName = request('columns')[$columnIndex]['data']; // Column name

            $columnSortOrder = request('order')[0]['dir']; // asc or desc
            
            $searchValue = request('search')['value']; // Search value
            

            ## Total number of records without filtering
            $totalRecords = DB::table('actualites')->count();

            ## Table Sorting
            
            ## Fetch records
            if(!empty($searchValue)){

                 $empQuery = Constituency::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->where('title', 'like', '%'.$searchValue.'%')
                            ->offset($row)
                            ->limit($rowperpage)
                            ->get();

                    ## Total number of records without filtering
                    $totalRecords = DB::table('actualites')->where('title', 'like', '%'.$searchValue.'%')->count();
                    
            }elseif(!empty($columnName)){

                //Change create column name created_at
                if($columnName=='created'){
                    $columnName  = 'created_at';  
                }

                $empQuery = Constituency::select('*')
                           # ->whereLanguagecode_id($defaultlanguage->id)
                            ->offset($row)
                            ->limit($rowperpage)->get();
                            #->orderebycoloumn($columnName, $columnSortOrder);
                
            }else{
                $empQuery = Constituency::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->offset($row)
                            ->limit($rowperpage)->get();
                       
            }

            $data = array();
            $are_you_sure_want_to_delete = "'".trans('messages.are_you_sure_want_to_delete')."'";
            $change_status = "'".trans('messages.change_status')."'";
            if(count($empQuery)){
            
                foreach($empQuery as $rk1 => $rv1){
                    $data[$rk1]['id'] = $rv1->id;
                    $data[$rk1]['title'] = $rv1->title;
                    $data[$rk1]['link'] = $rv1->link ?? '-';
                    
                    $status = trans('messages.statusinactive');
                    //$change_status = trans('messages.change_status');
                    $status_class = 'danger';
                    if($rv1->status){
                        $status = trans('messages.statusactive');
                        $status_class = 'success';
                    }

                    $data[$rk1]['status'] = '<a id="atag'.$rv1->id.'" class="btn btn-'.$status_class.'" data-id="'.$rv1->id.'" data-status="'.$rv1->status.'" href="javascript:void(0)" onclick="updateActualitesStatus(this)" >'.$status.'</a>';


                    $actions = '';
                                    
                    
                    $actions .= '<a href="'.route('update_actualites', $rv1->id).'" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>&nbsp; <br />';
                    
                    $actions .= '<a href="'.route('delete_actualites', $rv1->id).'" class="btn btn-danger" onclick="return confirm('.$are_you_sure_want_to_delete.')"><i class="material-icons">clear</i> SUPPRIMER</a>'; 
                    
                    $data[$rk1]['action'] = $actions;
                }
            }

            
            
            ## Total number of record with filtering
            $totalRecordwithFilter = Constituency::where('title', 'like', '%'.$searchValue.'%')->count();
            

            ## Response
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $totalRecordwithFilter,
                "iTotalDisplayRecords" => $totalRecords,
                "aaData" => $data
            );            
            echo json_encode($response);
            exit(); 
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return view('admin.actualites.create');
    }

    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        
        #$this->validateadsData($request);

        $status = request('status') ? true : false;
        $uplode_image_path = public_path('uploads/actualites');
        $title = request('title') ? request('title') :'';
		$subtitle = request('subtitle') ? request('subtitle') :'';
		$slide_image = request()->file('slide_image');
		$get_slide_image='';
        if($request->hasFile('slide_image')){
            if(!empty($slide_image)){
                @$get_slide_image =  $this->uploadimageCompress($slide_image, $uplode_image_path);
               
            }
        }
        $create = Constituency::create([
            'languagecode_id' => 0,
            'parent_id'=>'0',
            'image'=>$get_slide_image,
            'title' =>$title,
            'description' =>$subtitle,
            'link' => $request->link ? $request->link : '',				
            'status' => $status,
        ]);
        return redirect(route('actualites'))->with('success', trans('messages.Actualites been successfully added'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    

    

    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $Actualites = Constituency::find($id);

        return view('admin.actualites.edit', compact('Actualites'));

    }
    
    public function update(Request $request, $id){
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
		
            
        $this->validateadsData($request);

        $status = request('status') ? true : false;
        $uplode_image_path = public_path('uploads/actualites');
        $title = request('title') ? request('title') :'';
		$subtitle = request('subtitle') ? request('subtitle') :'';
		$slide_image = request()->file('slide_image');
		$get_slide_image='';
        if($request->hasFile('slide_image')){
            if(!empty($slide_image)){
                @$get_slide_image =  $this->uploadimageCompress($slide_image, $uplode_image_path);
               
            }
        }else{
            $get_slide_image=$request->previous_slide_image ? $request->previous_slide_image :''; 
        }
        $update = Constituency::where('id',$id)->update([
            'languagecode_id' => 0,
            'parent_id'=>'0',
            'image'=>$get_slide_image,
            'title' =>$title,
            'description' =>$subtitle,
            'link' => $request->link ? $request->link : '',				
            'status' => $status,
        ]);
        
        return redirect(route('actualites'))->with('success', trans('messages.Actualites been successfully updated'));
        
    }
    private function validateadsData(Request $request)
    {
        $validatedata = $request->validate([
            'title' => 'required|string',
            'subtitle' => 'required|string'
        ],
        [
            'title.required' => trans('messages.This field is required'),
            'subtitle.required' => trans('messages.This field is required')
        ]);

        return $validatedata;
    }

    private function validateadsupdateData(Request $request,$android_fullwidth_image)
    {
        $validatedata = $request->validate([
            'title' => 'required|string',
            'subtitle' => 'required|string',
        ],
        [
            'title.required' => trans('messages.This field is required'),
            'subtitle.required' => trans('messages.This field is required')
        ]);

        return $validatedata;
    }

    public function destroy($id){
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $languagecodes = $this->languagecodes();
        
		$slides = Constituency::where('id', $id)->get();

        if(!$slides){
            return abort(404);
            exit();
        }
        if(count($slides) > 0){
            foreach($slides as $slide){
                $uplode_image_path = public_path('uploads/actualites');
                if(!empty($slide->image) && File::exists($uplode_image_path.'/'.$slide->image)){
                    unlink($uplode_image_path.'/'.$slide->image);
                }

            }
        }
        
        Constituency::where('id', $id)->delete();
		
        return redirect(route('actualites'))->with('success', trans('messages.Actualites been successfully deleted'));

    }

    public function updatestatus(Request $request){

        if($request->ajax()){

            //Check permission access or not
            if(!$this->checkPermission(Auth::user()->role_id, 'actualites', 'is_read'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                    exit();
            }

            $output = array('success' => '', 'error' => '');
            
            $status = request('status') ? false : true;
            $id=request('id');
            $update = Constituency::where('id', $id)->update(['status' => $status]);

            if($update){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }
	
	
	/**
     * Update the table row sorting.
     *
     * @return \Illuminate\Http\Response
     */
    public function sortTable(Request $request)
    {
        if($request->ajax()){

            $position = request('position');
            $i = 1;
            foreach ($position as $k => $id) 
            {
                Constituency::where('id', $id)->update(['short_order' => $i]);
                $i++;
            }
            
            return response()->json(['success' => 'Update successfully.']);
            exit;

        }
    }
}