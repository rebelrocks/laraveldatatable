<?php

namespace App\Http\Controllers\Admin\Emailtemplate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Session;
use App\Models\Emailtemplate;
use Carbon\Carbon;
use App\Traits\Emailtemplate\EmailtemplateTrait;
use App\Traits\UploadTrait;
use App\Traits\checkermissionsTrait;
use App\Traits\Mailjet\MailjetTrait;
use App\Traits\GeneralsettingTrait;
use App\Traits\Sociallink\SociallinkTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Helper;

class EmailtemplatesController extends Controller
{

    use EmailtemplateTrait, UploadTrait, checkermissionsTrait,
        MailjetTrait, GeneralsettingTrait, SociallinkTrait, 
        LanguagecodeTrait;

    private $emailtemplatedir = "uploads/emailtemplates";

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $defaultlanguage = $this->getdefaultlanguage();
        $emailtemplates = Emailtemplate::whereLanguagecode_id($defaultlanguage->id)->get();

        return view('admin.emailtemplates.emailtemplates', compact('emailtemplates'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        /**
         * 
         * application\App\Traits\Emailtemplate 
         * Change email content line no(21)
         */
        $default_html_content = $this->defaulthtmlContent();
        $languagecodes = $this->languagecodes();
        return view('admin.emailtemplates.create', compact('default_html_content', 'languagecodes'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Validate request data
        $request->validate([
            'title' => 'required|string|max:191',
            'subject.*' => 'nullable|required_if:local.*,1|string|max:191',
            'sender_name.*' => 'nullable|required_if:local.*,1|string|max:191',
            'main_color.*' => 'nullable|required_if:local.*,1|string|max:191',
            'secondary_color.*' => 'nullable|required_if:local.*,1|string|max:191',
            'header_image.*' => 'nullable|required_if:local.*,1|image|mimes:jpeg,jpg,png,gif|max:2048',
            'white_logo.*' => 'nullable|required_if:local.*,1|image|mimes:jpeg,jpg,png,gif|max:2048',
            'description.*' => 'nullable|required_if:local.*,1|string',
            'text_part.*' => 'nullable|required_if:local.*,1|string',
        ]);

        //Request input data
        $title = request('title');
        $subject = request('subject');
        $sender_name = request('sender_name');
        $main_color = request('main_color');
        $secondary_color = request('secondary_color');
        $description = request('description');
        $text_part = request('text_part');

        //Request files
        $header_image = $request->file('header_image');
        $white_logo = $request->file('white_logo');

        $languagecode = request('languagecode');

        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);

        $default_subject = '';
        $default_sender_name = '';
        $default_main_color = '';
        $default_secondary_color = '';
        $default_email_content = '';
        $default_email_text_part = '';
        $default_header_image = '';
        $default_white_logo = '';

        $uplode_image_path = public_path(self::uploademailtemplatedir());

        $get_header_image = NULL;

        $get_white_logo = NULL;

        foreach ($languagecode as $key => $value)
        {
            //Check if subject is empty
            if(empty($subject[$key])){
                $default_subject = $subject[$lang_name];
            }

            //Check if sender_name is empty
            if(empty($sender_name[$key])){
                $default_sender_name = $sender_name[$lang_name];
            }

            //Check if main color is empty
            if(empty($main_color[$key])){
                $default_main_color = $main_color[$lang_name];
            }

            //Check if secondary color is empty
            if(empty($secondary_color[$key])){
                $default_secondary_color = $secondary_color[$lang_name];
            }

            //Check if email content is empty
            if(empty($description[$key])){
                $default_email_content = $description[$lang_name];
            }

            //Check if email text part is empty
            if(empty($text_part[$key])){
                $default_email_text_part = $text_part[$lang_name];
            }

            //Check if header image is empty
            if(empty($header_image[$key])){
                $default_header_image = $header_image[$lang_name];
            }

            //Check if white logo is empty
            if(empty($white_logo[$key])){
                $default_white_logo = $white_logo[$lang_name];
            }

            # code...
            if(!empty($value)){

                //Upload new file
                $header_image_photo  = $header_image[$key] ?? '';
                
                $white_logo_photo  = $white_logo[$key] ?? '';

                // Check if a header image has been uploaded
                if (isset($header_image_photo) && !empty($header_image_photo))
                {
                    @$get_header_image =  $this->uploadimageCompress($header_image_photo, $uplode_image_path);
                }else{

                    if(!empty($default_header_image)){
                        
                        @$get_header_image =  $this->uploadimageCompress($default_header_image, $uplode_image_path);
                    }
                }

                //end                

                // Check if a header image has been uploaded
                if (isset($white_logo_photo) && !empty($white_logo_photo)) {

                    @$get_white_logo =  $this->uploadimageCompress($white_logo_photo, $uplode_image_path);

                }else{
                    if(!empty($default_white_logo)){
                        @$get_white_logo =  $this->uploadimageCompress($default_white_logo, $uplode_image_path);
                    }
                }

                $email_subject = isset($subject[$key]) ? $subject[$key] : $default_subject;
                $email_sender_name = isset($sender_name[$key]) ? $sender_name[$key] : $default_sender_name;
                $email_main_color = isset($main_color[$key]) ? $main_color[$key] : $default_main_color;
                $email_secondary_color = isset($secondary_color[$key]) ? $secondary_color[$key]  : $default_secondary_color;
                $email_description = isset($description[$key]) ? $description[$key] : $default_email_content;
                $email_text_part = isset($text_part[$key]) ? $text_part[$key] : $default_email_text_part;

                $create = Emailtemplate::create([
                    'languagecode_id' => $value,            
                    'title' => $title,            
                    'subject' => $email_subject,            
                    'sender_name' => $email_sender_name,            
                    'main_color' => $email_main_color,            
                    'secondary_color' => $email_secondary_color,            
                    'header_image' => $get_header_image,            
                    'white_logo' => $get_white_logo,            
                    'description' => $email_description,            
                    'text_part' => $email_text_part,            
                    'status' => true,            
                    'is_html' => true, 
                    'slug' => $title, 
                ]);

                //Get Parent ID
                $parent_id = $request->session()->get('parent_id');

                if(empty($request->session()->get('parent_id'))){

                    // Via a request instance...
                    $parent_id =  $request->session()->put('parent_id', $create->id);

                }

                //Check parent ID value
                if(empty($parent_id)){
                    $parent_id = $create->id;   
                }
                
                //Update parent ID
                Emailtemplate::where('id', $create->id)->update([
                    'emailtemplate_id' => $parent_id
                ]);
            }
        }

        // Forget session value...
        $request->session()->forget('parent_id');

        return redirect(route('email_templates'))->with('success', trans('messages.email_templates_updated'));        
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
		$default_lc_id = $this->defaultlanguageId();

		$template = Emailtemplate::where('languagecode_id', $default_lc_id)
                            ->where('emailtemplate_id', $id)
                            ->first();

        if(!$template){
            return abort(404);
            exit();
        }
		
        $languagecodes = $this->languagecodes();
        return view('admin.emailtemplates.edit', compact('template', 'languagecodes', 'default_lc_id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        
        $subject = request('subject');
		$text_part = request('text_part');
        $main_color = request('main_color');
        $template_id = request('template_id');
        $description = request('description');
        $languagecode = request('languagecode');
        $sender_name = request('sender_name');
        $secondary_color = request('secondary_color');

        $lc_id = $this->defaultlanguageId();
        $defaultlanguage = $this->getdefaultlanguage();
        $lc_name = strtolower($defaultlanguage->name);

        // echo '<pre>'; print_r($request->all());die;

        $getDefaultEmail = Emailtemplate::where('id',$id)->where('languagecode_id',$lc_id)->first();
        // echo '<pre>'; print_r($getDefaultEmail);die;

		
        foreach ($languagecode as $key => $value) 
        {
			
			$add_subject = $subject[$key] ?? $subject[$lc_name];
			$add_sender_name = $sender_name[$key] ?? $sender_name[$lc_name];
			$add_main_color = $main_color[$key] ?? $main_color[$lc_name];
			$add_secondary_color = $secondary_color[$key] ?? $secondary_color[$lc_name];
			$add_description = $description[$key] ?? $description[$lc_name]; 
			$add_text_part = $text_part[$key] ?? $text_part[$lc_name];  



            $getEmailData = Emailtemplate::where('emailtemplate_id',$id)->where('languagecode_id',$value)->first();

            if (!empty($getEmailData)) 
            {
                $template = self::getemplateDetail($template_id[$key]);
                if(!$template)
                {
                    return abort(404);
                }
                
                $update = Emailtemplate::where('id', $template_id[$key])->update([
                    'languagecode_id' => $value,
                    'subject' => $add_subject,            
                    'sender_name' => $add_sender_name,            
                    'main_color' => $add_main_color,            
                    'secondary_color' => $add_secondary_color,           
                    'description' => $add_description,            
                    'text_part' => $add_text_part,
                ]);
                
                
            }
            else
            {
                $create = Emailtemplate::create([
                    'languagecode_id' => $value,
                    'subject' => $add_subject,            
                    'sender_name' => $add_sender_name,            
                    'main_color' => $add_main_color,            
                    'secondary_color' => $add_secondary_color,           
                    'description' => $add_description,            
                    'text_part' => $add_text_part,
                    'emailtemplate_id' => $id,
                ]);
            }


                $uplode_image_path = public_path(self::uploademailtemplatedir());
                //Upload new header_image
                if ($request->has('header_image')) 
                {
                    $header_image = $request->file('header_image');
                    //Unlik file                        
                    if(!empty($template->header_image) && File::exists($uplode_image_path.'/'.$template->header_image))
                    {
                        @unlink($uplode_image_path.'/'.$template->header_image);
                    }

                    @$get_header_image =  $this->uploadimageCompress($header_image, $uplode_image_path);
                    if(!empty($get_header_image))
                    {
                        Emailtemplate::where('emailtemplate_id', $id)->update(['header_image' => $get_header_image]);
                    }
                }
                else
                {
                    Emailtemplate::where('emailtemplate_id', $id)->update(['header_image' => $getDefaultEmail->header_image]);

                }
                
                if ($request->has('white_logo')) 
                {
                    $white_logo = $request->file('white_logo');
                    //Unlik file
                    if(!empty($template->white_logo) && File::exists($uplode_image_path.'/'.$template->white_logo))
                    {
                        @unlink($uplode_image_path.'/'.$template->white_logo);
                    }

                    @$get_white_logo =  $this->uploadimageCompress($white_logo, $uplode_image_path);
                    if(!empty($get_white_logo))
                    {
                        Emailtemplate::where('emailtemplate_id', $id)->update(['white_logo' => $get_white_logo]);
                    }
                }
                else
                {
                    Emailtemplate::where('emailtemplate_id', $id)->update(['white_logo' => $getDefaultEmail->white_logo]);

                }
           
        }
		return redirect(route('email_templates'))->with('success', trans('messages.email_templates_updated'));

        exit();
		exit;
        $check_white_logo = $template->white_logo ? 'nullable' : 'required';
        $check_header_image = $template->header_image ? 'nullable' : 'required';

        $languagecode_name = $this->getlanguagecodeByname(request('languagecode_name'));

        $languagecode_name = strtolower($languagecode_name->name);

        //Validate request data
        $this->validateupdatetemplateData($request, $languagecode_name, $check_white_logo, $check_header_image);

        //Request input data
        $subject = request('subject_'.$languagecode_name);
        $sender_name = request('sender_name_'.$languagecode_name);
        $main_color = request('main_color_'.$languagecode_name);
        $secondary_color = request('secondary_color_'.$languagecode_name);
        $description = request('description_'.$languagecode_name);

        //Request files
        $header_image = $request->file('header_image_'.$languagecode_name);
        $white_logo = $request->file('white_logo_'.$languagecode_name);
        $languagecode = request('languagecode');
        $text_part = request('text_part_'.$languagecode_name);

        $get_header_image = $template->header_image ? : NULL;
        $get_white_logo = $template->white_logo ? : NULL;

        // Check if a header image has been uploaded
        if ($request->has('header_image_'.$languagecode_name)) {

            $uplode_image_path = public_path(self::uploademailtemplatedir());

            //Unlik file
            if(!empty($template->header_image) && File::exists($uplode_image_path.'/'.$template->header_image))
            {
                @unlink($uplode_image_path.'/'.$template->header_image);
            }

            $get_header_image =  $this->uploadimageCompress($header_image, $uplode_image_path);

        }
        //end

        // Check if a header image has been uploaded
        if ($request->has('white_logo_'.$languagecode_name)) {

            $uplode_image_path = public_path(self::uploademailtemplatedir());

            //Unlik file
            if(!empty($template->white_logo) && File::exists($uplode_image_path.'/'.$template->white_logo))
            {
                @unlink($uplode_image_path.'/'.$template->white_logo);
            }

            $get_white_logo =  $this->uploadimageCompress($white_logo, $uplode_image_path);

        }
        //end
        // dd([$get_header_image,$get_white_logo]);
        $template_id= request('template_id');

        $update = Emailtemplate::where('id', $id)->update([
            'subject' => $subject,            
            'sender_name' => $sender_name,            
            'main_color' => $main_color,            
            'secondary_color' => $secondary_color,            
            'header_image' => $get_header_image,            
            'white_logo' => $get_white_logo,            
            'description' => $description,            
            'text_part' => $text_part,            
        ]);

        return redirect(route('email_templates'))->with('success', trans('messages.email_templates_updated'));

        exit();

        //old code 
        $languagecode = request('languagecode');
        $template_id= request('template_id');

        foreach ($subject as $key => $value)
        {

            # code...
            if(!empty($languagecode[$key]) && !empty($sender_name[$key]) && !empty($main_color[$key]) && !empty($secondary_color[$key]) && !empty($description[$key]) && !empty($template_id[$key])) {
            
                Emailtemplate::where('id', $template_id[$key])->update([
                    'languagecode_id' => $languagecode[$key],            
                    'subject' => $value,            
                    'sender_name' => $sender_name[$key],            
                    'main_color' => $main_color[$key],            
                    'secondary_color' => $secondary_color[$key],            
                    //'header_image' => $get_header_image,            
                    //'white_logo' => $get_white_logo,            
                    'description' => $description[$key],            
                    'status' => true,            
                    'is_html' => true,            
                ]);

            }
        }

        return back()->with('success', trans('messages.email_templates_updated'));
        exit();

        return redirect(route('email_templates'))->with('success', trans('messages.email_templates_updated'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatestatus(Request $request, $id)
    {
        if($request->ajax()){

            //Check permission access or not
            if(!$this->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_edit'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                    exit();
            }

            $output = array('success' => '', 'error' => '');
            
            $status = request('status') ? false : true;
            
            $update = Emailtemplate::where('id', $id)->update(['status' => $status]);

            if($update){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }



    /**
     * Define image upload path 
     */
    public function uploademailtemplatedir()
    {
        return $this->emailtemplatedir;
    }

    /**
     * Send the test email for admin email ID.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function sendtestemail(Request $request, $id)
    {
        //Get email template detail
        $template = self::getemplateDetail($id);

        if(!$template){

            return abort(404);
        }

        $adminemail = Auth::user()->email;

        $image_path = url('application/public/uploads/emailtemplates');

        $header_image = $image_path.'/'.$template->header_image;
        $white_logo = $image_path.'/'.$template->white_logo;

        //Site settings
        $sitesetting = $this->siteSettings();

        //Socail links
        $social_links = $this->sitesocialLinks();

        //Application name
        $appname = $sitesetting['site.name'] ?? 'Demo App';

        //replace template var with value
        $emailFindReplace = array(
            '##MAIN_COLOR##'  => '#'.$template->main_color,
            '##HEADER_IMAGE##' => $header_image,
            '##WHITE_LOGO##' => $white_logo,
            '##FIRST_NAME##' => ucwords(Auth::user()->first_name),
            '##SUPPORT_EMAIL##' => $sitesetting['site.support_email'] ?? '',
            '##SITE_NAME##' => $appname,
            '##SECONDARY_COLOR##' => '#'.$template->secondary_color,
            '##CONTACT_EMAIL##' => $sitesetting['site.contact_email_address'] ?? '',
            '##YEAR##' => date('Y'),
            '##FB_LINK##' => isset($social_links['EmailTemplate.fb_url']) ? '<a href="'.$social_links['EmailTemplate.fb_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/fb.png').'" width="54" /></a>' : '',
            '##TWITTER_LINK##' => isset($social_links['EmailTemplate.twitter_url']) ? '<a href="'.$social_links['EmailTemplate.twitter_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/tw.png').'" width="54" /></a>' : '',
            '##INSTA_LINK##' => isset($social_links['EmailTemplate.insta_url']) ? '<a href="'.$social_links['EmailTemplate.insta_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/it.png').'" width="54" /></a>' : '',
            '##WEBSITE##' => isset($social_links['EmailTemplate.web_url']) ? '<a href="'.$social_links['EmailTemplate.web_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/wd.png').'" width="54" /></a>' : '',
            '##LINKEDIN_LINK##' => isset($social_links['EmailTemplate.linked_in_url']) ? '<a href="'.$social_links['EmailTemplate.linked_in_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/linkedin.png').'" width="54" /></a>' : '',
            '##PWD_LINK##' => url('admin/dashboard'),
            '##REPORTED_USER_NAME##' => Auth::user()->first_name,
            '##REPORTED_USERE_MAIL##' => Auth::user()->email,
            '##USER_NAME##' => Auth::user()->first_name,
            '##FROM_USER##' => Auth::user()->first_name,
            '##FROM_USERE_MAIL##' => Auth::user()->email,
            '##MESSAGE##' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
            '##SITE_LINK##' => $sitesetting['site.url'] ?? '',
        );

        //Email template content end
        $content = strtr($template['description'], $emailFindReplace);
        //Get email subject
        $subject = strtr($template['subject'], $emailFindReplace);
        
        echo $content;
        
        exit();       

        //Get sender email
        $senderemail = $sitesetting['site.sending_email_address'] ?? '';
        
        //Send email
        try {

            if(config('app.email_send')==true){

                $this->mailjetEmail($senderemail, $appname, $subject, $content, Auth::user()->email);
                
            }

        } catch (\Exception $e) {
            
        }

        return redirect(route('email_templates'))->with('success', trans('messages.Test email sended successfully'));

    }


    /**
     * Validate the given data.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */

    private function validateupdatetemplateData(Request $request, $name, $check_header_image, $check_white_logo)
    {
        //Validate request data
        $request->validate([
            'subject_'.$name => 'required|string|max:191',
            'sender_name_'.$name => 'required|string|max:191',
            'main_color_'.$name => 'required|string|max:191',
            'secondary_color_'.$name => 'required|string|max:191',
            'header_image_'.$name => $check_header_image.'|image|mimes:jpeg,jpg,png,gif|max:2048',
            'white_logo_'.$name => $check_white_logo.'|image|mimes:jpeg,jpg,png,gif|max:2048',
            'description_'.$name => 'required|string',
        ]);
    }

}
