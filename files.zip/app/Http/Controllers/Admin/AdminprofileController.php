<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Hash;
use App\Rules\MatchOldPassword;
use App\User;
use Carbon\Carbon;

class AdminprofileController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id=null)
    {
        return view('admin.admin.edit_profile');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id=null)
    {
        //Validate request data
        $this->validateupdateprofileData($request);
        
        //Update admin profile detail
        $update = User::where('id', Auth::id())->update([
            'first_name' => request('first_name'),
            'last_name' => request('last_name'),
            'email' => request('email'),
        ]);

        //Check password blank or not
        if(!empty(request('password')))
            $update = User::where('id', Auth::id())->update([
                'password' => Hash::make(request('password')),
            ]);

                
        if($update){
            $this->SaveUserActivity('update profile by user id '.Auth::id()); 
            return redirect(route('admin.edit_profile'))->with('success', trans('messages.admin_profile_update'));

        }   

        return back()->with('warning', trans('messages.unable_update_profile'));
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editpassword()
    {
        return view('admin.admin.change_password');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function changepassword(Request $request)
    {
        //Validate request data
        $this->validatechangepassword($request);

        //Check password blank or not
        $update = User::where('id', Auth::id())->update([
            'password' => Hash::make(request('password')),
        ]);
                
        if($update){
            $this->SaveUserActivity('update password  by user id '.Auth::id());
            return redirect(route('admin.changepassword'))->with('success', trans('messages.the_password_is_successfully_changed'));

        }   

        return back()->with('warning', 'oops something went wrong please try again');
    }



    /**
     * Validate the given data.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */

    private function validatechangepassword(Request $request)
    {
        $request->validate([
            'current_password' => ['required', new MatchOldPassword],
            'password' => 'required|required_with:password_confirmation|string|min:8|confirmed|different:current_password',
        ]);
    }


    /**
     * Validate the given data.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */

    private function validateupdateprofileData(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:191',
            'last_name' => 'nullable|string|max:191',
            'email' => 'required|string|email|max:191|unique:users,email,'.Auth::id(),
            'password' => 'nullable|string|min:8',
        ],[
            'email.unique' => trans('messages.email_already_exists'),
        ]);
    }





}
