<?php

namespace App\Http\Controllers\Admin\Faq;

use Carbon\Carbon;
use App\Models\Faq;
use App\Traits\UploadTrait;
use Illuminate\Http\Request;
use App\Models\Languagecode;
use App\Models\Faqcategory;
use App\Traits\LanguagecodeTrait;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use App\Traits\checkermissionsTrait;
use Illuminate\Support\Facades\Session;

class FaqController extends Controller
{
    use checkermissionsTrait, UploadTrait, LanguagecodeTrait;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'faq', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $defaultlanguage = $this->getdefaultlanguage();
        $slides = Faq::whereLanguagecode_id($defaultlanguage->id)->latest()->get();

        return view('admin.Faq.faqs', compact('slides','defaultlanguage'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'faq', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
		
		//Get default language ID
        $default_language_id = $this->defaultlanguageId();
        $languagecodes = $this->languagecodes();
		$maincategories = Faqcategory::where('languagecode_id', $default_language_id)->get();
        return view('admin.Faq.create', compact('languagecodes','maincategories'));
    }

    private function validateadsData(Request $request)
    {
        $validatedata = $request->validate([
            'title.*' => 'required_if:local.*,1|string',
            'description.*' => 'required_if:local.*,1|string',
        ]);

        return $validatedata;
    }

    private function validateadsupdateData(Request $request,$android_fullwidth_image)
    {
        $validatedata = $request->validate([
            'title' => 'required|string',
            'description' => 'required|string',
        ]);

        return $validatedata;
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'faq', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        #$this->validateadsData($request);

        $faq_category_id = request('faq_category_id') ? request('faq_category_id') : 0;
        $title = request('title');
        $status = request('status') ? true : false;
        $description = request('description');
        $languagecode = request('languagecode');    
      
        $defaultlanguage = $this->getdefaultlanguage();
        $lang_name = strtolower($defaultlanguage->name);

        $default_title = $title[$lang_name];
        $default_description = $description[$lang_name];


        $create = Faq::create([
                    'faq_category_id' => $faq_category_id,
                    'title' => $default_title,
                    'status' => $status,
                    'description' => $default_description,
                    'languagecode_id' => $defaultlanguage->id,
                ]);

        if($create)
        {
            $result_id = $create->id;
            Faq::where('id',$result_id)->update(['faq_id' => $result_id]);            
            unset($languagecode[$lang_name]);
        }

        foreach ($languagecode as $key => $value) 
        {

            if(!empty($value))
            {
                $titles = isset($title[$key]) ? $title[$key] : $default_title;
                $descriptions = isset($description[$key]) ? $description[$key] : $default_description;
                
                $create = Faq::create([
                    'faq_category_id'=>$faq_category_id,
                    'title' => $titles,
					'status' => $status,
                    'faq_id' => $result_id,
                    'parent_id' => $result_id,
					'description' => $descriptions,
                    'languagecode_id' => $value,
                ]);
            }
        }

        return redirect(route('faqs'))->with('success', trans('messages.FAQ Has  been successfully added'));
    }

    

    public function show($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'faq', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
		
        $default_language_id = $this->defaultlanguageId();
        $languagecodes = $this->languagecodes();
		$maincategories = Faqcategory::where('languagecode_id', $default_language_id)->get();
        $slides = Faq::with('getLanguage')->where('faq_id',$id)->get();
        
		return view('admin.Faq.edit', compact('languagecodes','slides','maincategories'));

    }
    
    public function update(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'faq', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        // echo '<pre>'; print_r($request->all());die;

        $languagecodes = $this->languagecodes();
        $slide = Faq::find($request->slide_id);
        $this->validateadsData($request);
                   
        $faq_category_id = request('faq_category_id') ? request('faq_category_id') : 0;
        $title = request('title');
        $status = request('status') ? true : false;
        $description = request('description');
        $languagecode = request('languagecode'); 

        $defaultlanguage = $this->getdefaultlanguage();
        $lang_name = strtolower($defaultlanguage->name);

        $default_title = $title[$lang_name];
        $default_description = $description[$lang_name];

        $create =   Faq::where('id',$request->slide_id)->update([
            'faq_category_id'=> $faq_category_id,
            'title' => $default_title,
            'status' => $status,
            'faq_id' => $request->slide_id,
            'description' => $default_description,
            'languagecode_id' => $defaultlanguage->id,
        ]);

        
        return redirect(route('faqs'))->with('success', trans('messages.FAQ has  been successfully updated'));
        
    }

    public function destroy($id)
    {
        
        if(!$this->checkPermission(Auth::user()->role_id, 'faq', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $delete = Faq::where([['id','=',$id]])->delete();
        if($delete)
        {
            return redirect(route('faqs'))->with('success', trans('messages.FAQ has been successfully deleted'));
        }
        return redirect(route('faqs'))->with('success', trans('messages.FAQ could not be deleted'));

    }

    public function updatestatus(Request $request)
    {
        if($request->ajax())
        {
            if(!$this->checkPermission(Auth::user()->role_id, 'faq', 'is_edit'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                exit();
            }

            $output = array('success' => '', 'error' => '');
            
            $status = request('status') ? false : true;
            $id = request('id');
            $update = Faq::where('faq_id', $id)->update(['status' => $status]);

            if($update)
            {
                $output['success'] = trans('messages.status_updated_successfully');
            }
            else
            {
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }

}