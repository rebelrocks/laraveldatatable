<?php

namespace App\Http\Controllers\Admin\Socialinks;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Lang;
use App\User;
use App\Models\Sociallink;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;

class SocialinksController extends Controller
{
    use checkermissionsTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sociallinks', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $sociallinks = Sociallink::orderBy('sort_order', 'asc')->get(['id', 'name', 'value', 'label', 'sort_order', 'status']);
        
        return view('admin.sociallinks.sociallinks', compact('sociallinks'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sociallinks', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $sociallinks = request('name');
        $statusdata = request('status');

        //Update social links
        foreach ($sociallinks as $key => $value)
        {
            $status = $statusdata[$key] ?? 0;
            Sociallink::where('id', $key)->update(['value' => $value, 'status' => $status]);
        }
         
        return back()->with('success', trans('messages.social_links_updated'));

    }

    
}
