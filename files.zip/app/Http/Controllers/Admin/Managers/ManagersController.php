<?php

namespace App\Http\Controllers\Admin\Managers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Admin\AddmanagerRequest;
use App\Http\Requests\Admin\UpdatelanguageRequest;
use App\Models\Manager;
use App\Models\Site_permission;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;
use App\Traits\Helper\HelperTrait;

class ManagersController extends Controller
{
    use checkermissionsTrait, HelperTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'managers', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $managers = Manager::all();

        return view('admin.managers.managers', compact('managers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'managers', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return view('admin.managers.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddmanagerRequest $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'managers', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $manager_name = strtolower(request('name'));
        $create = Manager::create([
            'name' => $manager_name,
            'status' => request('status')
        ]);

        if($create){

            //add site premissions
            $roles = $this->roles();
            foreach ($roles as $role) {
                Site_permission::create([
                    'role_id' => $role->id,
                    'manager_id' => $create->id,
                    'is_read' => false,
                    'is_add' => false,
                    'is_edit' => false,
                    'is_delete' => false,
                    'status' => false,
                ]);
            }

            return redirect(route('managers'))->with('success', trans('messages.New Manager Created Successfully'));

        }

        return back()->with('warning', trans('messages.oops'));


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'managers', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return Manager::findOrFail($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'managers', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return abort(403);
        
        exit();
        
        $manager = $this->show($id);

        return view('admin.managers.edit', compact('manager'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'managers', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return abort(403);
        
        exit();

        //request validate data
        $request->validate([
            'name' => 'required|string|max:191|unique:managers,name,'.$id, 
            'status' => 'required|boolean', 
        ]);

        //Check manager detail exit or not
        $this->show($id);

        $update = Manager::where('id', $id)->update([
            'name' => request('name'),
            'status' => request('status')
        ]);

        if($update){

            return redirect(route('managers'))->with('success', trans('messages.Manager Updated Successfully'));

        }

        return back()->with('warning', trans('messages.oops'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'managers', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return abort(403);

        exit();
        $delete = $this->show($id);
        //Check site permission
        $check = Site_permission::where('manager_id', $id)->count();
        if($check){
            return back()->with('error', 'Manager associated with site permission.');
            exit();
        }

        $delete->delete();

        return back()->with('success', trans('messages.manager_deleted_successfully'));
    }
}
