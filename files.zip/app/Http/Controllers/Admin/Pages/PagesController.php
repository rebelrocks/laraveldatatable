<?php

namespace App\Http\Controllers\Admin\Pages;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use App\Models\Page;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;

class PagesController extends Controller
{

    use checkermissionsTrait, LanguagecodeTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $defaultlanguage = $this->getdefaultlanguage();
        $pages = Page::whereLanguagecode_id($defaultlanguage->id)->latest()->get();

        return view('admin.pages.pages', compact('pages'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $page = $this->getpageDetail($id);

        //Check page exit or not
        if(!$page){

            return redirect(route('cms_pages'))->with('warning', trans('messages.page_not_found'));

        }

        $languagecodes = $this->languagecodes(); 

        return view('admin.pages.edit', compact('page', 'languagecodes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecode_name = request('languagecode_name');

        $request->validate([
            'title.*' => 'nullable|required_if:local.*,1|string',
            'content.*' => 'nullable|required_if:local.*,1|string',
            'status.*' => 'boolean',
        ]);

        $title = request('title');
        $content = request('content');
        $page_id = request('page_id');
        $status = request('status');

        $languagecode = request('languagecode');

        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);

        $default_title = '';
        $default_content = '';
        $default_status = '';

        foreach ($languagecode as $key => $value)
        {

            //Check if title is empty
            if(empty($title[$key])){
                $default_title = $title[$lang_name];
            }

            //Check if content is empty
            if(empty($content[$key])){
                $default_content = $content[$lang_name];
            }

            //Check if status is empty
            if(empty($content[$key])){
                $default_status = $status[$lang_name] ?? false;
            }

            $page_title = $title[$key] ?? $default_title;
            $page_content = $content[$key] ?? $default_content;
            $page_status = $status[$key] ?? $default_status;

            if(empty($page_id[$key])){

                $update = Page::create([
                    'title' => $page_title,
                    'content' => $page_content,
                    'status' => $page_status,
                    'languagecode_id' => $value,
                    'slug' => Str::slug($page_title),
                    'page_id' => request('parent_id'),
                ]);

            }else{

                $update = Page::where('id', $page_id[$key])->update([
                    'title' => $page_title,
                    'content' => $page_content,
                    'status' => $page_status,
                    //'slug' => Str::slug($page_title)
                ]);

            }


        }

        return redirect(route('cms_pages'))->with('success', trans('messages.your_page_has_been_updated'));

        exit();

        if(!empty(request('page_id'))){

            $update = Page::where('id', $id)->update([
                'title' => $title,
                'content' => $content,
                'status' => $status,
            ]);

        }else{

            $parent_id = Page::find($id);

            $update = Page::create([
                'title' => $title,
                'content' => $content,
                'status' => $status,
                'languagecode_id' => request('languagecode'),
                'page_id' => $parent_id->page_id,
            ]);

        }
        
        if($update){

            return redirect(route('cms_pages'))->with('success', trans('messages.your_page_has_been_updated'));

        }   

        return back()->with('warning', trans('messages.page_not_found'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateold(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecode_name = request('languagecode_name');

        $request->validate([
            'title_'.$languagecode_name => 'required|unique:pages,title,'.$id,
            'content_'.$languagecode_name => 'required|string',
            'status_'.$languagecode_name => 'boolean',
        ]);

        $title = request('title_'.$languagecode_name);
        $content = request('content_'.$languagecode_name);
        $status = request('status_'.$languagecode_name) ? : false;
        if(!empty(request('page_id'))){

            $update = Page::where('id', $id)->update([
                'title' => $title,
                'content' => $content,
                'status' => $status,
            ]);

        }else{

            $parent_id = Page::find($id);

            $update = Page::create([
                'title' => $title,
                'content' => $content,
                'status' => $status,
                'languagecode_id' => request('languagecode'),
                'page_id' => $parent_id->page_id,
            ]);

        }
        
        if($update){

            return redirect(route('cms_pages'))->with('success', trans('messages.your_page_has_been_updated'));

        }   

        return back()->with('warning', trans('messages.page_not_found'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatestatus(Request $request, $id)
    {
        if($request->ajax()){

            //Check permission access or not
            if(!$this->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_edit'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                    exit();
            }

            $output = array('success' => '', 'error' => '');
            
            $status = request('status') ? false : true;
            
            $update = Page::where('id', $id)->update(['status' => $status]);

            if($update){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }
}
