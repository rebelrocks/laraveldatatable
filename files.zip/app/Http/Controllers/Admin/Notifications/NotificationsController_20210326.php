<?php

namespace App\Http\Controllers\Admin\Notifications;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use \Mailjet\Resources;
use App\Models\Notification;
use App\Models\Userdevice;
use App\Models\Usernotification;
use App\Models\Notificationsentrecord;
use App\Models\Category;
use App\User;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;
use Helper;
use App\Traits\Sociallink\SociallinkTrait;
use App\Traits\GeneralsettingTrait;
use App\Traits\Mailjet\MailjetTrait;
use App\Traits\LanguagecodeTrait;

class NotificationsController extends Controller
{
    use checkermissionsTrait, SociallinkTrait, GeneralsettingTrait, MailjetTrait, LanguagecodeTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin')->except(['sendpushnotification']);
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $defaultlanguage = $this->getdefaultlanguage();
        $notifications = Notification::whereLanguagecode_id($defaultlanguage->id)->latest()->get();

        return view('admin.notifications.notifications', compact('notifications'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $languagecodes = $this->languagecodes();
        return view('admin.notifications.create', compact('languagecodes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    /*public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $request->validate([
            'address' => 'required|string|max:191',
            'user_type' => 'required|in:1,2,single',
            'title.*' => 'nullable|required_if:local.*,1|string|max:191',
            'link.*' => 'nullable|required_if:local.*,1|string|max:191|url',
            'description.*' => 'nullable|required_if:local.*,1|string',
			'totalusercount' => 'required|numeric|not_in:0',
        ],[
            'title.*.required_if' => trans('messages.This field is required'),
            'description.*.required_if' => trans('messages.This field is required'),
            'link.*.required_if' => trans('messages.This field is required'),
        ]);

        $address = request('address') ? : NULL;
        $user_type = request('user_type') ? : NULL;
        $title = request('title') ? : NULL;
        $link = request('link') ? : NULL;
        $message = request('description') ? : NULL;
        $lat = request('latitude') ? : NULL;
        $lng = request('longitude') ? : NULL;
        $rad = request('srcradiusius') ? : NULL;
        
        $circle_radius = 6371;
        $languagecode = request('languagecode');

        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);
        $default_title = '';
        $default_description = '';
        $default_link = '';
        foreach ($languagecode as $key => $value) {

            //Check if title is empty
            if(empty($title[$key])){
                $default_title = $title[$lang_name];
            }
            
            //Check if description is empty
            if(empty($message[$key])){
                $default_description = $message[$lang_name];
            }

            //Check if description is empty
            if(empty($link[$key])){
                $default_link = $link[$lang_name];
            }

            $n_title = isset($title[$key]) ? $title[$key] : $default_title;
            $n_message = isset($message[$key]) ? $message[$key] : $default_description;
            $n_link = isset($link[$key]) ? $link[$key] : $default_link;
			
			switch ($value)
			{
				case 1:
					$en_title=$n_title;
					$en_message=$n_message;
					$en_link=$n_link;					
				break;
				case 2:
					$fr_title=$n_title;
					$fr_message=$n_message;
					$fr_link=$n_link;					
				break;
				case 3:
					$de_title=$n_title;
					$de_message=$n_message;
					$de_link=$n_link;					
				break;
			}

            $create = Notification::create([
                'languagecode_id' => $value,
                'description' => $n_message,
                'role_id' => $user_type-1,
                'title' => $n_title,
                'address' => $address,
                'latitude' => $lat,
                'longitude' => $lng,
                'link' => $n_link,
            ]);
			
			//Get Parent ID
			$parent_id = $request->session()->get('noti_parent_id');

			if(empty($request->session()->get('noti_parent_id'))){
				// Via a request instance...
				$parent_id =  $request->session()->put('noti_parent_id', $create->id);
			}

			//Check parent ID value
			if(empty($parent_id)){
				$parent_id = $create->id;   
			}
			
			//Update parent ID
			Notification::where('id', $create->id)->update([
				'parent_id' => $parent_id
			]);
			
        }

        if($create){ 

            $notification_user_type = $user_type-1;
			
            //Get users
            switch($notification_user_type){
                case '0':
					$users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as distance FROM user_devices INNER JOIN users on users.id = user_devices.user_id where users.status=1 && (users.role_id=1 OR users.role_id=2) Having `distance` < "'.$rad.'")');
                break;
                case '1':  
                    $users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as distance FROM user_devices INNER JOIN users on users.id = user_devices.user_id where users.status=1 && users.role_id="'.$notification_user_type.'" Having `distance` < "'.$rad.'")');
                break;             
                case '2':
                    $users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as distance FROM user_devices INNER JOIN users on users.id = user_devices.user_id where users.status=1 && users.role_id="'.$notification_user_type.'" Having `distance` < "'.$rad.'")');
                break;
				// case '3':
				// 	$users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as distance FROM user_devices INNER JOIN users on users.id = user_devices.user_id where users.status=1 && users.role_id="'.$notification_user_type.'" Having `distance` < "'.$rad.'")');
                // break;
                // case '4':
				// 	$users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as `distance` FROM `user_devices` Having `distance` < "'.$rad.'")');
            }

            if(!empty($users)){

                $notidata = $users;
                
				//Check if title is empty
				$default_title = $title[$lang_name];				
				//Check if description is empty
				$default_description = $message[$lang_name];
				//Check if description is empty
				$default_link = $link[$lang_name];
			
                foreach ($notidata as $UserDeviceData)
                {					
                    $user_id = $UserDeviceData->user_id;
                    $user_role = $UserDeviceData->role_id;
                    $all_get_notifications_user_id[]= $user_id;
                    if($user_id==0){
                        $all_get_notifications_user_id[]= 'b2c'.$UserDeviceData->id;
                        $user_role = 4;
                    }
					
					$title = isset($title[$UserDeviceData->languagecode_id]) ? $title[$UserDeviceData->languagecode_id] : $default_title;
					$message = isset($message[$UserDeviceData->languagecode_id]) ? $message[$UserDeviceData->languagecode_id] : $default_description;
					$link = isset($link[$UserDeviceData->languagecode_id]) ? $link[$UserDeviceData->languagecode_id] : $default_link;
					
                    $token = $UserDeviceData->device_token;
					
					
                    $data = [
                                'badge' => 0,
                                'title' => $title,
                                'message' => $message,
                                'url' => $link,
                                'user_id' => $user_id,
                                'fromuser_id' => 1,
                                'notify_type' => 'adminNotify'
                            ];

                    $iosdata = [
                                'alert' => [
                                    'body' => $message,
                                    'title' => $title
                                ],
                                'url' => $link,
                                'user_id' => $user_id,
                                'fromuser_id' => 1,                               
                                'notify_type' => 'adminNotify'
                            ];


                    if($UserDeviceData->device_type=="Android"){
                        $PfplaArgument[]= array('device_type'=>"Android",'role'=>$user_role,"device_token"=>$token,"notification_data"=>$data);
                    }else if($UserDeviceData->device_type=="iOS" || $UserDeviceData->device_type=="ios" || $UserDeviceData->device_type=="IOS"){
                        $PfplaArgument[]= array('device_type'=>"ios",'role'=>$user_role,"device_token"=>$token,"notification_data"=>$iosdata);
                    }
                }
                    
                if(!empty($all_get_notifications_user_id))
                {
                    DB::table('notification_sent_records')->insert([
                        'message' => json_encode($PfplaArgument, JSON_UNESCAPED_UNICODE),
                        'notification_id' => $parent_id,
                        'user_ids' => implode(",",array_unique($all_get_notifications_user_id)),
                        'status' => false
                    ]);
                }
                  
            }
			// Forget session value...
			$request->session()->forget('noti_parent_id');
            return redirect(route('notifications'))->with('success',  trans('messages.save_notification'));
	    }   

        return back()->with('warning', trans('messages.oops'));

    }*/

    public function store(Request $request)
    {    
	    $PfplaArgument=array();
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $request->validate([
            'address' => 'required|string|max:191',
            'title.*' => 'nullable|required_if:local.*,1|string|max:191',
            'link.*' => 'nullable|required_if:local.*,1|string|max:191|url',
            'description.*' => 'nullable|required_if:local.*,1|string',
        ],[
            'title.*.required_if' => trans('messages.This field is required'),
            'description.*.required_if' => trans('messages.This field is required'),
            'link.*.required_if' => trans('messages.This field is required'),
        ]);

        $address = request('address') ? : NULL;
        $user_type = request('user_type') ? : NULL;
        $is_single_user=request('is_single_user') ? : NULL;
        $single_user_id=request('single_user') ? : NULL;
        $title = request('title') ? : NULL;
        $link = request('link') ? : NULL;
        $message = request('description') ? : NULL;
        $lat = request('latitude') ? : NULL;
        $lng = request('longitude') ? : NULL;
        $rad = request('srcradiusius') ? : NULL;
        
        $circle_radius = 6371;
        $languagecode = request('languagecode');

        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);
        $default_title = '';
        $default_description = '';
        $default_link = '';
        foreach ($languagecode as $key => $value) {

            //Check if title is empty
            if(empty($title[$key])){
                $default_title = $title[$lang_name];
            }
            
            //Check if description is empty
            if(empty($message[$key])){
                $default_description = $message[$lang_name];
            }

            //Check if description is empty
            if(empty($link[$key])){
                $default_link = $link[$lang_name];
            }

            $n_title = isset($title[$key]) ? $title[$key] : $default_title;
            $n_message = isset($message[$key]) ? $message[$key] : $default_description;
            $n_link = isset($link[$key]) ? $link[$key] : $default_link;
			
			switch ($value)
			{
				case 1:
					$en_title=$n_title;
					$en_message=$n_message;
					$en_link=$n_link;					
				break;
				case 2:
					$fr_title=$n_title;
					$fr_message=$n_message;
					$fr_link=$n_link;					
				break;
				case 3:
					$de_title=$n_title;
					$de_message=$n_message;
					$de_link=$n_link;					
				break;
			}
            
            if(!empty($is_single_user)){
                $single_user=User::where('id',$single_user_id)->first()->toArray();
                $modified_user_type=$single_user['role_id'];
            }else{
                $modified_user_type=$user_type-1;
            }
           
            $create = Notification::create([
                'languagecode_id' => $value,
                'description' => $n_message,
                'role_id' => $modified_user_type,
                'title' => $n_title,
                'address' => $address,
                'latitude' => $lat,
                'longitude' => $lng,
                'link' => $n_link,
            ]);
			
			//Get Parent ID
			$parent_id = $request->session()->get('noti_parent_id');

			if(empty($request->session()->get('noti_parent_id'))){
				// Via a request instance...
				$parent_id =  $request->session()->put('noti_parent_id', $create->id);
			}

			//Check parent ID value
			if(empty($parent_id)){
				$parent_id = $create->id;   
			}
			
			//Update parent ID
			Notification::where('id', $create->id)->update([
				'parent_id' => $parent_id
			]);
			
        }

        if($create){ 
            if(empty($is_single_user)){
                $notification_user_type = $user_type-1;
                
                //Get users
                switch($notification_user_type){
                    case '0':
                        $users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as distance FROM user_devices INNER JOIN users on users.id = user_devices.user_id where users.status=1 && (users.role_id=1 OR users.role_id=2 OR users.role_id=3) Having `distance` < "'.$rad.'")');
                    break;
                    case '1':               
                    case '2':
                    case '3':
                        $users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as distance FROM user_devices INNER JOIN users on users.id = user_devices.user_id where users.status=1 && users.role_id="'.$notification_user_type.'" Having `distance` < "'.$rad.'")');
                    break;
                    case '4':
                        $users = DB::select('(SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as `distance` FROM `user_devices` Having `distance` < "'.$rad.'")');
                }
            }else{
                
                $users = DB::select('SELECT *, (6371 * acos(cos( radians("'.$lat.'")) * cos( radians(`lat`)) * cos( radians(`lng`) - radians("'.$lng.'")) + sin(radians("'.$lat.'")) * sin(radians(`lat`)))) as distance FROM user_devices INNER JOIN users on users.id = user_devices.user_id where users.status=1 AND users.id='.$single_user_id.'');
                
            }

            #dd($users);
            if(!empty($users)){

                $notidata = $users;
                
				//Check if title is empty
				$default_title = $title[$lang_name];				
				//Check if description is empty
				$default_description = $message[$lang_name];
				//Check if description is empty
				$default_link = $link[$lang_name];
			
                foreach ($notidata as $UserDeviceData)
                {					
                    $user_id = $UserDeviceData->user_id;
                    $user_role = $UserDeviceData->role_id;
                    $all_get_notifications_user_id[]= $user_id;
                    if($user_id==0){
                        $all_get_notifications_user_id[]= 'b2c'.$UserDeviceData->id;
                        $user_role = 4;
                    }
					
					$title = isset($title[$UserDeviceData->languagecode_id]) ? $title[$UserDeviceData->languagecode_id] : $default_title;
					$message = isset($message[$UserDeviceData->languagecode_id]) ? $message[$UserDeviceData->languagecode_id] : $default_description;
					$link = isset($link[$UserDeviceData->languagecode_id]) ? $link[$UserDeviceData->languagecode_id] : $default_link;
					
                    $token = $UserDeviceData->device_token;
					
                    $data = [
                                'badge' => 0,
                                'title' => $title,
                                'message' => $message,
                                'url' => $link,
                                'user_id' => $user_id,
                                'fromuser_id' => 1,
                                'notify_type' => 'adminNotify'
                            ];

                    $iosdata = [
                                'alert' => [
                                    'body' => $message,
                                    'title' => $title
                                ],
                                'url' => $link,
                                'user_id' => $user_id,
                                'fromuser_id' => 1,                               
                                'notify_type' => 'adminNotify'
                            ];


                    if($UserDeviceData->device_type=="Android"){
                        $PfplaArgument[]= array('device_type'=>"Android",'role'=>$user_role,"device_token"=>$token,"notification_data"=>$data);
                    }else if($UserDeviceData->device_type=="iOS" || $UserDeviceData->device_type=="ios" || $UserDeviceData->device_type=="IOS"){
                        $PfplaArgument[]= array('device_type'=>"ios",'role'=>$user_role,"device_token"=>$token,"notification_data"=>$iosdata);
                    }
                }
                    
                if(!empty($all_get_notifications_user_id))
                {
                    DB::table('notification_sent_records')->insert([
                        'message' => json_encode($PfplaArgument, JSON_UNESCAPED_UNICODE),
                        'notification_id' => $parent_id,
                        'user_ids' => implode(",",array_unique($all_get_notifications_user_id)),
                        'status' => false
                    ]);
                }
                  
            }
			// Forget session value...
			$request->session()->forget('noti_parent_id');
            return redirect(route('notifications'))->with('success',  trans('messages.save_notification'));
	    }   

        return back()->with('warning', trans('messages.oops'));

    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
	public function userlist($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $notification = Notificationsentrecord::where('notification_id', $id)->first();
        
		/*if(!$notification){			
            return abort('404');
            exit();
        }*/
		
		if(!empty($notification->sent_user_ids)){
            $sent_user_ids = explode(',', $notification->sent_user_ids);
        }else{
            $sent_user_ids[] = '';
        }

        $users = User::where(function($query) use ($sent_user_ids) {
                                foreach($sent_user_ids as $term) {
                                    $query->orWhere('id', $term);
                                };
                            })
                            ->get(['id', 'first_name', 'last_name', 'profile_pic']);

        return view('admin.notifications.userlists', compact('users'));
    }
	
    public function show($id)
    {
		die("wdfwef");
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $notification = Notificationsentrecord::where('notification_id', $id)->first();
        
        if(!$notification){

            return abort('404');
            exit();
        }

        $all_message=json_decode($notification->message);
        
        $sent_user_ids = explode(',', $notification->sent_user_ids);

        $users = User::where(function($query) use($sent_user_ids) {
                                foreach($sent_user_ids as $term) {
                                    $query->orWhere('id', $term);
                                    //$query->orWhere('id', 'like', "%$term%");
                                };
                            })
                            ->get(['id', 'first_name', 'last_name', 'profile_pic']);

        return view('admin.notifications.userlists', compact('users'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function history($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $percentage = 0;
        $total = 0;
        $totalSend = 0;
        $totalFail = 0;
        $totalClick = 0;
        $total_notifications = 0;

        $notification = Notificationsentrecord::where('notification_id', $id)->first();

        $total = Notificationsentrecord::where('notification_id', $id)->count();

        if(!empty($notification->user_ids)){

            $total_user_ids = explode(",",$notification->user_ids);

        }else{

            //$total_user_ids[] = '';
            $total_user_ids = [];

        }
        
        if(!empty($notification->sent_user_ids)){
            $total_sent_user_ids = explode(",",$notification->sent_user_ids);
        }else{
            $total_sent_user_ids = array();
        }

        if(count($total_user_ids)){

            $percentage = (count(array_unique($total_sent_user_ids))/count(array_unique($total_user_ids)))*100;
        

            $total_notifications = array_merge($total_sent_user_ids, $total_user_ids);
        
            $total_notifications = count(array_unique($total_notifications));
        
        }

        if(!empty($notification->user_ids)){
            $remaining_notifications = explode(",",$notification->user_ids);
        }else{
            $remaining_notifications = array();
        }
        
        $remaining_notifications = count(array_unique($remaining_notifications));

        $sent_notifications = count(array_unique($total_sent_user_ids));

        return view('admin.notifications.notification-history', compact('total_notifications', 'remaining_notifications', 'sent_notifications', 'percentage', 'total'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notifications', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $notification = Notification::findOrFail($id);

        if(!$notification){

            return abort(404);
            
        }

        Usernotification::where('related_id', $id)->delete();
        Notificationsentrecord::where('notification_id', $id)->delete();
        Notification::where('id', $id)->delete();
        
        return back()->with('success',  trans('messages.notification_deleted'));
    }


    public function usercount(Request $request)
    {
        $latitude = request('lat');
        $longitude = request('lng');
        $srcradius = request('srcradius');
        $user_type = request('user_type');

        $circle_radius = 6371;
        $max_distance = $srcradius;
        $lat = $latitude; //'48.85102978373828';
        $lng = $longitude; //'2.3287323994022717';
		
		if($user_type==1){
			$candidates = DB::select(
				   'SELECT * FROM
						(SELECT lat, lng, (' . $circle_radius . ' * acos(cos(radians(' . $lat . ')) * cos(radians(lat)) *
						cos(radians(lng) - radians(' . $lng . ')) +
						sin(radians(' . $lat . ')) * sin(radians(lat))))
						AS distance
						FROM user_devices) AS distances
					WHERE distance < ' . $max_distance . '
					ORDER BY distance
					
				');
		}
		elseif($user_type==2){
			
			$candidates = DB::select('SELECT * FROM
						(SELECT lat, lng, (' . $circle_radius . ' * acos(cos(radians(' . $lat . ')) * cos(radians(lat)) *
						cos(radians(lng) - radians(' . $lng . ')) +
						sin(radians(' . $lat . ')) * sin(radians(lat))))
						AS distance
						FROM user_devices WHERE role_id = 1) AS distances
					WHERE distance < ' . $max_distance . '
					ORDER BY distance');
		}
		elseif($user_type==3){
			
			$candidates = DB::select('SELECT * FROM
						(SELECT lat, lng, (' . $circle_radius . ' * acos(cos(radians(' . $lat . ')) * cos(radians(lat)) *
						cos(radians(lng) - radians(' . $lng . ')) +
						sin(radians(' . $lat . ')) * sin(radians(lat))))
						AS distance
						FROM user_devices  WHERE role_id = 2) AS distances
					WHERE distance < ' . $max_distance . '
					ORDER BY distance');
		}
		elseif($user_type==4){
			
			$candidates = DB::select('SELECT * FROM
						(SELECT lat, lng, (' . $circle_radius . ' * acos(cos(radians(' . $lat . ')) * cos(radians(lat)) *
						cos(radians(lng) - radians(' . $lng . ')) +
						sin(radians(' . $lat . ')) * sin(radians(lat))))
						AS distance
						FROM user_devices WHERE role_id = 3) AS distances
					WHERE distance < ' . $max_distance . '
					ORDER BY distance');
		}else{
			$candidates = DB::select(
				   'SELECT * FROM
						(SELECT lat, lng, (' . $circle_radius . ' * acos(cos(radians(' . $lat . ')) * cos(radians(lat)) *
						cos(radians(lng) - radians(' . $lng . ')) +
						sin(radians(' . $lat . ')) * sin(radians(lat))))
						AS distance
						FROM user_devices) AS distances
					WHERE distance < ' . $max_distance . ' AND role_id = 1
					ORDER BY distance					
				');
		}

        return count($candidates);
    }



    /**
     * Send notification email cron.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function sendnotificationEmail(Request $request)
    {
        //Get support email
        $support_email_id = $this->getsupportEmail()->value ?? '';
        //Get contact email
        $contact_email_id = $this->getcontactEmail()->value ?? '';
        //Get sender email
        $senderemail = $this->getsenderEmail()->value ?? '';

        
        //Get week day name
        $getweekDay = strtolower(Carbon::now()->format( 'l' ));
        
        //Get current time
        $getcurrentTime = Carbon::now()->format('H:i');

        //Get app name
        $appname = Helper::getapplicationName();

        //Get notifications list
        $notifications = Notification::where('status', 0)->get();

        if(count($notifications)){

            foreach ($notifications as $notification) 
            {
                //
                $notification_sent_records = DB::table('notification_sent_records')
                                            ->where('notification_id', $notification->id)
                                            ->where('status', 0)
                                            ->first();

                //$messages_array = $notification_sent_records->message;

                //$json_array = json_decode($messages_array, true);

                $user_ids = explode(",", $notification_sent_records->user_ids);

                foreach ($user_ids as $key => $value)
                {
                    
                    //Get user detail
                    $user = User::where('id', $value)->first();

                    if($user)
                    {
                        //check user email
                        if(!empty($user->email)){

                            try {

                                if(config('app.email_send')==true){
                                    //Send email                                
                                    //$this->mailjetEmail($senderemail, $appname, $notification->title, $notification->description, $user->email);
                                }
                                
                                //Update notification sent record
                                $user_id = $user->id;
                                $all_get_notifications_user_id[]= $user_id;

                                unset($user_ids[$key]);

                                //unset($json_array[$key]);

                                //$device_data_array = json_encode($json_array, true);

                                if(!empty($all_get_notifications_user_id))
                                {
                                    DB::table('notification_sent_records')->where('id', $notification_sent_records->id)->update([
                                        'user_ids' => implode(",",array_unique($user_ids)),
                                        'sent_user_ids' => implode(",",array_unique($all_get_notifications_user_id)),
                                        'status' => true
                                    ]);
                                }

                            } catch (\Exception $e) {

                            }
                        }                            
                    }                    
                }                
            }
        }

        return redirect(route('notifications'))->with('success', trans('messages.notification_sent_successfully'));
    }


	public function sendpushnotification(Request $request)
    {
        $notification_data = DB::table('notification_sent_records')
                            ->where('status', false)
                            ->orderBY('id',  'desc')
                            ->get();

        foreach($notification_data as $notification){
            
            $all_message= json_decode($notification->message);        
            $total_user_ids = explode(",",$notification->user_ids);
            
            if(!empty($notification->sent_user_ids)){
                $total_sent_user_ids = explode(",",$notification->sent_user_ids);
            }else{
                $total_sent_user_ids = array();
            }
            
            $PfplaArgument =array();    
            
            $UserNotifications = DB::table('user_notifications');      
            
            foreach($all_message as $key=> $all_message_data){       
                
                if($all_message_data->device_type=="Android" && $key<=30){

                    $total_sent_user_ids[]= $all_message_data->notification_data->user_id;
                    
                    $androiddata = (array)$all_message_data->notification_data;
                    
                    $userNotifications_data = DB::table('user_notifications')->where('related_id', $notification->notification_id)
                        ->where(['model'=> 'Notification', 'user_id'=> $androiddata['user_id'], 'related_id' => $notification->notification_id])
                        ->orderBy('id', 'desc')
                        ->first();
                    
                    if (empty($userNotifications_data)) {

                        $create = DB::table('user_notifications')->insert([
                            'user_id' => $androiddata['user_id'],
                            'related_id' => $notification->notification_id,
                            'model' => 'Notification',                         
                            'status' => 1,    
                            'notification' => $androiddata['message'],
                            'form_user_id' => 1,
                            'to_user_id' => $androiddata['user_id'],
                        ]);                        
                    }
                    
                    $token = $all_message_data->device_token;               
                    //dd($token);
                    $results = $this->pushAndroid($token, $androiddata);
					
					/* echo '<pre>';
					print_r($results);
					exit; */
                }else if(strtolower($all_message_data->device_type)=="ios" && $key<=30){
                    
                    $total_sent_user_ids[]= $all_message_data->notification_data->user_id;
                    
                    $iosdata = json_decode(json_encode($all_message_data->notification_data), true);
                    
                    $token = $all_message_data->device_token;               
                    
                    $userNotifications_data = DB::table('user_notifications')->where('related_id', $notification->notification_id)
                        ->where(['model'=> 'Notification', 'user_id'=> $iosdata['user_id'], 'related_id' => $notification->notification_id])
                        ->orderBy('id', 'desc')
                        ->first();

                    if (empty($userNotifications_data)) {
                        
                        $create = DB::table('user_notifications')->insert([
                            'user_id' => $iosdata['user_id'],
                            'related_id' => $notification->notification_id,
                            'model' => 'Notification',                         
                            'status' => 1,    
                            'notification' => $iosdata['alert']['body'],
                            'form_user_id' => 1,
                            'to_user_id' => $iosdata['user_id'],
                        ]); 
                    }

                    $this->pushIOS($token,$iosdata,0);
                                             
                }
                
                if($key >=31){

                    if($all_message_data->device_type=="Android"){

                        $data = $all_message_data->notification_data;   
                        $token = $all_message_data->device_token;
                        $PfplaArgument[]= array('device_type'=>"Android","device_token"=>$token,"notification_data"=>$data);

                    }else if(strtolower($all_message_data->device_type)=="ios"){
                        
                        $iosdata = $all_message_data->notification_data;    
                        $token = $all_message_data->device_token;
                        $PfplaArgument[]= array('device_type'=>"Android","device_token"=>$token,"notification_data"=>$iosdata);

                    }
                }
            }   
                    
            if(!empty($total_sent_user_ids)){   
                
                DB::table('notification_sent_records')->where('id', $notification->id)->update([
                        'message' => json_encode($PfplaArgument, JSON_UNESCAPED_UNICODE),
                        'sent_user_ids' => implode(",", array_unique($total_sent_user_ids))
                ]);
            }

            if(count($total_user_ids) == count(array_unique($total_sent_user_ids))){
                
                DB::table('notification_sent_records')->where('id', $notification->id)->update([
                        'status' => 1
                ]);  
            }
        }
		
		echo 'Notification sent successfully.';
    }


}
