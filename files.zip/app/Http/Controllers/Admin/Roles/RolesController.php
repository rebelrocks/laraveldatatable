<?php

namespace App\Http\Controllers\Admin\Roles;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;
use App\Traits\SitepermissionsTrait;
use App\Models\Role;
use App\Models\Manager;
use App\Models\Permission;
use App\Models\Site_permission;

class RolesController extends Controller
{
    
    use checkermissionsTrait, SitepermissionsTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'roles', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Check permission access or not
        /*if(!$this->checkPermission(Auth::user()->role_id, 'roles', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }*/

        $roles = Role::orderBy('id', 'asc')->where('status', 1)->paginate(10);

        return view('admin.roles.roles', compact('roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'roles', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return view('admin.roles.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'roles', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $request->validate([
            'role' => 'required|string|max:191|unique:roles,name',
        ]);

        $role = request('role');
        $slug = Str::slug($role, '_');

        $create = Role::create(['name' => $role, 'slug' => $slug,'status'=>1]);

        if($create)
        {
            //check role exit or not
            $site_permission = Site_permission::where('role_id', $create->id)->count();

            if(!$site_permission)
            {
                //add site premissions
                $managers = $this->managers();
                foreach ($managers as $manager) 
                {
                    Site_permission::create([
                        'status' => false,
                        'is_add' => false,
                        'is_read' => false,
                        'is_edit' => false,
                        'role_id' => $create->id,
                        'is_delete' => false,
                        'manager_id' => $manager->id,
                    ]);
                }
            }
        }
        return redirect(route('roles'))->with('success', trans('messages.new_role_add'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'roles', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $role = Role::findOrFail($id);
        return view('admin.roles.edit', compact('role'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'roles', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $request->validate([
            'role' => 'required|string|max:191|unique:roles,name,'.$id,
        ]);

        $managers = $this->managers();
        $role = request('role');
        $slug = Str::slug($role, '_');

        $update = Role::where('id', $id)->update(['name' => $role, 'slug' => $slug]);
        if($update)
        {
            foreach ($managers as $m_key => $m_value) 
            {
                $site_permission = Site_permission::where('role_id', $id)->where('manager_id',$m_value->id)->first();
                if (empty($site_permission)) 
                {
                    Site_permission::create([
                        'status' => false,
                        'is_add' => false,
                        'is_read' => false,
                        'is_edit' => false,
                        'role_id' => $id,
                        'is_delete' => false,
                        'manager_id' => $m_value->id,
                    ]);
                }
                
            }

        }

        return redirect(route('roles'))->with('success', trans('messages.role_update'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'roles', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        if($id < 16){
            return redirect(route('admin_dashboard'))->with('warning', trans('This is default role you can not delete default roles'));
            exit;
        }
        $role = Role::findOrFail($id);
        #Delete site permission
        Site_permission::where('role_id', $id)->delete();
        $role->delete();
        return redirect(route('roles'))->with('success', trans('messages.role_delete'));
    }
}
