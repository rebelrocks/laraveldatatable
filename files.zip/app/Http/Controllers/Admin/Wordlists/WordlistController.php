<?php

namespace App\Http\Controllers\Admin\Wordlists;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Http\Requests\Admin\AddwordsRequest;
use App\Http\Requests\Admin\WordlistupdateRquest;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use App\Traits\checkermissionsTrait;
use App\Traits\Helper\HelperTrait;
use App\Models\Wordlist;

class WordlistController extends Controller
{
    use LanguagecodeTrait, checkermissionsTrait, HelperTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecode = Session::get('locale');
        
        $languagecodedetail = Languagecode::where('code', $languagecode)->first();
        if(!empty($languagecodedetail->id)){
            $wordlists = Wordlist::where('languagecode_id', $languagecodedetail->id)->groupBy('key_name')->orderBy('id', 'asc')->paginate(10);
        }else{
            $wordlists = Wordlist::groupBy('key_name')->orderBy('id', 'asc')->paginate(10);    
        }
        
        return view('admin.wordlists.wordlists', compact('wordlists'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function wordlists(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        if(request()->ajax()) {


            ## Read value
            $draw = request('draw');
            $row = request('start');
            $rowperpage = request('length'); // Rows display per page
            $columnIndex = request('order')[0]['column']; // Column index
            $columnName = request('columns')[$columnIndex]['data']; // Column name
            $columnSortOrder = request('order')[0]['dir']; // asc or desc
            $searchValue = request('search')['value']; // Search value

            ## Search 
            $searchQuery = " ";
            if($searchValue != ''){
               $searchQuery = " and (key_value like '%".$searchValue."%' or 
                    key_name like '%".$searchValue."%') ";
            }
            
            //Get default language
            $defaultlanguage = $this->getdefaultlanguage();
            ## Total number of records without filtering

            //$sel  = DB::select("select * from `wordlists` GROUP BY `key_name` ");
           $sel = DB::select("select * from `wordlists` WHERE 1 ".$searchQuery." &&  `languagecode_id` = ".$defaultlanguage->id."");

            $totalRecords = count($sel);

            ## Total number of record with filtering
            $sel = DB::select("select * from `wordlists` WHERE 1 ".$searchQuery." &&  `languagecode_id` = ".$defaultlanguage->id."");

            $totalRecordwithFilter = count($sel);
            
            ## Fetch records
            
            //$wordlists = DB::select("select * from `wordlists` WHERE 1 ".$searchQuery." &&  `languagecode_id` = ".$defaultlanguage->id." GROUP BY `key_name` order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage);
            $wordlists = DB::select("select * from `wordlists` WHERE 1 ".$searchQuery." &&  `languagecode_id` = ".$defaultlanguage->id." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage);
            
            $data = array();
            $are_you_sure_want_to_delete = "'".trans('messages.are_you_sure_want_to_delete')."'";
            $change_status = "'".trans('messages.change_status')."'";

            foreach($wordlists as $wordlist){

                //Get language code name
                $lngdetail = $this->languagecode($wordlist->languagecode_id);
                $languagecodename = '-';
                if(!empty($lngdetail->name)){
                    $languagecodename = $lngdetail->name;     
                }

                $languagecode = '<span class="btn btn-success">'.$languagecodename.'</span>';

                //Status
                $status_class = $wordlist->status == 1 ? 'success' : 'danger';
                
                $status = $wordlist->status == 1 ? trans('messages.statusactive') : trans('messages.statusinactive');

                $status = '<a id="atag'.$wordlist->id.'" class="btn btn-'.$status_class.'" data-id="'.$wordlist->id.'" data-val="'.$wordlist->key_name.'" data-status="'.$wordlist->status.'" href="javascript:;" onclick="updateStatus(this)">'.$status.'</a>';

                //Actions
                $actions = '';
                $actions .='<a href="'.route('edit_word_detial', $wordlist->id).'" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>';

                $actions .='<a href="'.route('delete_wordlist', $wordlist->key_name).'" class="btn btn-danger" onclick="return confirm('.$are_you_sure_want_to_delete.')"><i class="material-icons">clear</i> SUPPRIMER</a>';

                $data[] = array( 
                    "key_name"=>$wordlist->key_name,
                    "key_value"=>$wordlist->key_value,
                    "language_code"=>$languagecode,
                    "status"=>$status,
                    "action"=>$actions
                );
            }

            ## Response
            $response = array(
              "draw" => intval($draw),
              "iTotalRecords" => $totalRecordwithFilter,
              "iTotalDisplayRecords" => $totalRecords,
              "aaData" => $data
            );

            echo json_encode($response);

            exit();
        }

    }    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecodes = $this->languagecodes();

        return view('admin.wordlists.create', compact('languagecodes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddwordsRequest $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $key_name = request('key_name');
        $key_value= request('word');
        $status = false;

        $languagecode = request('languagecode');
        
        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);

        if(request('status')){
            $status = true;
        }

        $default_word = '';

        if(is_array($key_value)){
            
            foreach ($languagecode as $key => $value) {
                
                //Check if title is empty
                if(empty($key_value[$key])){
                    $default_word = $key_value[$lang_name];
                }

                $word = $key_value[$key] ?? $default_word;

                if(!empty($word) && !empty($value)){
                    $create = new Wordlist;
                    $create->key_name = Str::slug($key_name, '_');
                    $create->key_value = $word;
                    $create->languagecode_id = $value;
                    $create->status = $status;
                    $create->save();
                }

                //Get Parent ID
                $parent_id = $request->session()->get('parent_id');

                if(empty($request->session()->get('parent_id'))){

                    // Via a request instance...
                    $parent_id =  $request->session()->put('parent_id', $create->id);

                }

                //Check parent ID value
                if(empty($parent_id)){
                    $parent_id = $create->id;   
                }
                
                //Update parent ID
                Wordlist::where('id', $create->id)->update([
                    'wordlist_id' => $parent_id
                ]);

            }
            
        }

        // Forget session value...
        $request->session()->forget('parent_id');

        return redirect(route('wordlists'))->with('success', trans('messages.new_word_detail_add'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $word_detail = Wordlist::findOrFail($id);

        return $word_detail;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $word_detail = $this->show($id);
        $languagecodes = $this->languagecodes();
        return view('admin.wordlists.edit', compact('word_detail', 'languagecodes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(WordlistupdateRquest $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $word_detail = $this->show($id);

        $key_name = request('key_name');
        $key_value= request('word');
        $word_id= request('word_id');

        $status = false;
        if(request('status')){
            $status = true;
        }

        $languagecode = request('languagecode');
        
        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);
        $lang_id = $defaultlanguage->id;

        $default_word = '';

        if(is_array($key_value)){

            foreach ($languagecode as $key => $value) {
                //Check if title is empty
                if(empty($key_value[$key])){
                    $default_word = $key_value[$lang_id];
                }

                $word = $key_value[$key] ?? $default_word;

                if(empty($word_id[$key])){
                        
                        $create = new Wordlist;
                        $create->key_name = Str::slug($key_name, '_');
                        $create->key_value = $word;
                        $create->languagecode_id = $value;
                        $create->status = $status;
                        $create->wordlist_id = request('parent_id');
                        $create->save();

                }else{
                        if(!empty($word_id[$key])){
                            $update = Wordlist::where('id', $word_id[$key])->update([
                               'key_name' =>  Str::slug($key_name, '_'),
                               'key_value' =>  $word,
                               'languagecode_id' =>  $value,
                               'status' =>  $status,

                            ]);
                        }
                }
            }
            
        }

        return redirect(route('wordlists'))->with('success', trans('messages.word_detail_update'));

        exit();
        //Old Code
        /*if(is_array($key_value)){
            foreach ($key_value as $key => $value) {
                if(!empty($key) && !empty($value) && !empty($word_id[$key])){
                    $update = Wordlist::find($word_id[$key]);
                    $update->key_name = Str::slug($key_name, '_');
                    $update->key_value = $value;
                    $update->languagecode_id = $key;
                    $update->status = $status;
                    $update->update();
                }    
            }
            
        }*/

        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        Wordlist::where('key_name', $id)->delete();

        return redirect()->back()->with('success', trans('messages.word_list_deleted'));
    }

    /**
     * Update the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function status(Request $request, $id)
    {
        if($request->ajax()){

            //Check permission access or not
            if(!$this->checkPermission(Auth::user()->role_id, 'wordlists', 'is_edit'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                exit();
            }

            $output = array('success' => '', 'error' => '');

            $wordlists = Wordlist::where('key_name', $id)->get();
            
            foreach ($wordlists as $wordlist)
            {
                $word = Wordlist::find($wordlist->id);

                $new_status = $word->status ? false : true;

                Wordlist::where('id', $word->id)->update(['status' => $new_status]);
            }

            //get detail
            $detail = Wordlist::where('key_name', $id)->first();
            
            //Status
            $status_class = $detail->status == 1 ? 'success' : 'danger';
                
            $status = $detail->status == 1 ? trans('messages.statusactive') : trans('messages.statusinactive');
                
            $html = '<a id="atag'.$detail->id.'" class="btn btn-'.$status_class.'" data-id="'.$detail->id.'" data-val="'.$detail->key_name.'" data-status="'.$detail->status.'" href="javascript:;" onclick="updateStatus(this)">'.$status.'</a>';

            if($detail){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }
}
