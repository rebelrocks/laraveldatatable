<?php

namespace App\Http\Controllers\Admin\Actualites;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Traits\UploadTrait;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Helper;

class Datasources extends Controller
{
    use checkermissionsTrait, UploadTrait, LanguagecodeTrait;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){

    }
}