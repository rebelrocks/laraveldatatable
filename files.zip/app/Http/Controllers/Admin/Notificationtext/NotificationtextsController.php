<?php

namespace App\Http\Controllers\Admin\Notificationtext;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Models\Notificationtext;
use App\Traits\checkermissionsTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;

class NotificationtextsController extends Controller
{
    use checkermissionsTrait, LanguagecodeTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notificationtext', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //$languagecode_id = $this->languagecodeID();
        $defaultlanguage = $this->getdefaultlanguage();    
        $notifications = Notificationtext::whereLanguage($defaultlanguage->id)->paginate(20);
        
        return view('admin.notificationstext.notificationstext', compact('notifications'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notificationtext', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecodes = $this->languagecodes();
        $defaultlanguage = $this->getdefaultlanguage();
        return view('admin.notificationstext.create', compact('languagecodes', 'defaultlanguage'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notificationtext', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }        

        $request->validate([
            'title.*' => 'nullable|required_if:local.*,1|string|max:191',
            'description.*' => 'required_if:local.*,1',
        ],[
            'title.*.required_if' => trans('messages.This field is required'),
            'description.*.required_if' => trans('messages.This field is required'),
        ]);

        $title = request('title');
        $description = request('description');
        $languagecode = request('languagecode');

        $defaultlanguage = $this->getdefaultlanguage();

        $lang_name = strtolower($defaultlanguage->name);
        $default_title = '';
        $default_description = '';

        foreach ($languagecode as $key => $value) {

            //Check if title is empty
            if(empty($title[$key])){
                $default_title = $title[$lang_name];
            }
            
            //Check if description is empty
            if(empty($description[$key])){
                $default_description = $description[$lang_name];
            }

            $n_title = isset($title[$key]) ? $title[$key] : $default_title;
            $n_description = isset($description[$key]) ? $description[$key] : $default_description;

            $create = Notificationtext::create([
                'title' => $n_title,
                'description' => $n_description,
                'language' => $value
            ]);

            //Get Parent ID
            $parent_id = $request->session()->get('parent_id');

            if(empty($request->session()->get('parent_id'))){

                // Via a request instance...
                $parent_id =  $request->session()->put('parent_id', $create->id);

            }

            //Check parent ID value
            if(empty($parent_id)){
                $parent_id = $create->id;   
            }
            
            //Update parent ID
            Notificationtext::where('id', $create->id)->update([
                'notificationtext_id' => $parent_id
            ]);
        
        } 

        // Forget session value...
        $request->session()->forget('parent_id');

        return redirect(route('notificationtext'))->with('success', trans('messages.notificationtext_created_successfully'));

    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notificationtext', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return Notificationtext::findOrFail($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notificationtext', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $notification = $this->show($id);
        $languagecodes = $this->languagecodes();
        return view('admin.notificationstext.edit', compact('notification', 'languagecodes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notificationtext', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $notification = $this->show($id);

        $languagecode_name = request('languagecode_name');

        //Validate request data
        $request->validate([
            'title_'.$languagecode_name => 'required|string|max:191',
            'description_'.$languagecode_name => 'required|string',
        ]);

        $title = request('title_'.$languagecode_name);
        $description = request('description_'.$languagecode_name);
        if(!empty(request('notification_id'))){

            Notificationtext::where('id', $id)->update([
                'title' => $title,
                'description' => $description,
            ]);

        }else{

            $parent_id = Notificationtext::find($id);
            Notificationtext::create([
                'title' => $title,
                'description' => $description,
                'language' => request('languagecode'),
                'notificationtext_id' => $parent_id->notificationtext_id,
            ]);

        } 

        return redirect(route('notificationtext'))->with('success', trans('messages.notificationtext_updated_successfully'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'notificationtext', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        
        Notificationtext::where('id', $id)->delete();
        
        return redirect(route('notificationtext'))->with('success', 'Texte de notification supprimé avec succès.');
    }



    /**
     * Get all language list.
     *
     * @return \Illuminate\Http\Response
     */
    public function languagecodes()
    {
        return Languagecode::whereStatus(1)->orderBy('is_default', 'desc')->get(['id', 'name', 'code', 'is_default']);
    }


    /**
     * Validate the given data.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */

    private function validateaddData(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:191',
            'description' => 'required|string',
            'languagecode' => 'required|exists:languagecodes,id'
        ]);
    }
}
