<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\UserData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\User;

class DashboardController extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   	
        $order = ['id', 'DESC'];
        $user = Auth::user();
        $users = User::select('id', 'first_name', 'last_name', 'created_at', 'role','dob')
                ->where('role_id','<',4)
                ->where(function($query) use($user){
                    if($user->role_id > 4){
                        
                        if(!empty($user->pincode)){
                            $query->orWhereRaw("CONCAT(',','" . $user->pincode . "', ',') REGEXP CONCAT(',(', REPLACE(pincode, ',', '|'), '),')");
                        }
                        if(!empty($user->block_id)){
                            $query->orWhereRaw("CONCAT(',','" . $user->block_id . "', ',') REGEXP CONCAT(',(', REPLACE(block, ',', '|'), '),')");
                        }
                        if(!empty($user->booth_id)){
                            $query->orWhereRaw("CONCAT(',','" . $user->booth_id . "', ',') REGEXP CONCAT(',(', REPLACE(booth_name, ',', '|'), '),')");
                        }
                        if(!empty($user->subblock_id)){
                            $query->orWhereRaw("CONCAT(',','" . $user->subblock_id . "', ',') REGEXP CONCAT(',(', REPLACE(subblock_id, ',', '|'), '),')");
                        }
                        if(!empty($user->block_member_ids)){
                            $query->orWhereRaw("CONCAT(',','" . $user->block_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                        }
                        if(!empty($user->subblock_member_ids)){
                            $query->orWhereRaw("CONCAT(',','" . $user->subblock_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                        }
                        if(!empty($user->booth_member_ids)){
                            $query->orWhereRaw("CONCAT(',','" . $user->booth_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                        }
                        if(!empty($user->id)){
                            $query->orWhereRaw("CONCAT(',','" . $user->id . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                        }
                    }
                })
                ->take('10')
                ->latest()
                ->where('is_approved',1)
                ->get();

        $total_users = User::whereIn('role_id',[1,2])
        ->where('is_approved',1)
        ->where('updated_at','!=','NULL')
        ->where(function($query) use($user){
            if($user->role_id > 4){
                
                if(!empty($user->pincode)){
                    $query->orWhereRaw("CONCAT(',','" . $user->pincode . "', ',') REGEXP CONCAT(',(', REPLACE(pincode, ',', '|'), '),')");
                }
                if(!empty($user->block_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_id . "', ',') REGEXP CONCAT(',(', REPLACE(block, ',', '|'), '),')");
                }
                if(!empty($user->booth_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_id . "', ',') REGEXP CONCAT(',(', REPLACE(booth_name, ',', '|'), '),')");
                }
                if(!empty($user->subblock_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->subblock_id . "', ',') REGEXP CONCAT(',(', REPLACE(subblock_id, ',', '|'), '),')");
                }
                if(!empty($user->block_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->subblock_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->subblock_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->booth_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->id . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
            }
        })
        ->count();

        $total_users = UserData::where('updated_at','=',NULL)->count();
        

        $total_updated_users = UserData::where('users_data.updated_at','!=','NULL')
        ->where(function($query) use($user){
            if($user->role_id > 4){
                
                if(!empty($user->pincode)){
                    $query->orWhereRaw("CONCAT(',','" . $user->pincode . "', ',') REGEXP CONCAT(',(', REPLACE(pincode, ',', '|'), '),')");
                }
                if(!empty($user->block_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_id . "', ',') REGEXP CONCAT(',(', REPLACE(block, ',', '|'), '),')");
                }
                if(!empty($user->booth_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_id . "', ',') REGEXP CONCAT(',(', REPLACE(booth_name, ',', '|'), '),')");
                }
                if(!empty($user->subblock_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->subblock_id . "', ',') REGEXP CONCAT(',(', REPLACE(subblock_id, ',', '|'), '),')");
                }
                if(!empty($user->block_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(block, ',', '|'), '),')");
                }
               
                if(!empty($user->booth_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(booth_name, ',', '|'), '),')");
                }
               
            }
        })
        ->count();
        
        $total_ratings = 0;
        $total_rate= User::select(DB::raw('SUM(rating) AS total_rating'))
        ->whereIn('role_id',[1,2])
        ->where('rating','>',0)
        ->first();
        $total_count= User::whereIn('role_id',[1,2])
        ->where('rating','>',0)
        ->count();
       
        if($total_count > 0){
        $total_ratings = round(($total_rate->total_rating/$total_count),1);
        }

        
        
        $total_requests = User::whereIn('role_id',[1,2])
        ->where('is_request',1)
        ->where('updated_at','=',NULL)
        ->where('is_approved',0)
        ->where(function($query) use($user){
            if($user->role_id > 4){
                
                if(!empty($user->pincode)){
                    $query->orWhereRaw("CONCAT(',','" . $user->pincode . "', ',') REGEXP CONCAT(',(', REPLACE(pincode, ',', '|'), '),')");
                }
                if(!empty($user->block_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_id . "', ',') REGEXP CONCAT(',(', REPLACE(block, ',', '|'), '),')");
                }
                if(!empty($user->booth_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_id . "', ',') REGEXP CONCAT(',(', REPLACE(booth_name, ',', '|'), '),')");
                }
                if(!empty($user->subblock_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->subblock_id . "', ',') REGEXP CONCAT(',(', REPLACE(subblock_id, ',', '|'), '),')");
                }
                if(!empty($user->block_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->subblock_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->subblock_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->booth_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->id . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
            }
        })
        ->count();
        $total_updated_requests = User::whereIn('role_id',[1,2])
        ->where('is_request',1)
        ->where('users.updated_at','!=','NULL')
        ->where(function($query) use($user){
            if($user->role_id > 4){
                
                if(!empty($user->pincode)){
                    $query->orWhereRaw("CONCAT(',','" . $user->pincode . "', ',') REGEXP CONCAT(',(', REPLACE(pincode, ',', '|'), '),')");
                }
                if(!empty($user->block_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_id . "', ',') REGEXP CONCAT(',(', REPLACE(block, ',', '|'), '),')");
                }
                if(!empty($user->booth_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_id . "', ',') REGEXP CONCAT(',(', REPLACE(booth_name, ',', '|'), '),')");
                }
                if(!empty($user->subblock_id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->subblock_id . "', ',') REGEXP CONCAT(',(', REPLACE(subblock_id, ',', '|'), '),')");
                }
                if(!empty($user->block_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->block_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->subblock_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->subblock_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->booth_member_ids)){
                    $query->orWhereRaw("CONCAT(',','" . $user->booth_member_ids . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
                if(!empty($user->id)){
                    $query->orWhereRaw("CONCAT(',','" . $user->id . "', ',') REGEXP CONCAT(',(', REPLACE(created_by, ',', '|'), '),')");
                }
            }
        })
        ->count();

        $activities=DB::table('user_activities');
        $activities->select('user_activities.*','users.first_name','users.last_name','roles.name');
        $activities->join('users','users.id','=','user_activities.user_id');	
        $activities->join('roles','roles.id','=','user_activities.role_id');
        $activities->latest();
        if(Auth::user()->role_id > 4){
            $AuthUser=Auth::user()->role_id;
            $userRoles=[];
            if($AuthUser == 4){
                $userRoles=[4,13,14,15,16];
            }
            if($AuthUser == 13){
                $userRoles=[13,14,15,16]; 
            }
            if($AuthUser == 14){
                $userRoles=[14,15,16]; 
            }
            if($AuthUser == 15){
                $userRoles=[15,16]; 
            }
            $activities->whereIn('user_activities.role_id',$userRoles);
        }
        $activities = $activities->get();				
        return view('admin.dashboard', compact('total_count','users','total_ratings','total_updated_users','total_users','total_requests','activities','total_updated_requests'));
    }
}
