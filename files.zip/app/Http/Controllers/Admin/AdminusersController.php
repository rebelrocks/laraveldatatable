<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Emailtemplate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Models\Role;
use App\Models\Permission;
use App\Models\Site_permission;
use App\Traits\SitepermissionsTrait;
use App\Traits\checkermissionsTrait;
use App\Traits\GeneralsettingTrait;
use App\Traits\Sociallink\SociallinkTrait;
use App\User;
use Illuminate\Support\Facades\Mail;

class AdminusersController extends Controller
{
    use SitepermissionsTrait;
    use checkermissionsTrait,GeneralsettingTrait,SociallinkTrait;
    private $userprofiledir = "uploads/users";

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'adminusers', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
		$AuthUser=Auth::user()->role_id;
        $userRoles=[];
        if($AuthUser == 4){
            $userRoles=[4,13,14,15,16];
        }
        if($AuthUser == 13){
            $userRoles=[14,15,16]; 
        }
        if($AuthUser == 14){
            $userRoles=[15,16]; 
        }
        if($AuthUser == 15){
            $userRoles=[16]; 
        }
		$users = User::where('role_id','>=', 4)->whereIn('role_id',$userRoles)->paginate(20);
        return view('admin.admin.users', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        #$this->getUserPermissuuions();
        #Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'adminusers', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
		
		$roles = Role::where('status', 1)->orderBy('id', 'asc')->paginate(10);
        //$roles = $this->roles();
        $block_categories = DB::table('users_data')
        ->select('block')
        ->groupBy('block')
        ->get();
        $booth_categories = DB::table('users_data')
        ->select('booth_name')
        ->groupBy('booth_name')
        ->get();
        $pin_codes=DB::table('users_data')
        ->select('pincode')
        ->where('pincode','!=','')
        ->groupBy('pincode')
        ->get();
        $block_members=DB::table('users')
        ->select('*')
        ->where('role_id',14)
        ->get();

        $sub_block_members=DB::table('users')
        ->select('*')
        ->where('role_id',15)
        ->get();

        $booth_members=DB::table('users')
        ->select('*')
        ->where('role_id',16)
        ->get();
        
        return view('admin.admin.create', compact('roles', 'booth_categories', 'block_categories','block_members','sub_block_members','booth_members','pin_codes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'adminusers', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        //Validate request data
        $request->validate([
            'role' => 'required|exists:roles,id',
            'first_name' => 'required|string|max:191',
            'last_name' => 'required|string|max:191',
            'email' => 'required|string|email|max:191|unique:users',
            'password' => 'required|string|min:5|max:16',
        ]);

        $first_name = request('first_name');
        $last_name = request('last_name');
        $email = request('email');
        $password = request('password');
        $role = request('role');

        $create = User::create([
            'first_name' => $first_name,
            'last_name' => $last_name,
            'block_id'=>(!empty($request->block)) ? implode(',',$request->block) : '',
            'booth_id'=>(!empty($request->booth_name)) ? implode(',',$request->booth_name) : '',
            'block_member_ids'=>(!empty($request->block_members)) ? implode(',',$request->block_members) : '',
            'booth_member_ids'=>(!empty($request->booth_members)) ? implode(',',$request->booth_members) : '',
            'pincode'=>(!empty($request->pin_codes)) ? implode(',',$request->pin_codes) : '',
            'email' => $email,
            'password' => Hash::make($password),
            'role_id' => $role,
            'role' => false,
            'status' => true,
        ]);
        
        $user = User::find($create->id);
        #sending mail to user for account deleted successfully.
        $template = Emailtemplate::where('id', 5)->first();
        $sitesetting = $this->siteSettings();
        $social_links = $this->sitesocialLinks();

        $appname = $sitesetting['site.name'] ?? 'Voters Management';
        $image_path = url('application/public/uploads/emailtemplates');
        $header_image = $image_path.'/'.$template->header_image;
        $white_logo = $image_path.'/'.$template->white_logo;

        $first_name  = $user->first_name ?? '';            
        
        #replace template var with value
        $member = Auth::user();
        $emailFindReplace = array(
            '##MAIN_COLOR##'  => '#'.$template->main_color,
            '##WHITE_LOGO##' => $white_logo,
            '##HEADER_IMAGE##' => $header_image,
            '##FIRST_NAME##' => ucwords($first_name),
            '##SITE_NAME##' => $appname,
            '##MEMBERNAME##' =>ucwords($member->first_name),
            '##MEMBEREMAIL##' =>$member->email,
            '##EMAIL##' => $email,
            '##SECONDARY_COLOR##' => '#'.$template->secondary_color,
            '##FB_LINK##' => isset($social_links['EmailTemplate.fb_url']) ? '<a href="'.$social_links['EmailTemplate.fb_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/fb.png').'" width="54" /></a>' : '',
            '##TWITTER_LINK##' => isset($social_links['EmailTemplate.twitter_url']) ? '<a href="'.$social_links['EmailTemplate.twitter_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/tw.png').'" width="54" /></a>' : '',
            '##INSTA_LINK##' => isset($social_links['EmailTemplate.insta_url']) ? '<a href="'.$social_links['EmailTemplate.insta_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/it.png').'" width="54" /></a>' : '',
            '##WEBSITE##' => isset($social_links['EmailTemplate.web_url']) ? '<a href="'.$social_links['EmailTemplate.web_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/wd.png').'" width="54" /></a>' : '',
            '##LINKEDIN_LINK##' => isset($social_links['EmailTemplate.linked_in_url']) ? '<a href="'.$social_links['EmailTemplate.linked_in_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/linkedin.png').'" width="54" /></a>' : '',
            '##CONTACT_EMAIL##' => $sitesetting['site.contact_email_address'] ?? '',
            '##SITE_LINK##' => $sitesetting['site.url'] ?? '',
            '##YEAR##' => date('Y'),	            
        );

        $from_mail = $sitesetting['site.sending_email_address'];
        $toEmail = $user->email;
        $content = strtr($template['description'], $emailFindReplace);
        $subject = str_replace('##SITE_NAME##', strtolower($appname), $template['subject']);
        if(!empty($toEmail))
        {
            $data =array('templates'=>$content);
            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $first_name, $toEmail, $subject) {
                $message->to($toEmail, ucwords($first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });

            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $subject, $member) {
                $message->to($member->email, ucwords($member->first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });

            $admin = User::find(1);
            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $subject, $admin) {
                $message->to($admin->email, ucwords($admin->first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });
        }

        #End code for mail

        $this->SaveUserActivity('New admin user created by '.Auth::id().' and admin user id is '.$create->id);
        return redirect(route('admin_users'))->with('success', trans('messages.user_has_been_successfully_added'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'adminusers', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $roles = Role::where('status', 1)->orderBy('id', 'asc')->paginate(10);
        $block_categories = DB::table('users_data')
        ->select('block')
        ->groupBy('block')
        ->get();
        $booth_categories = DB::table('users_data')
        ->select('booth_name')
        ->groupBy('booth_name')
        ->get();
        $pin_codes=DB::table('users_data')
        ->select('pincode')
        ->where('pincode','!=','')
        ->groupBy('pincode')
        ->get();
        $block_members=DB::table('users')
        ->select('*')
        ->where('role_id',14)
        ->where('id','!=',$id)
        ->get();

        $sub_block_members=DB::table('users')
        ->select('*')
        ->where('role_id',15)
        ->where('id','!=',$id)
        ->get();

        $booth_members=DB::table('users')
        ->select('*')
        ->where('role_id',16)
        ->where('id','!=',$id)
        ->get();
        
        $user = User::where('role_id','>=',4)->where('id', $id)->first();
        if(!$user){
            abort(404);
        }
        return view('admin.admin.edit_admin_user', compact('roles', 'booth_categories', 'block_categories','block_members','sub_block_members','booth_members','pin_codes', 'user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'adminusers', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        //Validate request data
        $request->validate([
            'role' => 'required|exists:roles,id',
            'first_name' => 'required|string|max:191',
            'last_name' => 'required|string|max:191',
            'email' => 'required|string|email|max:191|unique:users,email,'.$id,
            'password' => 'nullable|string|min:8|max:16',
        ]);

        $first_name = request('first_name');
        $last_name = request('last_name');
        $email = request('email');
        $password = request('password');
        $role = request('role');

        User::where('id', $id)->update([
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'role_id' => $role,
            'block_id'=>(!empty($request->block)) ? implode(',',$request->block) : '',
            'booth_id'=>(!empty($request->booth_name)) ? implode(',',$request->booth_name) : '',
            'block_member_ids'=>(!empty($request->block_members)) ? implode(',',$request->block_members) : '',
            'booth_member_ids'=>(!empty($request->booth_members)) ? implode(',',$request->booth_members) : '',
            'pincode'=>(!empty($request->pin_codes)) ? implode(',',$request->pin_codes) : ''
        ]);

        //Update password
        if(!empty($password)){
            User::where('id', $id)->update([
                'password' => Hash::make($password),
            ]);
        }

        $user = User::find($id);
        #sending mail to user for account deleted successfully.
        $template = Emailtemplate::where('id', 2)->first();
        $sitesetting = $this->siteSettings();
        $social_links = $this->sitesocialLinks();

        $appname = $sitesetting['site.name'] ?? 'Voters Management';
        $image_path = url('application/public/uploads/emailtemplates');
        $header_image = $image_path.'/'.$template->header_image;
        $white_logo = $image_path.'/'.$template->white_logo;

        $first_name  = $user->first_name ?? '';            
        
        #replace template var with value
        $member = Auth::user();
        $emailFindReplace = array(
            '##MAIN_COLOR##'  => '#'.$template->main_color,
            '##WHITE_LOGO##' => $white_logo,
            '##HEADER_IMAGE##' => $header_image,
            '##FIRST_NAME##' => ucwords($first_name),
            '##SITE_NAME##' => $appname,
            '##MEMBERNAME##' =>ucwords($member->first_name),
            '##MEMBEREMAIL##' =>$member->email,
            '##EMAIL##' => $email,
            '##SECONDARY_COLOR##' => '#'.$template->secondary_color,
            '##FB_LINK##' => isset($social_links['EmailTemplate.fb_url']) ? '<a href="'.$social_links['EmailTemplate.fb_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/fb.png').'" width="54" /></a>' : '',
            '##TWITTER_LINK##' => isset($social_links['EmailTemplate.twitter_url']) ? '<a href="'.$social_links['EmailTemplate.twitter_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/tw.png').'" width="54" /></a>' : '',
            '##INSTA_LINK##' => isset($social_links['EmailTemplate.insta_url']) ? '<a href="'.$social_links['EmailTemplate.insta_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/it.png').'" width="54" /></a>' : '',
            '##WEBSITE##' => isset($social_links['EmailTemplate.web_url']) ? '<a href="'.$social_links['EmailTemplate.web_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/wd.png').'" width="54" /></a>' : '',
            '##LINKEDIN_LINK##' => isset($social_links['EmailTemplate.linked_in_url']) ? '<a href="'.$social_links['EmailTemplate.linked_in_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/linkedin.png').'" width="54" /></a>' : '',
            '##CONTACT_EMAIL##' => $sitesetting['site.contact_email_address'] ?? '',
            '##SITE_LINK##' => $sitesetting['site.url'] ?? '',
            '##YEAR##' => date('Y'),	            
        );

        $from_mail = $sitesetting['site.sending_email_address'];
        $toEmail = $user->email;
        $content = strtr($template['description'], $emailFindReplace);
        $subject = str_replace('##SITE_NAME##', strtolower($appname), $template['subject']);
        if(!empty($toEmail))
        {
            $data =array('templates'=>$content);
            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $first_name, $toEmail, $subject) {
                $message->to($toEmail, ucwords($first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });

            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $subject, $member) {
                $message->to($member->email, ucwords($member->first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });

            $admin = User::find(1);
            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $subject, $admin) {
                $message->to($admin->email, ucwords($admin->first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });
        }

        #End code for mail

        $this->SaveUserActivity('Admin user updated by '.Auth::id().' and admin user id is '.$id);
        return redirect(route('admin_users'))->with('success', trans('messages.user_has_been_updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'adminusers', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $user = User::findOrFail($id);
        if(!$user)
        {
            return abort(404);
        }
        User::where('id', $id)->delete();

        #sending mail to user for account deleted successfully.
        $template = Emailtemplate::where('id', 4)->first();
        $sitesetting = $this->siteSettings();
        $social_links = $this->sitesocialLinks();

        $appname = $sitesetting['site.name'] ?? 'Voters Management';
        $image_path = url('application/public/uploads/emailtemplates');
        $header_image = $image_path.'/'.$template->header_image;
        $white_logo = $image_path.'/'.$template->white_logo;

        $first_name  = $user->first_name ?? '';            
        
        #replace template var with value
        $member = Auth::user();
        $emailFindReplace = array(
            '##MAIN_COLOR##'  => '#'.$template->main_color,
            '##WHITE_LOGO##' => $white_logo,
            '##HEADER_IMAGE##' => $header_image,
            '##FIRST_NAME##' => ucwords($first_name),
            '##SITE_NAME##' => $appname,
            '##MEMBERNAME##' =>ucwords($member->first_name),
            '##MEMBEREMAIL##' =>$member->email,
            '##SECONDARY_COLOR##' => '#'.$template->secondary_color,
            '##FB_LINK##' => isset($social_links['EmailTemplate.fb_url']) ? '<a href="'.$social_links['EmailTemplate.fb_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/fb.png').'" width="54" /></a>' : '',
            '##TWITTER_LINK##' => isset($social_links['EmailTemplate.twitter_url']) ? '<a href="'.$social_links['EmailTemplate.twitter_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/tw.png').'" width="54" /></a>' : '',
            '##INSTA_LINK##' => isset($social_links['EmailTemplate.insta_url']) ? '<a href="'.$social_links['EmailTemplate.insta_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/it.png').'" width="54" /></a>' : '',
            '##WEBSITE##' => isset($social_links['EmailTemplate.web_url']) ? '<a href="'.$social_links['EmailTemplate.web_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/wd.png').'" width="54" /></a>' : '',
            '##LINKEDIN_LINK##' => isset($social_links['EmailTemplate.linked_in_url']) ? '<a href="'.$social_links['EmailTemplate.linked_in_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/linkedin.png').'" width="54" /></a>' : '',
            '##CONTACT_EMAIL##' => $sitesetting['site.contact_email_address'] ?? '',
            '##SITE_LINK##' => $sitesetting['site.url'] ?? '',
            '##YEAR##' => date('Y'),	            
        );

        $from_mail = $sitesetting['site.sending_email_address'];
        $toEmail = $user->email;
        $content = strtr($template['description'], $emailFindReplace);
        $subject = str_replace('##SITE_NAME##', strtolower($appname), $template['subject']);
        if(!empty($toEmail))
        {
            $data =array('templates'=>$content);
            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $first_name, $toEmail, $subject) {
                $message->to($toEmail, ucwords($first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });

            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $subject, $member) {
                $message->to($member->email, ucwords($member->first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });

            $admin = User::find(1);
            $status = Mail::send("emails.send_mail", $data, function ($message) use ($from_mail, $subject, $admin) {
                $message->to($admin->email, ucwords($admin->first_name))
                    ->subject($subject);
                $message->from($from_mail, $subject);
            });
        }

        #End code for mail

        $this->SaveUserActivity('Admin user deleted by '.Auth::id().' and admin user id is '.$id);
        return back()->with('success',  trans('messages.user_delete_successfully'));

    }
}
