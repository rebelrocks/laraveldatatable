<?php

namespace App\Http\Controllers\Admin\Sitepermissions;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Admin\AddmanagerRequest;
use App\Http\Requests\Admin\UpdatelanguageRequest;
use App\Models\Manager;
use App\Models\Role;
use App\Models\Permission;
use App\Models\Site_permission;
use App\Traits\SitepermissionsTrait;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;

class SitepermissionsController extends Controller
{

    use SitepermissionsTrait, checkermissionsTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $roles = $this->roles();
        
        $managers = Manager::select('id', 'name', 'status')
                    ->where('status', 1)
                    ->orderBy('id', 'desc')
                    ->get();

        $permissions = $this->permissions();

        $current_role = '';

        $role = Role::where('name', '!=', 'Super Admin')->whereId($id)->first();

        if(!$role){
            return abort(404);
        }

        $sitepermissions = Site_permission::where('role_id', $id)->paginate(30);

        if(!empty($id)){
            $role = Role::where('name', '!=', 'Super Admin')->whereId($id)->first();
            $current_role = $role->name;
        }       

        //Send data
        $array = [
            'id' => $id,
            'managers' => $managers,
            'sitepermissions' => $sitepermissions,
            'current_role' => $current_role            
        ];

        return view('admin.sitepermissions.sitepermissions')->with($array);

    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index_v1($id)
    {
        return abort(404);
        exit();

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $current_role = '';

        $role = Role::findOrFail($id);

        $role_detail = Role::where('name', 'Super Admin')->first();

        $sitepermissions = Site_permission::where('role_id', '!=', $role_detail->id)->orderBy('role_id', 'asc')->paginate(10);       

        if(!empty($id)){
            $role = Role::where('name', '!=', 'Super Admin')->whereId($id)->first();

            if($role){
                $current_role = $role->name;
                $sitepermissions = Site_permission::where('role_id', $id)->orderBy('role_id', 'asc')->paginate(10);   
            }
        }

        return view('admin.sitepermissions.sitepermissions', compact('sitepermissions', 'current_role', 'id'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        return abort(404);
        exit(); 
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $role = Role::findOrFail($id);
        $roles = $this->roles();
        $managers = $this->managers();
        $permissions = $this->permissions();
        return view('admin.sitepermissions.create', compact('roles', 'managers', 'permissions', 'id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $id)
    {
        return abort(404);
        exit();

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Validate request data
        $request->validate([
            'role' => 'required|exists:roles,id',
            'manager' => 'required|exists:managers,id',
            'read' => 'boolean',
            'add' => 'boolean',
            'edit' => 'boolean',
            'delete' => 'boolean'
        ]);

        //request data
        $role = request('role');
        $manager = request('manager');
        $read = request('read') ? : false;
        $add = request('add') ? : false;
        $edit = request('edit') ? : false;
        $delete = request('delete') ? : false;

        //Check site permission exit or not
        $check = $this->checksitepermission('', $role, $manager);

        if($check){

            return back()->with('warning', trans('messages.site_permission_already_exits'));
            exit();
        }

        $create = Site_permission::create([
            'role_id' => $role,
            'manager_id' => $manager,
            'is_read' => $read,
            'is_add' => $add,
            'is_edit' => $edit,
            'is_delete' => $delete,
        ]);

        if($create){

            return redirect(route('sitepermissions',$id))->with('success', trans('messages.new_site_permission_created_successfully'));

        }

        return back()->with('warning', trans('messages.oops'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        return Site_permission::findOrFail($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($role_id, $id)
    {
        return abort(404);
        exit();

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $sitepermission = $this->show($id);
        $roles = $this->roles();
        $managers = $this->managers();
        $permissions = $this->permissions();

        $data = [
                'sitepermission' => $sitepermission,
                'roles' => $roles,
                'managers' => $managers,
                'permissions' => $permissions,
                'id' => $role_id,
            ];
        return view('admin.sitepermissions.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $role_id, $id)
    {
        return abort(404);
        exit();

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Validate request data
        $request->validate([
            'role' => 'required|exists:roles,id',
            'manager' => 'required|exists:managers,id',
            'read' => 'boolean',
            'add' => 'boolean',
            'edit' => 'boolean',
            'delete' => 'boolean'
        ]);

        $sitepermission = $this->show($id);

        //request data
        $role = request('role');
        $manager = request('manager');
        $read = request('read') ? : false;
        $add = request('add') ? : false;
        $edit = request('edit') ? : false;
        $delete = request('delete') ? : false;

        //Check site permission exit or not
        $check = $this->checksitepermission($id, $role, $manager);

        if($check){

            return back()->with('warning', trans('messages.site_permission_already_exits'));
            exit();
        }

        $update = Site_permission::where('id', $id)->update([
            'role_id' => $role,
            'manager_id' => $manager,
            'is_read' => $read,
            'is_add' => $add,
            'is_edit' => $edit,
            'is_delete' => $delete,
        ]);

        if($update){

            return redirect(route('sitepermissions', $role_id))->with('success', trans('messages.site_permission_updated_successfully'));

        }

        return back()->with('warning', trans('messages.oops'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($role_id, $id)
    {
        return abort(404);
        exit();

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'sitepermissions', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $delete = $this->show($id);
        $delete->delete();

        return back()->with('success', trans('messages.site_permissions_deleted_successfully'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatestatus(Request $request)
    {
        if($request->ajax()){

            $site_permission_id = request('site_permission_id');

            $sitepermission = $this->show($site_permission_id);

            //Status
            $status = true;

            if($sitepermission->status){

                $status = false;

            }

            $sitepermission->status = $status;
            $sitepermission->update();
            if($sitepermission){

                $permission = Site_permission::find($site_permission_id);

                $btn_class = $permission->status == 1 ? 'success' : 'danger';

                $btn_value = $permission->status ? trans('messages.active') : trans('messages.inactive');

                $is_read = "<a href='javascript:void(0)' onclick='updatestatus(".$site_permission_id.")'><span class='btn btn-sm btn-".$btn_class."'>".$btn_value."</span></a>";

                $response = [
                        'is_read' => $is_read,
                        'success' => trans('messages.status_updated_successfully'),
                    ];

                return response()->json($response);
            }
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function permissionstatus(Request $request)
    {
        if($request->ajax()){

            $columnsArray = [
                1 => 'is_read',
                2 => 'is_add',
                3 => 'is_edit',
                4 => 'is_delete',
            ];

            $role_id = request('role_id');
            $id = request('site_permission_id');
            $status = $columnsArray[request('status')];
            $current_status = request('current_status');
            $permission = Site_permission::where('id', $id)->where($status, $current_status)->first(["id", $status])->toArray();
            
            //Status
            $new_status = true;

            if($permission[$status]){

                $new_status = false;

            }
            
            $site_status = $status;

            $update = Site_permission::where('id', $id)->update([$status => $new_status]);
            
            if($update){
                $is_read = '';
                if($current_status==1){
                    $current_status = 0;
                }

                if($current_status==false){
                    $current_status = 1;
                }
                
                $detail = Site_permission::where('id', $id)->where($status, $new_status)->first(["id", $status])->toArray();
                
                $btn_class = $detail[$status] == 1 ? 'success' : 'danger';

                $btn_status = $detail[$status] == 1 ? '1' : '0';

                $btn_value = $detail[$status] ? trans('messages.yes') : trans('messages.no');

                $is_read .= "<a href='javascript:void(0)' onclick='updatesitepermissions(".$role_id.", ".$id.", ".request('status').", ".$btn_status.")'><span class='btn btn-sm btn-".$btn_class."'>".$btn_value."</span></a>";

                $response = [
                    'is_read' => $is_read,
                    'success' => trans('messages.status_updated_successfully'),
                ];

                return response()->json($response);  
            }

            $response = [
                'error' => trans('messages.oops'),
            ];

            return response()->json($response);            
        }
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateallstatus(Request $request, $status, $role_id)
    {
        //Get status
        $count = Site_permission::where($status, true)->where('role_id', $role_id)->count();

        $new_status = $count ? false : true;

        $update = Site_permission::where('role_id', $role_id)->update([$status => $new_status]);

        if($update){
            return back()->with('success', trans('messages.status_updated_successfully'));
        }

        return back()->with('success', trans('messages.oops'));
    }
}
