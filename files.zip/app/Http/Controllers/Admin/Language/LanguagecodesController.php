<?php

namespace App\Http\Controllers\Admin\Language;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Arr;
use App\Http\Requests\Admin\AddlanguageRequest;
use App\Http\Requests\Admin\UpdatelanguageRequest;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Carbon\Carbon;
use App\Traits\checkermissionsTrait;

class LanguagecodesController extends Controller
{

    use LanguagecodeTrait, checkermissionsTrait;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $languagecodes = Languagecode::all(['id', 'name', 'code', 'status', 'is_default']);
        $languages = $this->languagecodes();
        $defaultlanguage = $this->getdefaultlanguage();
        return view('admin.language.languagecodes', compact('languagecodes', 'languages', 'defaultlanguage'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Get all language code list
        $codelists = Arr::sort($this->codelists());

        return view('admin.language.create', compact('codelists'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AddlanguageRequest $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $status = false;

        if(request('status')){
            $status = true;
        }
        
        $code = request('code');

        //Check language code exit or not.
        if(!array_key_exists($code, $this->codelists())){
            return back()->with('warning', trans('messages.The selected language code does not exist'));    
            exit();
        }

        $create = Languagecode::create([
            'name' => request('name'),
            'code' => $code,
            'status' => $status,
        ]);

        if($create){

            return redirect(route('languages'))->with('success', trans('messages.create_new_language'));

        }

        return back()->with('warning', trans('messages.oops'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Languagecode::findOrFail($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $language = $this->show($id);

        //Get all language code list
        $codelists = Arr::sort($this->codelists());

        return view('admin.language.edit', compact('language', 'codelists'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatelanguageRequest $request, $id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $language = $this->show($id);

        $status = false;

        if(request('status')){
            $status = true;
        }

        $update = Languagecode::where('id', $id)->update([
            'name' => request('name'),
            'code' => request('code'),
            'status' => $status,
        ]);

        if($update){

            return redirect(route('languages'))->with('success', trans('messages.update_language'));

        }

        return back()->with('warning', trans('messages.oops'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        //Check language status if not active
        $check = Languagecode::where('id', $id)->where('is_default', true)->count();
        if($check){
            return redirect()->back()->with('warning', trans('messages.oops'));
            exit();
        }
           
        $delete = $this->show($id);
        $delete->delete();

        if($delete){

            return redirect(route('languages'))->with('success', trans('messages.delete_language'));

        }

        return back()->with('warning', trans('messages.oops'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatestatus(Request $request, $id)
    {
        if($request->ajax()){

            //Check permission access or not
            if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_edit'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                    exit();
            }

            $output = array('success' => '', 'error' => '');
            
            //Check language status if not active
            $check = Languagecode::where('id', $id)->where('is_default', true)->count();
            if($check){

                $output['error'] = trans('messages.something_worng');
                
            }else{
                
                $status = request('status') ? false : true;
                
                $update = Languagecode::where('id', $id)->update(['status' => $status]);

                if($update){
                    $output['success'] = trans('messages.status_updated_successfully');
                }else{
                    $output['error'] = trans('messages.something_worng');  
                }
            }
            return response()->json($output);
        }
    }


    /**
     * Update the default language in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updatedefaultlanguage(Request $request, $new_local, $default_language)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'language', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $language = $default_language;

        //Check language status if not active
        $check = Languagecode::where('id', $language)->where('status', true)->count();
        if(!$check){
            return redirect()->back()->with('warning', trans('messages.oops'));
            exit();
        }
        $update = Languagecode::where('id', $language)->update(['is_default' => true]);

        if($update){

            Languagecode::where('is_default', true)->where('id', '!=', $language)->update(['is_default' => false]);
            $local = $new_local ?? str_replace('_', '-', app()->getLocale());
            Session::put('locale', $local);
            return redirect()->back()->with('success', trans('messages.update_language_status'));
        }

        return redirect()->back()->with('warning', trans('messages.oops'));
    }
}
