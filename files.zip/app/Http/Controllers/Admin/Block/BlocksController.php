<?php

namespace App\Http\Controllers\Admin\Block;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Traits\UploadTrait;
use Carbon\Carbon;
use App\Models\Category;
use App\Traits\checkermissionsTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Helper;

class BlocksController extends Controller
{
    use checkermissionsTrait, UploadTrait, LanguagecodeTrait;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $categories = Category::where('category_id','=',0)->orderBy('short_order','ASC')->get();
        return view('admin.block.categories', compact('categories'));
    }

    public function ajax_get_blocks(){
        $defaultlanguage = $this->getdefaultlanguage();
        if(request()->ajax()) {

            $draw = request('draw');

            $row = request('start');

            $rowperpage = request('length'); // Rows display per page

            $columnIndex = request('order')['0']['column']; // Column index
            
            $columnName = request('columns')[$columnIndex]['data']; // Column name

            $columnSortOrder = request('order')[0]['dir']; // asc or desc
            
            $searchValue = request('search')['value']; // Search value
            

            ## Total number of records without filtering
            $totalRecords = DB::table('categories')->where('category_id','=',0)->count();

            ## Table Sorting
            
            ## Fetch records
            if(!empty($searchValue)){

                 $empQuery = Category::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->where('title', 'like', '%'.$searchValue.'%')
					        ->where('category_id','=',0)
                            ->offset($row)
                            ->limit($rowperpage)
                            ->orderBy('short_order','ASC')
                            ->get();

                    ## Total number of records without filtering
                    $totalRecords = DB::table('categories')->where('category_id','=',0)->where('title', 'like', '%'.$searchValue.'%')->count();
                    
            }elseif(!empty($columnName)){

                //Change create column name created_at
                if($columnName=='created'){
                    $columnName  = 'created_at';  
                }

                $empQuery = Category::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->offset($row)
					        ->where('category_id','=',0)
                            ->orderBy('short_order','ASC')
                            ->limit($rowperpage)->get();
                            #->orderebycoloumn($columnName, $columnSortOrder);
                
            }else{
                $empQuery = Category::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->offset($row)
					        ->where('category_id','=',0)
                            ->orderBy('short_order','ASC')
                            ->limit($rowperpage)->get();
                       
            }

            $data = array();
            $are_you_sure_want_to_delete = "'".trans('messages.are_you_sure_want_to_delete')."'";
            $change_status = "'".trans('messages.change_status')."'";
            if(count($empQuery)){
            
                foreach($empQuery as $rk1 => $rv1){
                    $data[$rk1]['id'] = $rv1->id;
                    $data[$rk1]['title'] = $rv1->title;
                    $data[$rk1]['content_type'] = $rv1->content_type ?? '-';
                    $data[$rk1]['department'] = $rv1->department ?? '-';
                    
                    $status = trans('messages.statusinactive');
                    //$change_status = trans('messages.change_status');
                    $status_class = 'danger';
                    if($rv1->status){
                        $status = trans('messages.statusactive');
                        $status_class = 'success';
                    }

                    $data[$rk1]['status'] = '<a id="atag'.$rv1->id.'" class="btn btn-'.$status_class.'" data-id="'.$rv1->id.'" data-status="'.$rv1->status.'" href="javascript:void(0)" onclick="updatecategoryStatus(this)" >'.$status.'</a>';


                    $actions = '';
                    #$subcategoryCounter=Category::where('category_id',$rv1->id)->count();               
                    #if($subcategoryCounter > 0){
                    $actions .= '<a href="'.route('sub_blocks', $rv1->id).'" class="btn btn-success">'.trans('View Sub blocks').'<div class="ripple-container"></div></a>&nbsp; <br />';
                    #}
                    $actions .= '<a href="'.route('update_block', $rv1->id).'" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>&nbsp; <br />';
                    
                    $actions .= '<a href="'.route('delete_block', $rv1->id).'" class="btn btn-danger" onclick="return confirm('.$are_you_sure_want_to_delete.')"><i class="material-icons">clear</i> SUPPRIMER</a>'; 
                    
                    $actions .= ' <a href="javascript:void(0);" style="margin-left: 5px;"><i class="material-icons" style="font-size: 42px; color: #ccc;">dehaze</i></a>';
                    
                    $data[$rk1]['action'] = $actions;
                }
            }

            
            
            ## Total number of record with filtering
            $totalRecordwithFilter = Category::where('category_id','=',0)->where('title', 'like', '%'.$searchValue.'%')->count();
            

            ## Response
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $totalRecordwithFilter,
                "iTotalDisplayRecords" => $totalRecords,
                "aaData" => $data
            );            
            echo json_encode($response);
            exit(); 
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        return view('admin.block.create');
    }

    public function store(Request $request)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
      
        $this->validateadsData($request);

        $status = request('status') ? true : false;
        $uplode_image_path = public_path('uploads/categories');
        $title = request('title') ? request('title') :'';
		$subtitle = request('subtitle') ? request('subtitle') :'';
		$slide_image = request()->file('slide_image');
        $content_type=request('content_type') ? : '';
        
        $department=implode(',',$request->department);
		$get_slide_image='';
        if($request->hasFile('slide_image')){
            if(!empty($slide_image)){
                @$get_slide_image =  $this->uploadimageCompress($slide_image, $uplode_image_path);
               
            }
        }
        $create = Category::create([
            'languagecode_id' =>'0',
            'parent_id'=>'',
            'category_id'=>$request->category_id ? $request->category_id : 0,
            'title' => $title,
            'img_default'=>$get_slide_image,
            'content_type' => $content_type,
            'department' => $department,
            'Subtitle_training' => $subtitle,
            'number_of_questions' => $request->number_of_question,				
            'status' => $status,
        ]);

        return redirect(route('blocks'))->with('success', trans('Block has been successfully added'));
    }

    private function validateadsData(Request $request)
    {
        $validatedata = $request->validate([
            'title' => 'required|string',
            'subtitle' => 'required|string',
            'number_of_question' => 'required|string',
            #'department' => 'required|string',
            #'content_type' => 'required|string',
        ]);

        return $validatedata;
    }

    private function validateadsupdateData(Request $request)
    {
        $validatedata = $request->validate([
            'title' => 'required|string',
            'subtitle' => 'required|string',
            'number_of_question' => 'required|string',
            #'department' => 'required|string',
            #'content_type' => 'required|string',
        ]);

        return $validatedata;
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    

    

    public function edit($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        
        $category = Category::find($id);

        return view('admin.block.edit', compact('category'));

    }
    
    public function update(Request $request, $id){
       
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $this->validateadsupdateData($request);
        
        $status = request('status') ? true : false;
        $uplode_image_path = public_path('uploads/categories');
        $title = request('title') ? request('title') :'';
		$subtitle = request('subtitle') ? request('subtitle') :'';
		$slide_image = request()->file('slide_image');
        $content_type=request('content_type') ? : '';
        
        $department=implode(',',$request->department);
		$get_slide_image='';
        if($request->hasFile('slide_image')){
            if(!empty($slide_image)){
                @$get_slide_image =  $this->uploadimageCompress($slide_image, $uplode_image_path);
               
            }
        }else{
            $get_slide_image=$request->previous_slide_image ? $request->previous_slide_image :''; 
        }
        $update = Category::where('id',$id)->update([
            'languagecode_id' =>'0',
            'parent_id'=>'',
            'category_id'=>$request->category_id ? $request->category_id : 0,
            'title' => $title,
            'img_default'=>$get_slide_image,
            'content_type' => $content_type,
            'department' => $department,
            'Subtitle_training' => $subtitle,
            'number_of_questions' => $request->number_of_question,				
            'status' => $status,
        ]);
		
            
        return redirect(route('blocks'))->with('success', trans('Block Added has been successfully updated'));
        
    }

    public function destroy($id){
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
       
		$slides = Category::where('id', $id)->get();

        if(!$slides){
            return abort(404);
            exit();
        }
        if(count($slides) > 0){
            foreach($slides as $slide){
                $uplode_image_path = public_path('uploads/categories');
                if(!empty($slide->img_default) && File::exists($uplode_image_path.'/'.$slide->img_default)){
                    unlink($uplode_image_path.'/'.$slide->img_default);
                }

            }
        }
        
        Category::where('id',$id)->orWhere('category_id',$id)->delete();
		
        return redirect(route('blocks'))->with('success', trans('Block has been successfully deleted'));

    }

    public function updatestatus(Request $request){

        if($request->ajax()){

            //Check permission access or not
            if(!$this->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                    exit();
            }

            $output = array('success' => '', 'error' => '');
            
            $status = request('status') ? false : true;
            $id=request('id');

            $update = Category::where('id', $id)->update(['status' => $status]);

            if($update){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }
	
	
	/**
     * Update the table row sorting.
     *
     * @return \Illuminate\Http\Response
     */
    public function sortTable(Request $request)
    {
        if($request->ajax()){

            $position = request('position');
            $i = 1;
            foreach ($position as $k => $id) 
            {
               
                Category::where('id', $id)->update(['short_order' => $i]);
                $i++;
            }
            
            return response()->json(['success' => 'Update successfully.']);
            exit;

        }
    }


    public function sub_blocks($id)
    {
        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $defaultlanguage = $this->getdefaultlanguage();
        $categories = Category::where('category_id',$id)->orderBy('short_order','ASC')->get();
        $defaultLanguadgeCode=$defaultlanguage->id;
        $categoryInfo=Category::where('id',$id)->first(); 
                   
        return view('admin.block.sub_categories', compact('categories','categoryInfo'));
    }

    public function ajax_get_sub_blocks($id){
        $defaultlanguage = $this->getdefaultlanguage();
        if(request()->ajax()) {

            $draw = request('draw');

            $row = request('start');

            $rowperpage = request('length'); // Rows display per page

            $columnIndex = request('order')['0']['column']; // Column index
            
            $columnName = request('columns')[$columnIndex]['data']; // Column name

            $columnSortOrder = request('order')[0]['dir']; // asc or desc
            
            $searchValue = request('search')['value']; // Search value
            

            ## Total number of records without filtering
            $totalRecords = DB::table('categories')->count();

            ## Table Sorting
            
            ## Fetch records
            if(!empty($searchValue)){

                 $empQuery = Category::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->where('title', 'like', '%'.$searchValue.'%')
                            ->where('category_id',$id)
                            ->offset($row)
                            ->limit($rowperpage)
                            ->get();

                    ## Total number of records without filtering
                    $totalRecords = DB::table('categories')->where('category_id',$id)->where('title', 'like', '%'.$searchValue.'%')->count();
                    
            }elseif(!empty($columnName)){

                //Change create column name created_at
                if($columnName=='created'){
                    $columnName  = 'created_at';  
                }

                $empQuery = Category::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->offset($row)
                            ->where('category_id',$id)
                            ->limit($rowperpage)->get();
                            #->orderebycoloumn($columnName, $columnSortOrder);
                
            }else{
                $empQuery = Category::select('*')
                            #->whereLanguagecode_id($defaultlanguage->id)
                            ->offset($row)
                            ->where('category_id',$id)
                            ->limit($rowperpage)->get();
                       
            }
            $data = array();
            $are_you_sure_want_to_delete = "'".trans('messages.are_you_sure_want_to_delete')."'";
            $change_status = "'".trans('messages.change_status')."'";
            if(count($empQuery)){
            
                foreach($empQuery as $rk1 => $rv1){
                    $data[$rk1]['id'] = $rv1->id;
                    $data[$rk1]['title'] = $rv1->title;
                    $data[$rk1]['content_type'] = $rv1->content_type ?? '-';
                    $data[$rk1]['department'] = $rv1->department ?? '-';
                    $categoryInfo=Category::where('id',$id)->first(); 
                    $category_name=$categoryInfo->title ? $categoryInfo->title : '-';
                                            
                    $data[$rk1]['category_name'] = $category_name ? $category_name : '-';
                    
                    $status = trans('messages.statusinactive');
                    //$change_status = trans('messages.change_status');
                    $status_class = 'danger';
                    if($rv1->status){
                        $status = trans('messages.statusactive');
                        $status_class = 'success';
                    }

                    $data[$rk1]['status'] = '<a id="atag'.$rv1->id.'" class="btn btn-'.$status_class.'" data-id="'.$rv1->id.'" data-status="'.$rv1->status.'" href="javascript:void(0)" onclick="updatecategoryStatus(this)" >'.$status.'</a>';


                    $actions = '';
                                    
                    $actions .= '<a href="'.route('update_sub_block', $rv1->id).'" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>&nbsp; <br />';
                    
                    $actions .= '<a href="'.route('delete_block', $rv1->id).'" class="btn btn-danger" onclick="return confirm('.$are_you_sure_want_to_delete.')"><i class="material-icons">clear</i> SUPPRIMER</a>'; 
                    
                    $data[$rk1]['action'] = $actions;
                }
            }

            
            
            ## Total number of record with filtering
            $totalRecordwithFilter = Category::where('category_id',$id)->whereLanguagecode_id($defaultlanguage->id)->where('title', 'like', '%'.$searchValue.'%')->count();
            

            ## Response
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $totalRecordwithFilter,
                "iTotalDisplayRecords" => $totalRecords,
                "aaData" => $data
            );            
            echo json_encode($response);
            exit(); 
        }
    }
}