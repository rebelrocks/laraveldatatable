<?php

namespace App\Http\Controllers\Admin\Block;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Traits\UploadTrait;
use Carbon\Carbon;
use App\Models\Category;
use App\Traits\checkermissionsTrait;
use App\Models\Languagecode;
use App\Traits\LanguagecodeTrait;
use Helper;

class SubBlocksController extends Controller
{
    use checkermissionsTrait, UploadTrait, LanguagecodeTrait;
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }


    public function create()
    {
        
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $categories=Category::where('category_id',0)->where('status',1)->get();
        return view('admin.subblock.create',compact('categories'));
    }

    public function store(Request $request)
    {
        
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_add'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
      
        $this->validateadsData($request);

        $status = request('status') ? true : false;
        $uplode_image_path = public_path('uploads/categories');
        $title = request('title') ? request('title') :'';
		$subtitle = request('subtitle') ? request('subtitle') :'';
		$slide_image = request()->file('slide_image');
        $content_type=request('content_type') ? : '';
        
        $department=implode(',',$request->department);
		$get_slide_image='';
        if($request->hasFile('slide_image')){
            if(!empty($slide_image)){
                @$get_slide_image =  $this->uploadimageCompress($slide_image, $uplode_image_path);
               
            }
        }
        $create = Category::create([
            'languagecode_id' =>'0',
            'parent_id'=>'',
            'category_id'=>$request->category_id ? $request->category_id : 0,
            'title' => $title,
            'img_default'=>$get_slide_image,
            'content_type' => $content_type,
            'department' => $department,
            'Subtitle_training' => $subtitle,
            'number_of_questions' => $request->number_of_question,				
            'status' => $status,
        ]);

        return redirect(route('blocks'))->with('success', trans('Sub-Block has been successfully added'));
    }

    private function validateadsData(Request $request)
    {
        $validatedata = $request->validate([
            'title' => 'required|string',
            'subtitle' => 'required|string',
            'number_of_question' => 'required|string',
            #'department' => 'required|string',
            #'content_type' => 'required|string',
        ]);

        return $validatedata;
    }

    private function validateadsupdateData(Request $request)
    {
        $validatedata = $request->validate([
            'title' => 'required|string',
            'subtitle' => 'required|string',
            'number_of_question' => 'required|string',
            #'department' => 'required|string',
            #'content_type' => 'required|string',
        ]);

        return $validatedata;
    }
    
    public function edit($id)
    {
        
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        
        $category = Category::find($id);
        $categories=Category::where('category_id',0)->where('status',1)->get();
        return view('admin.subblock.edit', compact('category','categories'));

    }
    
    public function update(Request $request, $id){
       
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_edit'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }

        $this->validateadsupdateData($request);
        $status = request('status') ? true : false;
        $uplode_image_path = public_path('uploads/categories');
        $title = request('title') ? request('title') :'';
		$subtitle = request('subtitle') ? request('subtitle') :'';
		$slide_image = request()->file('slide_image');
        $content_type=request('content_type') ? : '';
        
        $department=implode(',',$request->department);
		$get_slide_image='';
        if($request->hasFile('slide_image')){
            if(!empty($slide_image)){
                @$get_slide_image =  $this->uploadimageCompress($slide_image, $uplode_image_path);
               
            }
        }else{
            $get_slide_image=$request->previous_slide_image ? $request->previous_slide_image :''; 
        }
        $update = Category::where('id',$id)->update([
            'languagecode_id' =>'0',
            'parent_id'=>'',
            'category_id'=>$request->category_id ? $request->category_id : 0,
            'title' => $title,
            'img_default'=>$get_slide_image,
            'content_type' => $content_type,
            'department' => $department,
            'Subtitle_training' => $subtitle,
            'number_of_questions' => $request->number_of_question,				
            'status' => $status,
        ]);
		
            
        return redirect(route('blocks'))->with('success', trans('Sub-Block has been successfully updated'));
        
    }

    public function destroy($id){
        
        if(!$this->checkPermission(Auth::user()->role_id, 'categories', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
       
		$slides = Category::where('id', $id)->get();

        if(!$slides){
            return abort(404);
            exit();
        }
        if(count($slides) > 0){
            foreach($slides as $slide){
                $uplode_image_path = public_path('uploads/categories');
                if(!empty($slide->img_default) && File::exists($uplode_image_path.'/'.$slide->img_default)){
                    unlink($uplode_image_path.'/'.$slide->img_default);
                }

            }
        }
        
        Category::where('id',$id)->orWhere('category_id',$id)->delete();
		
        return redirect(route('blocks'))->with('success', trans('Sub-Block has been successfully deleted'));

    }

    public function updatestatus(Request $request){

        if($request->ajax()){

            if(!$this->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
            {
                return response()->json(['error' => trans('messages.You are not authorised to access that location')]);
                    exit();
            }

            $output = array('success' => '', 'error' => '');
            
            $status = request('status') ? false : true;
            $id=request('id');

            $update = Category::where('id', $id)->update(['status' => $status]);

            if($update){
                $output['success'] = trans('messages.status_updated_successfully');
            }else{
                $output['error'] = trans('messages.something_worng');  
            }

            return response()->json($output);
        }
    }
	
    public function sortTable(Request $request)
    {
        if($request->ajax()){

            $position = request('position');
            $i = 1;
            foreach ($position as $k => $id) 
            {
               
                Category::where('id', $id)->update(['short_order' => $i]);
                $i++;
            }
            
            return response()->json(['success' => 'Update successfully.']);
            exit;

        }
    }

}