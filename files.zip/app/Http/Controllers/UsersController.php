<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use App\User;
use App\Models\Usermeta;
use App\Models\Userimage;
use App\Models\Restaurantdetail;
use App\Models\Restaurantgallery;
use App\Models\Restauranttype;
use Carbon\Carbon;
use App\Traits\UploadTrait;
use App\Traits\checkermissionsTrait;
use Helper;


class UsersController extends Controller
{
    use UploadTrait, checkermissionsTrait;

    private $userprofiledir = "uploads/users";

 	public function signup()
    {		
        return view('users.signup');
    }


    /**
     * Define user profile image upload path 
     */
    public function userprofiledirpath()
    {
        return $this->userprofiledir;
    }



    /**
     * upload user images
     * @param $user_id, $image_id, $image
     */
    private function uploaduserimages($user_id, $image, $image_id)
    {
        //add user image
        Userimage::create([
            'user_id' => $user_id,
            'image' => $image,
            'image_id' => $image_id,
            'status' => 1,
        ]);
    }

    /**
     * delete user images
     * @param $id, $image
     */
    private function deleteuserimages($id, $image)
    {
        $uplode_image_path = public_path(self::userprofiledirpath());

        //Unlik file
        if(!empty($image) && File::exists($uplode_image_path.'/'.$image))
        {
            unlink($uplode_image_path.'/'.$image);
        }

        Userimage::where('id', $id)->delete();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteuserimage($user_id, $id)
    {

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'users', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }


        $user = User::find($user_id);

        if(!$user){

            return abort(404);
            
        }

        $get_image_detail = Userimage::find($id);

        $uplode_image_path = public_path(self::userprofiledirpath());

        //Unlik file
        if(!empty($get_image_detail->image) && File::exists($uplode_image_path.'/'.$get_image_detail->image))
        {
            unlink($uplode_image_path.'/'.$get_image_detail->image);
        }

        Userimage::where('id', $id)->delete();

        return redirect()->back()->with('success', trans('messages.User image has been successfully deleted'));
    }

    public function deleterestaturantimage($user_id, $id)
    {

        //Check permission access or not
        if(!$this->checkPermission(Auth::user()->role_id, 'users', 'is_delete'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }


        $user = Restaurantdetail::find($id);

        if(!$user){

            return abort(404);
            
        }

        $get_image_detail = Restaurantgallery::find($id);

        $uplode_image_path = public_path().'/uploads/restaurants/gallery/';

        //Unlik file
        if(!empty($get_image_detail->image) && File::exists($uplode_image_path.'/'.$get_image_detail->image))
        {
            unlink($uplode_image_path.'/'.$get_image_detail->image);
        }

        Restaurantgallery::where('id', $id)->delete();

        return redirect()->back()->with('success', trans('messages.Restaturents image has been successfully deleted'));
    }
}
