<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Models\UserImage;
use App\Models\UserVote;
use App\Models\Page;
use App\Models\Dish;
use App\Models\Blockuser;
use App\Models\Transaction;
use App\Models\Providerdeal;
use App\Models\Deal;
use App\Models\Invite;
use App\Models\Friend;
use App\Models\Restaurantdetail;
use App\Models\Restauranttype;
use Aws\Ses\SesClient;
use Aws\Exception\AwsException;
use App\Models\Sociallink;
use App\Models\Comment;

class Controller extends BaseController
{
	use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	
    protected $default_firebase_user_path = '/Users';			
		
    protected $successStatus = 200, $notauthorized = 401;

    /**
     * Get the specified user detail.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

	public function getUserPermissuuions(){
		$user=Auth::user();
		$permissions=DB::table('site_permissions')
		->select('managers.*')
		->join('managers','managers.id','=','site_permissions.manager_id')
		->where('site_permissions.role_id',$user->role_id)
		->where('site_permissions.is_add',1)
		->get();
		return $permissions;
	}

	public function SaveUserActivity($activity){
		$status = DB::table('user_activities')->insert([
			'role_id'=>Auth::user()->role_id,
			'activities'=>$activity,
			'user_id'=>Auth::user()->id,
			'created_at'=>date('Y-m-d H:i:s'),
			'updated_at'=>date('Y-m-d H:i:s'),
		]);
	}

	public function UserActivity($activity,$user_data_id){
		$status = DB::table('user_data_activities')->insert([
			'role_id'=>Auth::user()->role_id,
			'activities'=>$activity,
			'user_id'=>Auth::user()->id,
			'user_data_id'=>$user_data_id,
			'created_at'=>date('Y-m-d H:i:s'),
			'updated_at'=>date('Y-m-d H:i:s'),
		]);
	}
    public function getuserDetail($id)
    {
    	return User::find($id);
    }
	
	
    /**
     * Get the specified page detail.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getpageDetail($id)
    {
    	return Page::find($id);
    }

    /**
     * Count users
     *
     **/
    public function countusers()
    {
        return User::where('role_id', 1)->count();
    }


    //Api

    protected function userID()
    {  
        return auth('api')->user()->id;
    }

    protected function userdetail()
    {  
        return auth('api')->user();
    }


    protected function outputJSON($result = null, $responseCode = 200) {
     
        return response()->json($result, $responseCode);
    }


    protected function sendoutputJSON($result = null, $message = '', $responseCode = 200) {
     
        if ($message != '') $response["message"] = $message;
        if ($result != null) $response["data"] = $result;
     
        return response()->json($response, $responseCode);
    }


    public function authentification()
    {
        if (!Auth::guard('api')->check()) { 
            $response = [
                'message' => 'Unauthenticated',                
            ];            
            header('Content-type: application/json');            
            echo json_encode($response, 401);
            exit();
        }else{
            return auth('api')->user();
        } 
    }

	function btwoccrypt( $string, $action = 'e' ) {
		
		$secret_key = 'my_simple_secret_key';
		$secret_iv = 'my_simple_secret_iv';
	 
		$output = false;
		$encrypt_method = "AES-256-CBC";
		$key = hash('sha256', $secret_key);
		$iv = substr(hash('sha256', $secret_iv ), 0, 16);
	 
		if( $action == 'e' ) {
			$output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
		}
		else if( $action == 'd' ){
			$output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
		}
	 
		return $output;
	}
	
	public function b2cauthentification()
	{
		
		if(!isset($_SERVER["HTTP_AUTHORIZATION"])){			
			$response = [
                'message' => 'Unauthenticated', 
				'invalid_token' => true,	
            ];    
			http_response_code(401);	
            header('Content-type: application/json');            
            echo json_encode($response, 401);
            exit();
		}
		
		$AuthChk=explode(" ",$_SERVER["HTTP_AUTHORIZATION"]);
		if(isset($AuthChk['0']) && $AuthChk['0'] != 'Bearer'){
			$response = [
                'message' => 'Unauthenticated',
				'invalid_token' => true,	
            ];       
			http_response_code(401);	
            header('Content-type: application/json');            
            echo json_encode($response, 401);
            exit();
		}
		elseif(isset($AuthChk['1']) && $AuthChk['1'] != ''){			
			$access_token = json_decode($this->btwoccrypt(trim($AuthChk['1']),'d'));
			
			$tokenData=DB::table('oauth_access_tokens')->where('id',$access_token->b2c)->where('user_id',$access_token->ag)->first();
            if($tokenData === null) {
				$response = [
					'message' => 'Unauthenticated',
					'invalid_token' => true,	
				];       
				http_response_code(401);	
				header('Content-type: application/json');            
				echo json_encode($response, 401);
				exit();
			}
			$user_data = User::where('id', $access_token->ag)->first();
			if($user_data === null) {
				$response = [
					'message' => 'Identifiant invalide',
					'is_account_deleted'=>true,
                    'is_account_suspended'=>false	
				];				
				http_response_code(401);	
				header('Content-type: application/json');            
				echo json_encode($response, 401);
				exit();
			}
			elseif($user_data->status == false) {
				$response = [
					'message' => 'Identifiant invalide',
					'is_account_deleted'=>false,
                    'is_account_suspended'=>true
				];				
				http_response_code(401);	
				header('Content-type: application/json');            
				echo json_encode($response, 401);
				exit();
			}
			else{
				return $access_token->ag;
			}		
									
		}
		else
		{
			$response = [
                'message' => 'Unauthenticated',
				'invalid_token' => true,	
            ];          
			http_response_code(401);
            header('Content-type: application/json');            
            echo json_encode($response, 401);
            exit();
		}
	}
	
	public function bookingNumber() {
		$order = Transaction::select('id')->orderBy('id', 'desc')->first();
		if(!empty($order)){
			$order_id = $order->id;
		}else{
			$order_id = 1;
		}		
        $number = strtoupper('ENM' . rand('999', '100') . ($order_id + 1));
        return $number;
    }
	
	public function distanceCalculation($add_lat, $add_long, $user_lat, $user_long, $decimals = 1) {
		// Calculate the distance in degrees
		// echo $add_lat.','. $add_long.','. $user_lat.','. $user_long.'<br/>';
		$theta = $user_long - $add_long;
		$dist = sin(deg2rad($user_lat)) * sin(deg2rad($add_lat)) +  cos(deg2rad($user_lat)) * cos(deg2rad($add_lat)) * cos(deg2rad($theta));
		$dist = acos($dist);
		$dist = rad2deg($dist);
		$miles = $dist * 60 * 1.1515;

		$distance = $miles * 1.609344;
		return round($distance, $decimals);
	}
	
	public function allblockunblock($userID = null){
		
		$blocked=array(1);
		$friends = Blockuser::select('id','block_id','user_id')->where('user_id', $userID)->orWhere('block_id', $userID)->get();
		$blockedfriends = Blockuser::select('id','block_id','user_id')->where('user_id', $userID)->orWhere('block_id', $userID)->get();
		
		if(!empty($friends)){
			foreach ($friends as $val){
				if($val->block_id==$userID){
				$blocked[] = $val->user_id;
				}
				else{
				$blocked[] = $val->block_id;
				}
			}
		}
		if(!empty($blockedfriends)){
			foreach ($blockedfriends as $val){
				if($val->block_id==$userID){
				$blocked[] = $val->user_id;
				}
				else{
				$blocked[] = $val->block_id;
				}
			}
		}
			
		$blocked = array_unique($blocked);
		$blocked = array_unique(array_merge($blocked,array('1')));
		return $blocked;		
	}
	
	public function allInvited($userID = null){
		
		$alreadyinvited = array();
		$alreadyinvitedusers = Invite::where([['invite_id','=',$userID]])->get();
		foreach($alreadyinvitedusers as $invited) 
		{				
			$alreadyinvited[] = $invited->user_id;				
		}
		$alreadyinvitedmeusers = Invite::where([['user_id','=',$userID]])->get();
		foreach($alreadyinvitedmeusers as $invited) 
		{				
			$alreadyinvited[] = $invited->invite_id;				
		}
		
		$alreadyfriendusers = Friend::where([['user_id','=',$userID],['req_accept_status','=','1'],['req_sent_status','=','1']])->orWhere([['recipient_id','=',$userID],['req_accept_status','=','1'],['req_sent_status','=','1']])->get();
		
		foreach ($alreadyfriendusers as $invited) 
		{
			if($userID == $invited->recipient_id)
			{
				$alreadyinvited[] = $invited->user_id;
			}
			else
			{
				$alreadyinvited[] = $invited->recipient_id;
			}
		}
		
		return array_unique($alreadyinvited);		
	}
	
	public function allInActiveUser(){
		
		$inactvies=array(1);
		$usersArray = User::select('id')->where('status', 0)->get();
		
		if(!empty($usersArray)){
			foreach ($usersArray as $val){
				$inactvies[] = $val->id;
			}
		}
			
		$inactvies = array_unique($inactvies);
		return $inactvies;		
	}
	
	public function sendAwsMail($from_mail,$to_mail,$descriptionbody,$text_data,$subject,$sender_name = false,$receiver_name = false){
		$response_arr = array();
		$ses_client = SesClient::factory(array(
			'version'=> 'latest',
			'region' => 'eu-west-2',
			'credentials' => array(
				'key' => 'AKIAVS3LDQGOHYIIDP6F',
				'secret'  => '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'
			) 
		));
		
		$FromAddresses = "$sender_name <$from_mail>";
		try {
			$result = $ses_client->sendEmail([
			'Source'=>$FromAddresses,
			'Destination' => [
				'ToAddresses' => [
				$to_mail,
				],
			],
			'Message' => [
				'Body' => [
					'Html' => [
						'Charset' => 'UTF-8',
						'Data' => $descriptionbody,
					],
					'Text' => [
						'Charset' => 'UTF-8',
						'Data' => $text_data,
					],
				],
				'Subject' => [
					'Charset' => 'UTF-8',
					'Data' => $subject,
				],
			],
			]);

		
		$response_arr['is_send'] = true;
		} catch (\Exception $e) {
		$response_arr['is_send'] = false;
		$response_arr['error'] = $e->getMessage();
			
		}
		return $response_arr;
	}

	public function blankIfNull($value)
    {
    	if ($value == null || $value == "NULL" || $value == NULL ) 
    	{
    			$value = '';
    	}
    	return 	$value;
    }

    /*function stringToSlugUnique($str, $modelName, $fieldName) {
        $str = substr(strtolower($str), 0, 35);
		$randomStr = mt_rand(1, 1000);
		$check = DB::table($modelName)->where($fieldName,$str)->count();
        if ($check>0) {
           $randomnumber = mt_rand(1, 10000);
            $str = $this->stringToSlugUnique($str . '-' . $randomnumber, $modelName, $fieldName);
        } 		
        $strRandom = $str.'-'. $randomStr;
		return $strRandom;
    }
	Call : $slug = $this->stringToSlugUnique($first_name,'users','slug');
	*/
	
	function stringToSlugUnique() {
        $str = 'user';
		$digits = 6;
        $randomStr=rand(pow(10, $digits-1), pow(10, $digits)-1);
		
		$check = DB::table('users')->where('username',$str.'-'.$randomStr)->count();
        if ($check>0) {
            $randomStr=rand(pow(10, $digits-1), pow(10, $digits)-1);
            $this->stringToSlugUnique();
        } 		
        $strRandom = $str.'-'.$randomStr;
		return $strRandom;
    }
	
	
	# https://github.com/ktamas77/firebase-php is used for help

	public function getFirebaseConnection(){
		
		$defualt_url = 'https://rankonline-505e4-default-rtdb.firebaseio.com';
		$default_token = 'FFnVZpHsvM73VZvh59i5mrYCdf6pMaPc9eJwcAd8';
		
		$firebase = new \Firebase\FirebaseLib($defualt_url,$default_token);
        
        return $firebase;		
    }
	
	public function getUserDetailFirebase($userID){
		$firebaseconnection = $this->getFirebaseConnection();		
		$data=$firebaseconnection->get($this->default_firebase_user_path.'/'.$userID);
		$user_firebase_match_data = json_decode($data,true);
		return $user_firebase_match_data;
	}
	
	/**
	 * Data struction for update or Store data on firebase 
	 * 
	 * $dataArray=array(
	 *		'user_id'=>$userID,
	 *		'token_id'=>'',
	 *		'username'=>'',
	 *		'first_name'=>'',
	 *		'last_name'=>'',
	 *		'email'=>'',
	 *		'status'=>1,
	 *		'recent_share_click_date_time'=>time(),
	 *		'block_list'=>'',
	 *		'total_unread_notification'=>0,
	 *	);
	 * 
	 */
    public function storeOrUpdateDataFirebase($userID,$dataToStore){
		$status = false;
        $firebaseconnection = $this->getFirebaseConnection();		
        $data[$userID] = $dataToStore;			
        
        $storeStatus = $firebaseconnection->update($this->default_firebase_user_path,$data);
        if($storeStatus){
            $status = true;
		}
		return $status;
	}

	public function updateInviteCountFireBase($userID,$alreadyinvited)
	{
		$status = false;
		$firebaseconnection = $this->getFirebaseConnection();

		$userDataFirebase = $this->getUserDetailFirebase($userID);
		
		$allblockuserarray = $this->allblockunblock($userID);
		$inactiveusers = $this->allInActiveUser();
		$allblockuser = array_unique(array_merge($allblockuserarray,$inactiveusers));
					
		// echo '<pre>'; print_r($userDataFirebase);die;
		$totalunreadNotification = DB::table('user_notifications')->where([['to_user_id','=',$userID],['is_readed','=',0]])->count();
		$user = User::find($userID);
		$totalCommentCounter = Comment::where('commented_to',$userID)->where('parent_comment_id',0)->whereNotIn('commented_by',$allblockuser)->count();
		$firend_requests='';
		if(!empty($alreadyinvited)){
			$firend_requests=implode(',',$alreadyinvited);
		}
		
		$dataToStore = array(
			'email' => $user->email,
			'status' => $user->status,
			'user_id' => $userID,
			'token_id' => $user->token_id,
			'username' => $user->username	,
			'end_time' => $userDataFirebase['end_time'],
			'last_name' => $user->last_name,
			'first_name' => $user->first_name,
			'start_time' => $userDataFirebase['start_time'],
			'boost_countdown_start'=>(isset($userDataFirebase['boost_countdown_start']) && !empty($userDataFirebase['boost_countdown_start'])) ? $userDataFirebase['boost_countdown_start'] : '',
			'boost_countdown_end'=>(isset($userDataFirebase['boost_countdown_end']) && !empty($userDataFirebase['boost_countdown_end'])) ? $userDataFirebase['boost_countdown_end'] : '',
			'vote_limit' => $userDataFirebase['vote_limit'],
			'block_list' => $userDataFirebase['block_list'],
			'total_comments' => $totalCommentCounter,
			'super_snap_count' => $userDataFirebase['super_snap_count'],
			'total_vote'=>(isset($userDataFirebase['total_vote']) && !empty($userDataFirebase['total_vote'])) ? $userDataFirebase['total_vote'] : 0,
			'is_mobile_verified' => $userDataFirebase['is_mobile_verified'] ?? 0,
			'is_email_verified' => $userDataFirebase['is_email_verified'] ?? 0,
			'recent_share_click_date_time' => $userDataFirebase['recent_share_click_date_time'],
			'total_unread_notification' => $totalunreadNotification,
			'firend_requests'=>$firend_requests,
		);

		$data[$userID] = $dataToStore;

		$storeStatus = $firebaseconnection->update($this->default_firebase_user_path,$data);
        if($storeStatus){
            $status = true;
		}

		return $status;
	}

	public function updateUnreadNotificationCountFireBase($userID)
	{
		$status = false;
		$firebaseconnection = $this->getFirebaseConnection();

		$userDataFirebase = $this->getUserDetailFirebase($userID);
		
		$allblockuserarray = $this->allblockunblock($userID);
		$inactiveusers = $this->allInActiveUser();
		$allblockuser = array_unique(array_merge($allblockuserarray,$inactiveusers));
					
		// echo '<pre>'; print_r($userDataFirebase);die;
		$totalunreadNotification = DB::table('user_notifications')->where([['to_user_id','=',$userID],['is_readed','=',0]])->count();
		$user = User::find($userID);
		$totalCommentCounter = Comment::where('commented_to',$userID)->where('parent_comment_id',0)->whereNotIn('commented_by',$allblockuser)->count();

		$dataToStore = array(
			'email' => $user->email,
			'status' => $user->status,
			'user_id' => $userID,
			'token_id' => $user->token_id,
			'username' => $user->username	,
			'end_time' => $userDataFirebase['end_time'],
			'last_name' => $user->last_name,
			'first_name' => $user->first_name,
			'start_time' => $userDataFirebase['start_time'],
			'boost_countdown_start'=>(isset($userDataFirebase['boost_countdown_start']) && !empty($userDataFirebase['boost_countdown_start'])) ? $userDataFirebase['boost_countdown_start'] : '',
			'boost_countdown_end'=>(isset($userDataFirebase['boost_countdown_end']) && !empty($userDataFirebase['boost_countdown_end'])) ? $userDataFirebase['boost_countdown_end'] : '',
			'vote_limit' => $userDataFirebase['vote_limit'],
			'block_list' => $userDataFirebase['block_list'],
			'total_comments' => $totalCommentCounter,
			'super_snap_count' => $userDataFirebase['super_snap_count'],
			'total_vote'=>(isset($userDataFirebase['total_vote']) && !empty($userDataFirebase['total_vote'])) ? $userDataFirebase['total_vote'] : 0,
			'is_mobile_verified' => $userDataFirebase['is_mobile_verified'] ?? 0,
			'is_email_verified' => $userDataFirebase['is_email_verified'] ?? 0,
			'recent_share_click_date_time' => $userDataFirebase['recent_share_click_date_time'],
			'total_unread_notification' => $totalunreadNotification,
			'firend_requests'=>$userDataFirebase['firend_requests'] ?? '',
		);

		$data[$userID] = $dataToStore;

		$storeStatus = $firebaseconnection->update($this->default_firebase_user_path,$data);
        if($storeStatus)
        {
            $status = true;
		}
        // echo '<pre>'; print_r($storeStatus);die;
		return $status;
	}
	
	public function deteteDataFirebase($userID){
		$status=false;
		$firebaseconnection = $this->getFirebaseConnection();
		$firebase_match_data = $firebaseconnection->get($this->default_firebase_user_path.'/'.$userID);
									
		if($firebase_match_data!='null'){
			$status=$firebaseconnection->delete($this->default_firebase_user_path.'/'.$userID,array());										
		}
		return $status;
	}
	
	public function calculateRankOfUser($user_id){
				
		$rank=0;
		$sumOfPnXn=0;
		$sumOfPn=0;
		$x=0;
		$y=0;
		$z=0;
		$totalVotesGivenInPast7Days=0;
		$toalProfilePicture=UserImage::where('user_id',$user_id)->count();
		$currentDate = date('Y-m-d');
		$last7Day=date('Y-m-d', strtotime('-7 day', strtotime(date('Y-m-d'))));
		$totalVotes=UserVote::where('user_id',$user_id)->get();
		
		if(count($totalVotes) > 0 && count($totalVotes) >= 0){								
			$totalVotesGivenInPast7Days=UserVote::where('voter_id',$user_id)->where('created_at','>=',$last7Day)->count();
			$ap=1;
			foreach($totalVotes as $vote){
				$votedAgo = $this->daysDiffBetween(date('Y-m-d',strtotime($vote->created_at)),$currentDate);
				$coefficient = intval($vote->point);
				$votedUserRank = $vote->rank_of_voter;
				
				$xkival=$coefficient*(($votedUserRank - $votedAgo > 0) ? $votedUserRank - $votedAgo : 0);
				$sumOfPnXn = $sumOfPnXn+$xkival;
				$pkival=($votedUserRank - $votedAgo > 0) ? $votedUserRank - $votedAgo : 0;
				$sumOfPn = $sumOfPn+$pkival;
				$ap++;
			}
			if($sumOfPn > 0){
				$x = $sumOfPnXn / $sumOfPn;					
			}				
		}
		if($totalVotesGivenInPast7Days >= 300){
			$totalVotesGivenInPast7Days=300;
		}
		
		$y = $totalVotesGivenInPast7Days * 100 / 300;
		$z = $toalProfilePicture * 100 / 6;
		$xx=($x > 0) ? ($x / 100)*70 : 0;
		$yy=($y / 100)*20;
		$zz=($z / 100)*10;
		$rank = $xx + $yy + $zz;
		$FINALRANK=number_format($rank ,2);
		
		User::where('id',$user_id)->update([
			'rank' => $FINALRANK
		]);
		UserVote::where('voter_id',$user_id)->update([
			'rank_of_voter' => $FINALRANK
		]);		
		return true;		
	}
	
	public function daysDiffBetween($dt1, $dt2) {
		return date_diff(
			date_create($dt2),  
			date_create($dt1)
		)->format('%a');
	}
	
	protected function generalAppSettings($lc)
    {
        
        $settings = $this->siteSettings();

        $social_links = Sociallink::whereStatus(true)->get(['name','value','status'])->toArray();
        $data_arr = [];
        foreach($social_links as $thing)
        {
            $data_arr[str_replace("EmailTemplate.", "", $thing['name'])] = $thing['value'];
            $data_arr[str_replace("EmailTemplate.", "", $thing['name'])."_status"] = $thing['status'] ? true : false;
        }
		
		if($settings['site.paymentstatus']==true)
		{
			$data_arr['stripe_publishable_key'] = $settings['site.publishable_key'];
		}
		else
		{
			$data_arr['stripe_publishable_key'] = $settings['site.test_publishable_key'];
		}

		$data_arr['default_time_for_revote'] = $settings['site.default_time_for_revote'] ?? '';
		$data_arr['vote_point_after_purchase_premium'] = $settings['site.vote_point_after_purchase_premium'] ?? '';
		$data_arr['vote_point_after_rate_app'] = $settings['site.vote_point_after_rate_app'] ?? '';
		$data_arr['vote_point_after_watch_video'] = $settings['site.vote_point_after_watch_video'] ?? '';
		$data_arr['default_vote_limit'] = $settings['site.default_vote_limit'] ?? '';
		$data_arr['vote_point_after_share'] = $settings['site.vote_point_after_share'] ?? '';
 
		$data_arr['reportemail'] = $settings['site.reportemail'] ?? '';
        $data_arr['contactemail'] = $settings['site.contact_email_address'] ?? '';
        $data_arr['force_status'] = $settings['app.update'] ? true : false;
        $data_arr['force_status_ios'] = $settings['app.ios_update'] ? true : false;
        $data_arr['should_show_popup'] = $settings['app.should_show_popup'] ? true : false;
        $data_arr['app_version'] = $settings['app.version'] ?? '';
        $data_arr['app_version_ios'] = $settings['app.ios_version'] ?? '';
		$data_arr['conditions-generales-dutilisation'] = url('pages/conditions-generales-dutilisation'.'/'.$lc);
		$data_arr['confidentialite'] = url('pages/confidentialite'.'/'.$lc);
        
        return $data_arr;
	}



		
}
