<?php

namespace App\Http\Controllers;

use App\User;
use App\Models\Sociallink;
use App\Models\Userdevice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Traits\GeneralsettingTrait;
use App\Models\UserVotePoint;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	use GeneralsettingTrait;
    public function __construct()
    {
        $this->middleware('auth')->except(['saveshare','sendnotification','getUserProfile','shareUserProfile','storeAlreadyRegisterdUserFirebase','home']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
		return view('home');
    }
	
    # get User Profile data 

    public function getUserProfile($userName){
        try{
            if($userName == 'admin'){
                return redirect(route('admin_dashboard'));
            }
            $user=User::where('username',$userName)->with('userimages')->first();
            #echo '<pre>'; print_r($user);exit;
            $fb_link = Sociallink::where('name','EmailTemplate.fb_url')->first();
            
            return view('frontend.profile',compact('user','fb_link'));
        } catch (\Exception $e) {
            echo $e->getMessage();exit;
        }
    }
    
    # Share user profile code start from hare 
    
    public function shareUserProfile(Request $request,$share_id){
		
		$userIpAddress=$request->ip();
        try{
			
            $user=User::where('token_id',$share_id)->with('userimages')->first();
           
            //echo '<pre>'; print_r($user);exit;
            $fb_link = Sociallink::where('name','EmailTemplate.fb_url')->first();
            
            return view('frontend.share_profile',compact('user','fb_link','share_id','userIpAddress'));
        } catch (\Exception $e) {
            echo $e->getMessage();exit;
        }
    }

    public function saveshare(Request $request)
    {

        if($request->ajax())
        {
			$share_id = request('share_id');
            $userIpAddress = request('user_ip_address');
			
			$user=User::where('token_id',$share_id)->with('userimages')->first();
            $user_id=$user->id;
			$visitCounter=DB::table('profile_visitors')->where([['visitor_ip_address','=',$userIpAddress],['user_id','=',$user_id]])->count();
            // && $user->max_vote_limit==0
			if(!empty($user) && $visitCounter < 1){
                        
				DB::table('profile_visitors')->insert([
					'visitor_ip_address'=> $userIpAddress,
					'user_id'=> $user->id,
					'created_at'=> date('Y-m-d H:i:s'),
					'visited_at'=> date('Y-m-d H:i:s'),
					'updated_at'=> date('Y-m-d H:i:s'),
				]);
			
				#store Data on firebase server 
				$totalunreadNotification=DB::table('user_notifications')->where([['user_id','=',$user_id],['is_readed','=',0]])->count();
				$allblockuserarray = $this->allblockunblock($user_id);
				$blocklisteduser='';
				if(!empty($allblockuserarray)) $blocklisteduser = implode(',',$allblockuserarray);
				$userDataFirebase=$this->getUserDetailFirebase($user_id);
				$total_sender_vote = DB::table('user_votes')->where([['user_id','=',$user_id]])->count();	
				$dataToStore=array(
					'user_id'=>$user_id,
					'token_id'=> $user->token_id,
					'username'=>$user->username	,
					'first_name'=>$user->first_name,
					'last_name'=>$user->last_name,
					'email'=>$user->email,
					'status'=>$user->status,
					'start_time'=>$userDataFirebase['start_time'],
					'end_time'=>$userDataFirebase['end_time'],
					'boost_countdown_start'=>(isset($userDataFirebase['boost_countdown_start']) && !empty($userDataFirebase['boost_countdown_start'])) ? $userDataFirebase['boost_countdown_start'] : '',
					'boost_countdown_end'=>(isset($userDataFirebase['boost_countdown_end']) && !empty($userDataFirebase['boost_countdown_end'])) ? $userDataFirebase['boost_countdown_end'] : '',
					'vote_limit'=>intval($userDataFirebase['vote_limit']),
					'is_mobile_verified'=>$userDataFirebase['is_mobile_verified'] ?? 0,
					'is_email_verified'=>$userDataFirebase['is_email_verified'] ?? 0,
					'super_snap_count'=>$userDataFirebase['super_snap_count'],
					'recent_share_click_date_time'=>time(),
					'block_list'=>"$blocklisteduser",
					'total_vote'=>$total_sender_vote,
					'total_unread_notification'=>$totalunreadNotification,
					'total_comments'=>$userDataFirebase['total_comments'] ?? 0,
					'firend_requests'=>$userDataFirebase['firend_requests'] ?? '',
				);
				
				$this->storeOrUpdateDataFirebase($user_id,$dataToStore);

				# End code for store data on firebase 
				
				
				$UserDeviceList = Userdevice::select('*')->where('user_id', $user->id)->get();
				$title = "✅  A friend just clicked on your link.";
				$title_fr = "✅ Un ami vient de cliquer sur ton lien.";
				
				
				$andata = array("message" => $title,"user_id" => $user_id,"notify_type" => "VisitProfile");            
				$iosdata = array('alert' => array('body' => $title,"title"=>''),"user_id" => $user_id,'notify_type' => "VisitProfile");
				
				$andata_fr = array("message" => $title_fr,"user_id" => $user_id, "notify_type" => "VisitProfile");            
				$iosdata_fr = array('alert' => array('body' => $title_fr,"title"=>''),"user_id" => $user_id,'notify_type' => "VisitProfile");
				
				#echo '<pre>';print_r($UserDeviceList);exit;
				if($UserDeviceList)
				{	
					$totalunreadNotification = DB::table('user_notifications')->where([['to_user_id','=',$user->id],['is_readed','=',0]])->count();
					foreach($UserDeviceList as $UserDeviceData)
					{
						if(!empty($UserDeviceData->device_token))
						{
							if($UserDeviceData->device_type == "Android")
							{
								$token = $UserDeviceData->device_token;
								if($UserDeviceData->languagecode_id == 2){
									$this->pushAndroid($token,$andata_fr);
								}else{
									$this->pushAndroid($token,$andata);    										
								}
							}
							elseif(strtolower($UserDeviceData->device_type) == "ios")
							{
								$token = $UserDeviceData->device_token;
								$badge = $UserDeviceData->badge;	
								if($UserDeviceData->languagecode_id == 2){
									$this->pushIOS($token,$iosdata_fr,null,$totalunreadNotification);
								}else{
									$this->pushIOS($token,$iosdata,null,$totalunreadNotification);   										
								}                            	
							}   
						}   
					}
				}

            }
			
            $output['success'] = trans('messages.status_updated_successfully');

            return response()->json($output);
        }
		
		echo trans('messages.status_updated_successfully');

        return response()->json($output);
    }
	
	public function storeAlreadyRegisterdUserFirebase(){
        $users=User::get();
        $counter=0;
        foreach($users as $user){
             #store Data on firebase server 
             $totalunreadNotification=DB::table('user_notifications')->where([['user_id','=',$user->id],['is_readed','=',0]])->count();
             $allblockuserarray = $this->allblockunblock($user->id);
             $blocklisteduser='';
             if(!empty($allblockuserarray)) $blocklisteduser = implode(',',$allblockuserarray);
             $sitesetting = $this->siteSettings();
		     $snapchat_req_per_day=intval($sitesetting['site.snapchat_req_per_day']);
		
             $userVotePoints = UserVotePoint::where('user_id',$user->id)->first();
			 $total_sender_vote = DB::table('user_votes')->where([['user_id','=',$user->id]])->count();
             $dataToStore=array(
                 'user_id'=>$user->id,
                 'token_id'=> $user->token_id,
                 'username'=>$user->username	,
                 'first_name'=>$user->first_name,
                 'last_name'=>$user->last_name,
                 'email'=>$user->email,
                 'status'=>$user->status,
				 'start_time'=>'',
				 'end_time'=>'',
				 'boost_countdown_start'=>'',
				 'boost_countdown_end'=>'',
				 'is_mobile_verified'=>0,
			     'is_email_verified'=>0,
				 'super_snap_count'=>$snapchat_req_per_day,
				 'vote_limit'=>(intval($userVotePoints->max_vote_limit)) ?? 0,
                 'recent_share_click_date_time'=>'',
                 'block_list'=>"$blocklisteduser",
				 'total_vote'=>$total_sender_vote,
                 'total_unread_notification'=>$totalunreadNotification,
				 'total_comments'=>0,
             );
             
             $status=$this->storeOrUpdateDataFirebase($user->id,$dataToStore);
             if($status){
                 $counter++;
             }
             
        }
        echo '<center><h3> Total '.$counter.' records added/updated on firebase...</h3></center>';

    }
    
    # Push Notification related code start from hare 
	
	public function sendnotification(Request $request)
    {		
		
		/*$ios_device_token="A7AD11F25DCD9756E1ED659A504C88FC66B6790A6EA5D7EBEBE9813E6851CE0B";
		$android_device_token="eJ87OgAbVOU:APA91bFnCB55puSsJWTNlVjSNnTc49AWjJX3h-aIxkhnK0OV7HU3u-iOv3aULplTnGn4ncK5gI5KWQYrZCsnv9NzZ7haanMFvW_8aaYwGXPnZswZyVdL5mAYeSfVBIg6trWWlCzJ2Kd9";
		$message="Un nouvel événement vient d'être publié. Découvrez-le maintenant.";
		
		$response_data = array("chat_id" => 1,"unread_count" => 0,"user_id"=>1,"first_name"=>"delete chat","image_base_url"=>"");
		$android_data = array("total_unread_count" => 0,"title" => "Conf Plus Test", "message" => "Je vous prépare une série de jeux concours avec plein de lots à gagner pour vous aider durant l'externat. Le premier est avec Conf+. Tente de gagner un abonnement gratuit à l'année. ","user_id" => 1,'sender_id'=> 1, "notify_type" => "adminNotify","result_data"=>$response_data);
		$iosdata = array('alert' => array('body' => "Je vous prépare une série de jeux concours avec plein de lots à gagner pour vous aider durant l'externat. Le premier est avec Conf+. Tente de gagner un abonnement gratuit à l'année. ", 'title' => "Basic user notification Test"),"total_unread_count" => 0, "user_id" => 609, "sender_id" => 1, 'notify_type' => "adminNotify", "result_data" => $response_data);
						
	    echo "babashdhs__".$this->basicpushIOS($ios_device_token,$iosdata,0); 
		exit;*/
        $notification_data = DB::table('notification_sent_records')
                            ->where('status', false)
                            ->orderBY('id',  'desc')
                            ->get();

        foreach($notification_data as $notification){
            
            $all_message= json_decode($notification->message);        
            $total_user_ids = explode(",",$notification->user_ids);
            
            if(!empty($notification->sent_user_ids)){
                $total_sent_user_ids = explode(",",$notification->sent_user_ids);
            }else{
                $total_sent_user_ids = array();
            }
            
            $PfplaArgument =array();    
            
            //$UserNotifications = DB::table('user_notifications');      
            
            foreach($all_message as $key=> $all_message_data){       
               				
                if($all_message_data->device_type=="Android" && $key<=30){

                    $total_sent_user_ids[]= $all_message_data->notification_data->user_id;
                    
                    $androiddata = (array)$all_message_data->notification_data;
                    
                    /*$userNotifications_data = DB::table('user_notifications')->where('related_id', $notification->notification_id)
                        ->where(['model'=> 'Notification', 'user_id'=> $androiddata['user_id'], 'related_id' => $notification->notification_id])
                        ->orderBy('id', 'desc')
                        ->first();
                    
                    if (empty($userNotifications_data)) {
                        $create = DB::table('user_notifications')->insert([
                            'user_id' => $androiddata['user_id'],
                            'related_id' => $notification->notification_id,
                            'model' => 'Notification',                         
                            'status' => 1,    
                            'notification' => $androiddata['message'],
                            'form_user_id' => 1,
                            'to_user_id' => $androiddata['user_id'],
                        ]);                        
                    }*/
                    
                    $token = $all_message_data->device_token;              
                    $results = $this->homepushAndroid($token, $androiddata);
					
                }else if(strtolower($all_message_data->device_type)=="ios" && $key<=30){                    
                    $total_sent_user_ids[]= $all_message_data->notification_data->user_id;                    
                    $iosdata = json_decode(json_encode($all_message_data->notification_data), true);                    
                    $token = $all_message_data->device_token;              
                    
                    /*$userNotifications_data = DB::table('user_notifications')->where('related_id', $notification->notification_id)
                        ->where(['model'=> 'Notification', 'user_id'=> $iosdata['user_id'], 'related_id' => $notification->notification_id])
                        ->orderBy('id', 'desc')
                        ->first();

                    if (empty($userNotifications_data)) {                        
                        $create = DB::table('user_notifications')->insert([
                            'user_id' => $iosdata['user_id'],
                            'related_id' => $notification->notification_id,
                            'model' => 'Notification',                         
                            'status' => 1,    
                            'notification' => $iosdata['alert']['body'],
                            'form_user_id' => 1,
                            'to_user_id' => $iosdata['user_id'],
                        ]); 
                    }*/
					
					if($all_message_data->role==1){
						$this->basicpushIOS($token,$iosdata,0);
					}elseif($all_message_data->role==2 || $all_message_data->role==3){
						$this->propushProIOS($token,$iosdata,0);
					}
                                             
                }
                
                if($key >=31){

                    if($all_message_data->device_type=="Android"){
                        $data = $all_message_data->notification_data;   
                        $token = $all_message_data->device_token;
                        $PfplaArgument[]= array('device_type'=>"Android","device_token"=>$token,"notification_data"=>$data);
                    }else if(strtolower($all_message_data->device_type)=="ios"){                        
                        $iosdata = $all_message_data->notification_data;    
                        $token = $all_message_data->device_token;
                        $PfplaArgument[]= array('device_type'=>"Android","device_token"=>$token,"notification_data"=>$iosdata);
                    }
                }
            }   
                    
            if(!empty($total_sent_user_ids)){  
                DB::table('notification_sent_records')->where('id', $notification->id)->update([
                        'message' => json_encode($PfplaArgument, JSON_UNESCAPED_UNICODE),
                        'sent_user_ids' => implode(",", array_unique($total_sent_user_ids))
                ]);
            }

            if(count($total_user_ids) == count(array_unique($total_sent_user_ids))){                
                DB::table('notification_sent_records')->where('id', $notification->id)->update([
                        'status' => 1
                ]);  
            }
        }
		
		echo 'Notification sent successfully.';
    }
	
	public function homepushAndroid($registration_id = null, $data = null)
    {  
        
        $url = 'https://fcm.googleapis.com/fcm/send';
        
        if(is_array($registration_id)){
            
            $fields = array(
                'registration_ids' => $registration_id,
                'data' => $data,
                'time_to_live' => 9000,
                'delay_while_idle' => true,
                'priority' => 'high',
                'ttl' => 3600,
                'timestamp' => 3600,
                'sound' => 'default'
            );

        }else{

            $fields = array(
                'to' => $registration_id,
                'data' => $data,
                'ttl' => 3600,
                'timestamp' => 3600,
                'sound' => 'default'
            );
        }

        $headers = array(
            'Authorization: key= AAAAcf4-TM0:APA91bGe5FYfg9Z0jAClpmW2WHxrxesLiL4qi62Mz0qoBz_aZMOAp0SWiaOnz7_uDbNVvHSUnSnJjFkHCd2t3qk8PBxgyc_wEaik9qUM0pTOpmV-PW6z5gfO4cS_8Gb-VisqIVp6bhsT',
            'Content-Type: application/json'
        );

        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);

        if ($result === FALSE) {
            $error = '0';
            return ($error);
            die('Curl failed: ' . curl_error($ch));
            //curl_get_info();
        }
        // Close connection
        curl_close($ch);
    }	
	
	public function basicpushIOS($registration_id = null, $data = null,$badge=NULL){
		$passphrase = '12345';
		$pemFile = public_path('/APNSCertEatUser_Live.pem');
		$ctx = stream_context_create();
		stream_context_set_option($ctx, 'ssl', 'local_cert',  $pemFile);
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
		
		/*production mode*/
		// echo $registration_id;die;
		// Open a connection to the APNS server
		$fp = stream_socket_client(
		'ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
		
		//if (!$fp)
		//exit("Failed to connect: $err $errstr" . PHP_EOL);
		
		$data['sound'] = 'default';
		$data['badge'] = $badge;
		//$data['content-availabel'] = true;		
		$body['aps'] = $data;
		
		// Encode the payload as JSON
		$payload = json_encode($body);
		$msg = chr(0) . pack('n', 32) . pack('H*', $registration_id) . pack('n', strlen($payload)) . $payload;
		
		// Send it to the server
		$result = fwrite($fp, $msg, strlen($msg));
		
		if (!$result){	
			//echo 'Message not delivered' . PHP_EOL;
			//print_r($result);die;
		}
		// echo $registration_id;die;
		fclose($fp);
		/*production mode*/		
	}
	
	public function propushProIOS($registration_id = null, $data = null,$badge=NULL){
		$passphrase = '12345';
		$pemFile = public_path('/APNSEatManager_Live.pem');
		$ctx = stream_context_create();
		stream_context_set_option($ctx, 'ssl', 'local_cert',  $pemFile);
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
		
		/*production mode*/
		// echo $registration_id;die;
		// Open a connection to the APNS server
		$fp = stream_socket_client(
		'ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
		
		//if (!$fp)
		//exit("Failed to connect: $err $errstr" . PHP_EOL);
		
		$data['sound'] = 'default';
		$data['badge'] = $badge;
		//$data['content-availabel'] = true;		
		$body['aps'] = $data;
		
		// Encode the payload as JSON
		$payload = json_encode($body);
		$msg = chr(0) . pack('n', 32) . pack('H*', $registration_id) . pack('n', strlen($payload)) . $payload;
		
		// Send it to the server
		$result = fwrite($fp, $msg, strlen($msg));
		
		if (!$result){	
			//echo 'Message not delivered' . PHP_EOL;
			//print_r($result);die;
		}
		// echo $registration_id;die;
		fclose($fp);
		/*production mode*/		
	}
    
}
