<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use GuzzleHttp\Psr7\Request;
use Session;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    
    protected function redirectTo()
    {
       if(Auth::user()->role_id==3){
            $subscriptionTransectionDetail= \DB::table('transactions')
            ->select('transactions.*')
            ->where([['transactions.user_id','=',Auth::user()->id],['transactions.subscription_type','=','Paid']])
            ->orderBy('id', 'desc')
            ->limit(1)
            ->get()->toArray();
           
            if(count($subscriptionTransectionDetail) > 0){
                $start_dt=strtotime(current($subscriptionTransectionDetail)->start_datetime);
                $end_dt=strtotime(current($subscriptionTransectionDetail)->end_datetime);
                $remainDays=date_diff( 
                    date_create(current($subscriptionTransectionDetail)->end_datetime),
                    date_create(date('Y-m-d H:i:s'))
                )->format('%a');
                if($remainDays > 0 && $end_dt >= time()){
                   return '/admin';
                }else{
                    return '/route-accept-terms';
                }

            }else{
            return '/route-accept-terms';  
            }  
            
        }
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
}
