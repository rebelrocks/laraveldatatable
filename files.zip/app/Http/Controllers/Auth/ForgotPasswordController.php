<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Support\Str;
use \Mailjet\Resources;
use Carbon\Carbon;
use Helper;
use DB;
use App\Models\Emailtemplate;
use App\Models\Sociallink;
use App\Traits\Sociallink\SociallinkTrait;
use App\Traits\GeneralsettingTrait;
use App\User;
use Aws\Ses\SesClient;
use Aws\Exception\AwsException;


class ForgotPasswordController extends Controller
{

    use SociallinkTrait, GeneralsettingTrait;

    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    /**
     * Display the form to request a password reset link.
     *
     * @return \Illuminate\Http\Response
     */
    public function showLinkRequestForm()
    {
        return view('auth.passwords.email');
    }


    /**
     * Send a reset link to the given user.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\JsonResponse
     */
    public function sendResetLinkEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ],[
            'email.exists' => trans('passwords.user'),
        ]);


        $email = request('email');

        $user = User::where('email', $email)->first();

            $getuser = $this->getuserdetailbyEmail($email);
        if(!$user){

            return back()->with('email', trans('passwords.user'));
        }

        //Checked exceptions
        try {
            
            $check_token = DB::table('password_resets')->where('email', $email)->first();
        
            if($check_token){
                //Delete password token
                DB::table('password_resets')->where('email', $email)->delete();
            }

            $emailtemplate  = Emailtemplate::where('id', 1)->first();

            // $emailtemplate = $this->getforgotpasswordDetail();


            $image_path = url('application/public/uploads/emailtemplates');

            $header_image = $image_path.'/'.$emailtemplate->header_image;

        // echo '<pre>'; print_r($emailtemplate);die('sa');
            //Get user detail 
            $getuser = $this->getuserdetailbyEmail($email);

            $first_name  = $getuser->first_name ?? '';
            
            //$email  = $getuser->email ?? '';

            $new_token = $this->token();

            $reset_link_url = url(config('app.url').route('password.reset', ['token' => $new_token, 'email' => $email], false));

            //Get support email
            $support_email_id = $this->getsupportEmail()->value ?? '';
            //Get contact email
            $contact_email_id = $this->getcontactEmail()->value ?? '';
            //Get sender email
            $senderemail = $this->getsenderEmail()->value ?? '';
            
            //replace template var with value
            $token = array(
                '##MAIN_COLOR##'  => '#'.$emailtemplate->main_color,
                '##HEADER_IMAGE##' => $header_image,
                '##FIRST_NAME##' => ucwords($first_name),
                '##SUPPORT_EMAIL##' => $support_email_id,
                '##SITE_NAME##' => Helper::getapplicationName(),
                '##SECONDARY_COLOR##' => '#'.$emailtemplate->secondary_color,
                '##CONTACT_EMAIL##' => $contact_email_id,
                '##YEAR##' => date('Y'),
                '##FB_LINK##' => $this->fbpage(),
                '##TWITTER_LINK##' => $this->twitterpage(),
                '##INSTA_LINK##' => $this->instagrampage(),
                '##WEBSITE##' => $this->websitepageurl(),
                '##LINKEDIN_LINK##' => $this->linkedinpageurl(),
                '##PWD_LINK##' => $reset_link_url,
            );

            $pattern = '[%s]';

            foreach($token as $key=>$val)
            {
                $varMap[sprintf($key)] = $val;
            }
            
            $emailContent = strtr($emailtemplate['description'],$varMap);
        // echo '<pre>'; print_r($emailtemplate);die('dcdsf');
            //Email template content end

            //Create New Password Reset Token
            DB::table('password_resets')->insert([
                'email' => $email,
                'token' => $new_token,
                'created_at' => Carbon::now()
            ]);

            //Get the token just created above
            $tokenData = DB::table('password_resets')->where('email', $email)->first();

            $app_name = Helper::getapplicationName();
            


            $subject =  str_replace('##SITE_NAME##', $app_name, 'Forget Password');

            // $mj = new \Mailjet\Client(getenv('MJ_APIKEY_PUBLIC'), getenv('MJ_APIKEY_PRIVATE'));
            $settings = Helper::siteSettings();
            $TextPart = $emailtemplate->text_part;
		   // echo '<pre>'; print_r($settings);die('sda');

            $from_mail = $settings['site.sending_email_address'];
            $sender_name = $emailtemplate->sender_name;
            $FromAddresses = "$sender_name <$from_mail>";
            $toAddress = $email;
            // $toAddress = "dominiquefra58@gmail.com";;
            // echo $toAddress; die('dfds');


            $ses_client = SesClient::factory(array(
                'version'=> 'latest',
                'region' => 'eu-west-2',
                'credentials' => array(
                    'key' => 'AKIAVS3LDQGOHYIIDP6F',
                    'secret'  => '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'
                ) 
            ));

            try {
                    $result = $ses_client->sendEmail([
                    'Source'=>$FromAddresses,
                    'Destination' => ['ToAddresses' => [$toAddress,],],
                    'Message' => ['Body' => ['Html' => ['Charset' => 'UTF-8','Data' => $emailContent,],
                                'Text' => ['Charset' => 'UTF-8','Data' => $TextPart,],],
                        'Subject' => ['Charset' => 'UTF-8','Data' => $subject,],],
                    ]);

                    // echo '<pre>'; print_r($result);die;

                } catch (\Exception $e) {
                    //echo $e->getMessage();exit;
                }


            return redirect()->back()->with('status', trans('A reset link has been sent to your email address.'));

        } catch (\Exception $e) {
            // echo '<pre>'; print_r($e->getMessage());  
            // die('sdff');
            
            return redirect()->back()->withErrors(['error' => trans('A Network Error occurred. Please try again.')]);
        }
    }

    /**
     * Validate the email for the given request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    protected function validateEmail(Request $request)
    {
        $request->validate(['email' => 'required|email']);
    }


    /**
     * Send reset password email notification
     *
     */

    private function sendResetEmail($email, $token)
    {

        //Retrieve the user from the database
        $user = User::where('email', $email)->first();

        //Generate, the password reset link. The token generated is embedded in the link
        $link = config('base_url') . 'password/reset/' . $token . '?email=' . urlencode($user->email);

        try {

            Notification::send($user, new ResetPassword($user));
            //Here send the link with CURL with an external email API 
            return true;

        } catch (\Exception $e) {

            return false;
        }    
    }



    /**
     * Forget password email template detail
     * @return \Illuminate\Http\Response
     */
    private function getforgotpasswordDetail()
    {
        return Emailtemplate::where('title', 'forgot_password')->first();
    }



    /** 
     * Get user by email
     * @return \Illuminate\Http\Response
     */
    private function getuserdetailbyEmail($email)
    {
        return User::where('email', $email)->first(['id', 'email', 'first_name', 'last_name']);
    }



    /**
     * Generate ramdom token number
     * @return \Illuminate\Http\Response
     */
    private function token()
    {
        return Str::random(60);
    }
}
