<?php

namespace App\Http\Controllers\API\V1\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use App\User;
use Laravel\Passport\Passport;
use App\Traits\LanguagecodeTrait;
use App\Traits\LoginTrait;
use App\Models\Userdevice;
use Helper;
use Exception;

class UserloginController extends Controller
{

    use LanguagecodeTrait, LoginTrait;

    public $successStatus = 200;


    protected function outputJSON($result = null, $message = '', $responseCode = 200) {     
        if ($message != '') $response["message"] = $message;
        if ($result != null) $response["data"] = $result;     
        return response()->json($response, $responseCode);
    }

    /**
     * Login user and create token
     *
     * @param  [string] email
     * @param  [string] password
     * @param  [boolean] remember_me
     * @return [string] access_token
     * @return [string] token_type
     * @return [string] expires_at
     */
    public function userlogin(Request $request)
    {
        try {            
        
			$lc =(!empty(request('lc')))?trim(request('lc')):'';
			if(empty($lc)){
				if($lc == 'fr'){					
					return $this->outputJSON(null , "Le code de langue est requis.", 401);				
				}else{								
					return $this->outputJSON(null , "Language code is required.", 401); 
				}
			}
			
            $validator = Validator::make($request->all(), [ 
                'client_secret' => 'required|string|exists:oauth_clients,secret',
                'email' => 'required|string|email',
                'password' => 'required|string',
                'device_id' => 'required|string',
                'device_type' => 'required|string',
				#'app_id' => 'required|in:1,2',	
            ]);

            if ($validator->fails()) {
                return $this->outputJSON(null , $validator->errors()->first(), 401);            
            }
			
			$email = request('email');
			$api_password = md5(request('password'));
			#$app_id = request('app_id');
			$user_data=array();
            $user_data = User::where('email', $email)->where('api_password', $api_password)->where('role_id', 1)->first();
			
			if(empty($user_data)) {
				if($lc == 'fr'){					
					return $this->outputJSON(null , "Votre mot de passe ou votre identifiant est incorrect. Merci de bien vouloir réessayer.", 401);				
				}else{								
					return $this->outputJSON(null , "Votre mot de passe ou votre identifiant est incorrect. Merci de bien vouloir réessayer.", 401); 
				}
				exit;
			}
			
			if($user_data->status!=1) {
				return $this->outputJSON(null , "Votre compte n'est pas actif. Veuillez contacter l'administrateur pour l'activer.", 401);				
				exit;
			}
			
			// login the user
			if($user_data->email){
				Auth::login($user_data, true);
			}else{
				Auth::loginUsingId($user_data->id);
			}
					
            /*$credentials = $request->only(['email', 'password']);        
            if(!Auth::attempt($credentials)){
                $message = trans('auth.failed');
                return $this->outputJSON(null , $message, 401);
            }*/

            $user = $request->user();
			
            //Old access token revoked 
            DB::table('oauth_access_tokens')->where('revoked', false)->where('user_id', $user->id)->where('device_id', request('device_id'))->update([
                'revoked' => true
            ]);

			$access_token = md5(uniqid(rand(), true)).$user->id.md5(uniqid(rand(), true));
			$refresh_token = md5(uniqid(rand(), true)).$user->id.md5(uniqid(rand(), true));
			$user_id = $user->id;
			$client_id = 2;
			if($lc == 'fr'){					
				$languagecode_id = 2;				
			}else{								
				$languagecode_id = 1;				 
			}
            //$languagecode_id = request('languagecode');
            $languagecode = $this->languageDetail($languagecode_id)->code;
            $device_id = request('device_id');
            $device_token = (!empty(request('device_token')))?trim(request('device_token')):'';
            $device_type = request('device_type');
			$latitude = (!empty(request('lat')))?trim(request('lat')):'0.0000000';
            $longitude = (!empty(request('lng')))?trim(request('lng')):'0.0000000';
			
			DB::table('oauth_access_tokens')->insert(
				[
					'user_id' => $user->id,
					'device_id' => request('device_id'),
					'device_type' => request('device_type'),
					'client_id' => '2',
					'id' => $access_token,
					'revoked' => 0,
					'created_at' => date("Y-m-d H:i:s"),
					'updated_at' => date("Y-m-d H:i:s"),
					'expires_at' => date("Y-m-d H:i:s"),
				]
			);	
			
			DB::table('oauth_refresh_tokens')->insert(
				[
					'id' => $refresh_token,
					'access_token_id' => $access_token,
					'revoked' => 0,					
					'expires_at' => date("Y-m-d H:i:s"),
				]
			);
			
			if(!empty($latitude) && !empty($longitude)){
				User::where('id', $user_id)->update([
						'longitude' => $longitude,
						'latitude' => $latitude
					]);
			}
					
            //Add & update user device detail
            $this->adddeviceDetail($device_type, $device_token, $latitude, $longitude, $user->id, $user->role_id, $device_id, $languagecode_id);

            $dob = '';
            
            if(!empty($user->dob)){
                $dob = Helper::dateformatDmy($user->dob); 
            }
            
            $image_path = public_path('uploads/users');
            $profile = '';            
            if(!empty($user->profile_pic) && File::exists($image_path.'/'.$user->profile_pic)){
                $profile = url('application/public/uploads/users/'.$user->profile_pic);
            }

            $response = [
                'message' => 'Connecté avec succès.',            
                'token_type' => 'Bearer',
                'expires_at' => 1620000,
                'access_token' => $this->bTwoCcrypt(json_encode(array("ag"=>$user_id,"b2c"=>$access_token,"cli"=>$client_id,"devid"=>$device_id)),'e'),
                'refresh_token' => $this->bTwoCcrypt(json_encode(array("ag"=>$user_id,"b2c"=>$refresh_token,"cli"=>$client_id)),'e'),
                'languagecode' => $languagecode,
                'data' => [
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
					'user_type' => $user->role_id,
                    'email' => $user->email,
                    'dob' => $dob,
                    'profile' => $profile,
                    'device_id' => $user->userdevice->device_id ?? '',
                    'device_token' => $user->userdevice->device_token ?? '',
                    'device_type' => $user->userdevice->device_type ?? '',
                ]
            ];
            return response()->json($response, 200);
			
        } catch (Exception $e) {            
            return $this->outputJSON(null, $e->getMessage(), 500);
        }
    }    
}
