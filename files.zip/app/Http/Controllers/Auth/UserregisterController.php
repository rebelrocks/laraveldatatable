<?php

namespace App\Http\Controllers\API\V1\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use App\Traits\UploadTrait;
use App\Traits\LanguagecodeTrait;
use App\User;
use App\Models\Usermeta;
use App\Models\Restaurantdetail;
use App\Models\Restaurantgallery;
use Exception;
use Helper;
use Aws\Ses\SesClient;
use Aws\Exception\AwsException;
use App\Models\Emailtemplate;
use App\Models\Sociallink;

class UserregisterController extends Controller
{

    use UploadTrait, LanguagecodeTrait;

    private $userprofiledir = "uploads/users";

    /** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function useregister(Request $request) 
    {
        try {    						
            //Get today date
            $todayDate = Carbon::parse(now())->format('d/m/Y');
			$lc =(!empty(request('lc')))?trim(request('lc')):'';
			if(empty($lc)){
				if($lc == 'fr'){					
					return $this->outputJSON(['message' => "Le code de langue est requis."], 401);				
				}else{								
					return $this->outputJSON(['message' => "Language code is required."], 401);
				}
			}
            // Validate the request...
			$social_type = request('social_type');
			//Facebook | Apple | Gmail
			$facebook_user_id = request('facebook_user_id');
			$gmail_user_id = request('gmail_user_id');
			$gmail_user_pic = request('gmail_user_pic');
			$apple_user_id = request('apple_user_id');
			$app_id = request('app_id');
			
			
			$validator = Validator::make($request->all(), [
				'client_secret' => 'required|string|exists:oauth_clients,secret', 
				'first_name' => 'required|string|max:191',
				'last_name' => 'required|string|max:191',
				'email' => 'required|string|email|max:191',
				'profile' => 'nullable|image|mimes:jpeg,jpg,png',
				'dob' => 'nullable|date_format:d/m/Y|before_or_equal:'.$todayDate,
				'password' => 'required|string|min:6|max:16',
				'confirmation_password' => 'required|same:password|string|min:6|max:16',
				'phone_no' => 'nullable|numeric',
				'user_type' => 'required|in:1,2,3',
				
			]);
			$password = request('password');
			        	
			
           	if($validator->fails()) {                 
                $response = [
                    'message' => $validator->errors()->first(),
                ];
                return $this->outputJSON($response, $this->notauthorized);               
            }else{
				$email=trim(request('email'));
				$user_type=trim(request('user_type'));
				if (User::where([['email','=',$email],['role_id','=', $user_type]])->exists()) {
				   return $this->outputJSON(['message' => "Cet email semble déjà utilisé. Merci d'en choisir un autre."], 401);
				}
			}

			$social_type = request('social_type');
			//Facebook | Apple | Gmail
			$facebook_user_id = request('facebook_user_id');
			$gmail_user_id = request('gmail_user_id');
			$gmail_user_pic = request('gmail_user_pic');
			$apple_user_id = request('apple_user_id');
		
            //Data request
            $user_type = request('user_type');
            $first_name = request('first_name');
            $last_name = request('last_name');
            $email = request('email');
            //$password = request('password');
            $dob = request('dob');
            $phone_no = request('phone_no');
            $profile = $request->file('profile');

            //$languagecode_id = request('languagecode');

            if(!empty($dob)){
                $dob = Carbon::createFromFormat('d/m/Y', $request->dob)->format('Y-m-d');
            }

            $get_profile_image = NULL;

            //Check user profile
            if($request->hasFile('profile')){
                $uplode_image_path = public_path('uploads/users');                                    
                $get_profile_image =  $this->uploadimageCompress($profile, $uplode_image_path);
            }

			//Set default role
			
            $role = 1; //Customer

            // if(!empty($user_type) && $user_type==2){
            //     $role = 2; //Restaurant owner
            // }elseif(!empty($user_type) && $user_type==3){
            //     $role = 3; //Provider
            // }

            $create = User::create([
            	'first_name' => $first_name,
                'last_name' => $last_name,
                'dob' => $dob,
                'email' => $email,
                'password' => Hash::make($password),
                'api_password' => md5($password),
                'profile_pic' => $get_profile_image,
                'mobile' => $phone_no,
				'facebook_user_id' => $facebook_user_id,
				'gmail_user_id' => $gmail_user_id,
				'gmail_user_pic' => $gmail_user_pic,
				'apple_user_id' => $apple_user_id,                
				'role_id' => $role,
				'notify_date' => date("Y-m-d H:i:s"),
                'status' => true,
            ]);

            //Check user registration success or not.
            if($create){
				
                //Update user detail
                $update = Usermeta::create([
                    'user_id' => $create->id,
                    'job_title' => request('profession'),
                    'about_me' => request('about_me'),
					'min_age' => 0,
                    'max_age' => 100,
					'search_radius' => 500,
					'interest_male' => 1,
					'interest_female' => 1,
                    'professionals_only' => 1,
                ]);

                
                $user_dob = '';
        
                if(!empty($create->dob)){
                    $user_dob = Helper::dateformatDmy($create->dob); 
                }
                
                $image_path = public_path('uploads/users');                
                $user_profile = '';
                
                if(!empty($create->profile_pic) && File::exists($image_path.'/'.$create->profile_pic)){
                    $user_profile = url('application/public/uploads/users/'.$create->profile_pic);
                }

				if($facebook_user_id!='' && $profile==""){
					$response['facebook_user_id'] = true;
				}
				elseif($gmail_user_id!='' && $gmail_user_pic!='' && $profile==""){
					$response['gmail_user_id'] = true;
				}
                
                $data = [
                    'first_name' => $create->first_name,
                    'last_name' => $create->last_name,
                    'email' => $create->email,
                    'phone_no' => $create->phone_no ?? '',
                    'dob' => $user_dob,
                    'profile' => $user_profile,
					'password' => $password,
                    'profession' => $create->usermeta->job_title ?? '',
                    'about_me' => $create->usermeta->about_me ?? '',
                ];
				
				//Site settings
				$settings = Helper::siteSettings();
										
				$emailtemplate  = Emailtemplate::where('id', 7)->first();
				$image_path = url('application/public/uploads/emailtemplates');
				$header_image = $image_path.'/'.$emailtemplate->header_image;
				$white_logo = $image_path.'/'.$emailtemplate->white_logo;
				
				//Site social_links
				$social_link_names_status=array();        
				$social_links = Sociallink::all(['name','value','status'])->toArray();        
				foreach($social_links as $thing){
					$social_link_names_status[$thing['name']] = $thing['status'];
					$social_link_names[] = $thing['name'];
					$social_link_values[] = $thing['value'];
				}        
				$social_links = array_combine($social_link_names, $social_link_values);
				$FB_LINK = (isset($social_link_names_status['EmailTemplate.fb_url']) && $social_link_names_status['EmailTemplate.fb_url']==true)? '<a href="'.$social_links['EmailTemplate.fb_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/fb.png').'" width="54" /></a>' :'';
				$TWITTER_LINK = (isset($social_link_names_status['EmailTemplate.twitter_url']) && $social_link_names_status['EmailTemplate.twitter_url']==true)? '<a href="'.$social_links['EmailTemplate.twitter_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/tw.png').'" width="54" /></a>' :'';
				$INSTA_LINK = (isset($social_link_names_status['EmailTemplate.insta_url']) && $social_link_names_status['EmailTemplate.insta_url']==true)? '<a href="'.$social_links['EmailTemplate.insta_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/it.png').'" width="54" /></a>' :'';
				$WEBSITE = (isset($social_link_names_status['EmailTemplate.web_url']) && $social_link_names_status['EmailTemplate.web_url']==true)? '<a href="'.$social_links['EmailTemplate.web_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/wd.png').'" width="54" /></a>' :'';
				$LINKEDIN_LINK = (isset($social_link_names_status['EmailTemplate.linked_in_url']) && $social_link_names_status['EmailTemplate.linked_in_url']==true)? '<a href="'.$social_links['EmailTemplate.linked_in_url'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/linkedin.png').'" width="54" /></a>' :'';
				
				//replace template var with value
				$token = array(
					'##SITE_LINK##' => url(config('app.url')),
					'##WHITE_LOGO##' => $white_logo,
					'##MAIN_COLOR##'  => '#'.$emailtemplate->main_color,
					'##HEADER_IMAGE##' => $header_image,
					'##FIRST_NAME##' => $create->first_name,
					'##SUPPORT_EMAIL##' => $emailtemplate->from_email,
					'##SITE_NAME##' => Helper::getapplicationName(),
					'##SECONDARY_COLOR##' => '#'.$emailtemplate->secondary_color,
					'##CONTACT_EMAIL##' => $emailtemplate->reply_to_email,
					'##YEAR##' => date('Y'),
					'##FB_LINK##' => $FB_LINK,
					'##TWITTER_LINK##' => $TWITTER_LINK,
					'##INSTA_LINK##' => $INSTA_LINK,
					'##WEBSITE##' => $WEBSITE,
					'##LINKEDIN_LINK##' => $LINKEDIN_LINK,
				);
				
				$pattern = '[%s]';
				foreach($token as $key=>$val)
				{
					$varMap[sprintf($key)] = $val;
				}
				
				$emailContent = strtr($emailtemplate['description'],$varMap);
				
				$ses_client = SesClient::factory(array(
						'version'=> 'latest',
						'region' => 'eu-west-2',
						'credentials' => array(
							'key' => 'AKIAVS3LDQGOHYIIDP6F',
							'secret'  => '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'
						) 
					));

				
				$subject =  strtr($emailtemplate->subject, $varMap);
				$sender_name = $emailtemplate->sender_name;
				$from_mail = $settings['site.sending_email_address'];
				$FromAddresses = "$sender_name <$from_mail>";
				try {
					$result = $ses_client->sendEmail([
					'Source'=>$FromAddresses,
					'Destination' => ['ToAddresses' => [$create->email,],],
					'Message' => ['Body' => ['Html' => ['Charset' => 'UTF-8','Data' => $emailContent,],
								'Text' => ['Charset' => 'UTF-8','Data' => "",],],
						'Subject' => ['Charset' => 'UTF-8','Data' => $subject,],],
					]);
					
				} catch (\Exception $e) {
					//echo $e->getMessage();exit;
				}
				
				if($lc == 'fr'){
					$response['message'] = "Votre compte a été créé avec succès.";
				}else{
					$response['message'] = "Your account has been successfully created.";
				}				
				
                $response['data'] = $data;                
                return $this->outputJSON($response);

    		}else{
                return $this->outputJSON(['message' => 'Unauthenticated'], $this->notauthorized);
            }
        } catch (Exception $e) {          
            return $this->outputJSON(['message' => $e->getMessage()], 500);
        }

    }	
	
	public function checkmail(Request $request) 
    {
        try {            
        
            // Validate the request...
			
			$lc =(!empty(request('lc')))?trim(request('lc')):'';
			if(empty($lc)){
				if($lc == 'fr'){					
					return $this->outputJSON(['message' => "Le code de langue est requis."], 401);				
				}else{								
					return $this->outputJSON(['message' => "Language code is required."], 401);
				}
			}
		
        	$validator = Validator::make($request->all(), [
                'client_secret' => 'required|string|exists:oauth_clients,secret',
				'user_type' => 'required|in:1,2,3',				
            ]);

           	if($validator->fails()) {                 
                $response = [
                    'message' => $validator->errors()->first(),
                ];
                return $this->outputJSON($response, $this->notauthorized);               
            }else{
				$email=trim(request('email'));
				$user_type=trim(request('user_type'));
				if (User::where([['email','=',$email],['role','=', $user_type]])->exists()) {
				   return $this->outputJSON(['message' => "Cet email semble déjà utilisé. Merci d'en choisir un autre."], 401);
				}
			}
			
			return $this->outputJSON(['message' => "Email not used."]);
			
        } catch (Exception $e) {          
            return $this->outputJSON(['message' => $e->getMessage()], 500);
        }

    }
	
}
