<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use DB;
use App\User;

class ResetPasswordController extends Controller
{

    /**
     * Display the password reset view for the given token.
     *
     * If no token is present, display the link request form.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string|null  $token
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function showResetForm(Request $request, $token = null)
    {
        return view('auth.passwords.reset')->with(
            ['token' => $token, 'email' => $request->email]
        );
    }


    /**
     * Reset the given user's password.
     *
     * @param  \Illuminate\Contracts\Auth\CanResetPassword  $user
     * @param  string  $password
     * @return void
     */
    protected function reset(Request $request)
    {
	
        $request->validate([
            'token' => 'required',
            'email' => 'required|email|exists:users,email',
            'password' => 'required|confirmed|min:8',
        ],[
            'email.exists' => trans('passwords.user'),
            'email.required' => trans('messages.please_enter_your_email_address'),
        ]);


        // Validate the token
        $tokenData = DB::table('password_resets')->where('token', $request->token)->first();

        // Redirect the user back to the password reset request form if the token is invalid
        if (!$tokenData){

            return back()->with('email', trans('passwords.token'));

        }

        $user = User::where('email', $tokenData->email)->first();
        // Redirect the user back if the email is invalid
        if (!$user){

            return back()->with('email', trans('passwords.user'));
        }

        $password = request('password');

        //Hash and update the new password
        $user->password = Hash::make($password);
        $user->api_password = Hash::make($password);
        $user->setRememberToken(Str::random(60));
        $user->update(); //or $user->save();

        //login the user immediately they change password successfully
        //Auth::login($user);

        $this->guard()->login($user);

        //Delete the token
        DB::table('password_resets')->where('email', $user->email)->delete();

        if (auth()->user()->role == false)
        {
            return redirect(route('admin_dashboard'));
        }
        
        return redirect(route('home'));
    }


    /**
     * Get the guard to be used during password reset.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return Auth::guard();
    }
}
