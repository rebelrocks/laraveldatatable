<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Exports\DataExport;
use App\Imports\DataImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Traits\GeneralsettingTrait;
use App\Traits\checkermissionsTrait;
use Illuminate\Support\Facades\Auth;

class ExcelController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	use checkermissionsTrait,GeneralsettingTrait;
    private $userprofiledir = "uploads/users";

    public function __construct()
    {
        
    }

     /**
    * @return \Illuminate\Support\Collection
    */
    public function importExportView()
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'import', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
		
       return view('import');
    }
   
    /**
    * @return \Illuminate\Support\Collection
    */
    public function export() 
    {
        if(!$this->checkPermission(Auth::user()->role_id, 'export', 'is_read'))
        {
            return redirect(route('admin_dashboard'))->with('warning', trans('messages.You are not authorised to access that location'));
            exit;
        }
        $this->SaveUserActivity('voters export activity performed '); 
        return Excel::download(new DataExport, 'users.xlsx');

    }
   
    /**
    * @return \Illuminate\Support\Collection
    */
    public function import() 
    {
        Excel::import(new DataImport,request()->file('file'));
        $this->SaveUserActivity('voters import activity performed ');  
        return redirect(route('importExportView'))->with('success', 'Data imported successfully!');
    }
}
