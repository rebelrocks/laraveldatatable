<?php

namespace App;

use Laravel\Passport\HasApiTokens;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Notifications\ResetPassword;
use Illuminate\Support\Facades\Hash;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;



    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded  = [];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];



    /**
     * Get the user deatil record associated with the user.
     */
    public function usermeta()
    {
        return $this->hasOne('App\Models\Usermeta')->withDefault();
    }

    /**
     * Get the user deatil record associated with the user.
     */
    public function userquestion()
    {
        return $this->hasOne('App\Models\Userquestion')->withDefault();
    }

    
    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
       $this->notify(new ResetPassword($token));
    }


    /**
     * Get the user images record associated with the user.
     */
    public function userimages()
    {
        return $this->hasMany('App\Models\UserImage', 'user_id');
    }
	
	public function UserComment()
    {
        return $this->hasMany('App\Models\Comment', 'commented_to');
    }
	
	public function UserVote()
    {
        return $this->hasMany('App\Models\UserVote', 'voter_id');
    }
	
	public function myTotalVote(){
		return $this->hasMany(Models\UserVote::class, 'user_id');
	}

                                                               
    /**
     * Scope a query to only include set default order.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOrdered($query)
    {
        return $query->orderBy('id', 'desc')->get();
    }

    /**
     * Scope a query to only include set by give value & order.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOrderebycoloumn($query, $cl_name, $ortype)
    {
        return $query->orderBy($cl_name, $ortype)->get();
    }


    /**
     * Get the user deatil record associated with the user.
     */
    public function userrole()
    {
        return $this->belongsTo('App\Models\Role', 'role_id')->withDefault();
    }
	
	public function userFriend()
    {
        return $this->hasOne('App\Models\Friend', 'user_id');
    }


    /**
     * Get the user device detail
     */
    // public function userdevice()
    // {
        // return $this->hasOne('App\Models\Userdevice', 'user_id');
    // }
	
	public function UserSetting()
    {
        return $this->hasOne('App\Models\UserSetting', 'user_id');
    }
	
	public function AppNotificationSetting()
    {
        return $this->hasOne('App\Models\AppNotificationSetting', 'user_id');
    }
	
	public function UserDevice()
    {
        return $this->hasMany('App\Models\Userdevice', 'user_id');
    }


    /**
     * Get the restaurant details record associated with the user.
     */
   
	
	/**
     * Find the user instance for the given username.
     *
     * @param  string  $username
     * @return \App\User
     */
    /*public function findForPassport($username)
    {
        return $this->where('first_name', $username)->first();
    }*/
	
	
	/**
     * Validate the password of the user for the Passport password grant.
     *
     * @param  string  $password
     * @return bool
     */
    /*public function validateForPassportPasswordGrant($password)
    {
        return Hash::check($password, $this->password);
    }*/


}
