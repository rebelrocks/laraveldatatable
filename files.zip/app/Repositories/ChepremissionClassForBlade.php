<?php

namespace App\Repositories;
use App\Traits\checkermissionsTrait;

class ChepremissionClassForBlade
{
    use checkermissionsTrait;
}