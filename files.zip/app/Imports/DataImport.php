<?php
namespace App\Imports;

use App\Models\EquifaxTestData;
use App\Models\UserData;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class DataImport implements ToCollection, WithHeadingRow
{
    /**
     * @param Collection $collection
     */
    public function collection(Collection $collection)
    {

        
        foreach ($collection as $key => $row) {
            $idcard= $row['idcardno'] ?? '';
            $counter = UserData::where('voter_id_number',$idcard)->count();
            if($counter < 1){
                $user =  DB::table('users')->insertGetId([
                    'first_name'                 => $row['name'] ?? '',
                    'father_or_husband_name'     => $row['relname'] ?? '', 
                    'email'                      => '', 
                    'gender'                     => $row['gender'] ?? '',
                    'dob'                        => '',
                    'age'                        => $row['age'] ?? '',
                    'rel_type'                   => $row['rtype'] ?? '',
                    'status_type'                => $row['statustype'] ?? '',
                    'mobile'                     => $row['contactno'] ?? '',
                    'address'                    => '',
                    'house_number'               => $row['houseno'] ?? '',
                    'lane'                       => '',
                    'city'                       => '',
                    'state'                      => '',
                    'block'                      => $row['engsection'] ?? '', 
                    'pincode'                    => $row['pincode'] ?? '', 
                    'booth_name'                 => $row['boothname'] ?? '', 
                    'sub_area'                   => $row['section_no'] ?? '', 
                    'assembly_constituency'      => '', 
                    'voter_id_number'            => $row['idcardno'] ?? '',
                    'parliamentary_constituency' => '',
                    'part_number'                => $row['part_no'] ?? '',
                    'part_name'                  => '',
                    'serial_number'              => $row['serial_no'] ?? '',
                    'polling_station'            => '',
                    'facebook_url'               => '',
                    'twitter_url'                => '', 
                    'remarks'                    => '', 
                    'role_id'                    => 1, 
                    'role'                       => 1,
                    'is_approved'                   => 1,
                ]);
               
                DB::table('users_data')->insertGetId([
                    'first_name'                 => $row['name'] ?? '',
                    'father_or_husband_name'     => $row['relname'] ?? '', 
                    'email'                      => '', 
                    'gender'                     => $row['gender'] ?? '',
                    'dob'                        => '',
                    'age'                        => $row['age'] ?? '',
                    'rel_type'                   => $row['rtype'] ?? '',
                    'status_type'                => $row['statustype'] ?? '',
                    'mobile'                     => $row['contactno'] ?? '',
                    'address'                    => '',
                    'house_number'               => $row['houseno'] ?? '',
                    'lane'                       => '',
                    'city'                       => '',
                    'state'                      => '',
                    'block'                      => $row['engsection'] ?? '', 
                    'pincode'                    => $row['pincode'] ?? '', 
                    'booth_name'                 => $row['boothname'] ?? '', 
                    'sub_area'                   => $row['section_no'] ?? '', 
                    'assembly_constituency'      => '', 
                    'voter_id_number'            => $row['idcardno'] ?? '',
                    'parliamentary_constituency' => '',
                    'part_number'                => $row['part_no'] ?? '',
                    'part_name'                  => '',
                    'serial_number'              => $row['serial_no'] ?? '',
                    'polling_station'            => '',
                    'facebook_url'               => '',
                    'twitter_url'                => '', 
                    'remarks'                    => '', 
                    'user_id'                    => $user, 
                ]);
    
                # create insert log 
                $this->UserActivity('Voter Create activity performed on  user id :  '.$user,$user); 
            }
            
        }

    }
    public function UserActivity($activity,$user_data_id){
		$status = DB::table('user_data_activities')->insert([
			'role_id'=>Auth::user()->role_id,
			'activities'=>$activity,
			'user_id'=>Auth::user()->id,
			'user_data_id'=>$user_data_id,
			'created_at'=>date('Y-m-d H:i:s'),
			'updated_at'=>date('Y-m-d H:i:s'),
		]);
	}
	
}
