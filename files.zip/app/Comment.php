<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\CommentLike;

class Comment extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'comments';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
     protected $guarded  = [];

     public function commentlikes()
    {
        return $this->hasMany('App\Models\CommentLike', 'comment_id')->orderBy('created_at', 'DESC');
    }
	
	public function getAllReplies(){
		return $this->hasMany('App\Models\Comment', 'parent_comment_id');
	}
	
	public function commentedUserData(){
		return $this->belongsTo('App\User','commented_by','id')->select('id', 'first_name','last_name','country_prefix','country');
		
	}
	
	public function userImage(){
		return $this->hasMany('App\Models\UserImage','user_id','commented_by');
		
	}
}
