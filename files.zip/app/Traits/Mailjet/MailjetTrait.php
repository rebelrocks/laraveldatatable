<?php

namespace App\Traits\Mailjet;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use App\Models\Sociallink;
use App\Models\Emailtemplate;
use \Mailjet\Resources;

trait MailjetTrait
{
    /**
     * Send email's
     * 
     * @param 
     * @return \Illuminate\Http\Response
     */
    public function mailjetEmail($senderemail, $appname, $subject , $emailcontent, $email)
    {

        $mj = new \Mailjet\Client(getenv('MJ_APIKEY_PUBLIC'), getenv('MJ_APIKEY_PRIVATE'));

        $body = [
                    'FromEmail' => $senderemail,
                    'FromName' => $appname,
                    'Subject' => $subject,
                    'Text-part' => "",
                    'Html-part' => $emailcontent,
                    'Recipients' => [
                        [
                            'Email' => $email
                        ]
                    ]
                ];

        $response = $mj->post(Resources::$Email, ['body' => $body]);

        return $response;
               
    }
}