<?php

namespace App\Traits\Helper;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use App\Models\Sociallink;
use App\Models\Languagecode;
use App\Models\Role;

trait HelperTrait
{
    /**
     * Get the language code detail by ID.
     * 
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function languagecode($id)
    {
        return Languagecode::where('id', $id)->first(['name', 'code']); 
    }


    /**
     * Get the all role list.
     * 
     * @return \Illuminate\Http\Response
     */
    public function roles()
    {
        return Role::all(['id', 'name', 'slug']); 
    }


    protected function weekarrayen()
    {
        return [
            'monday' => 1,
            'tuesday' => 2,
            'wednesday' => 3,
            'thursday' => 4,
            'friday' => 5,
            'saturday' => 6,
            'sunday' => 7
        ];
    }

    protected function weekarrayfr()
    {
        return [
                1 => 'Lundi',
                2 => 'Mardi',
                3 => 'Mercredi',
                4 => 'Jeudi', 
                5 => 'Vendredi', 
                6 => 'Samedi',
                7 => 'Dimanche'
            ];

        exit(); 
        
        return [
                1 => 'Lundi',
                2 => 'Mardi',
                3 => 'Mercredi',
                4 => 'Jeudi', 
                5 => 'Vendredi', 
                6 => 'Samedi',
                7 => 'Dimanche'
            ];   
        return [
            1 => 'Monday',
            2 => 'Tuesday',
            3 => 'Wednesday',
            4 => 'Thursday', 
            5 => 'Friday', 
            6 => 'Saturday',
            7 => 'Sunday'
        ];
    }
}