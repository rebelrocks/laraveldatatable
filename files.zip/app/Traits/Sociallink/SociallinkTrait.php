<?php

namespace App\Traits\Sociallink;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use App\Models\Sociallink;

trait SociallinkTrait
{
    /**
     * Get facebook page url
     * @return \Illuminate\Http\Response
     */
    public function fbpage()
    {

        $fb_page_url = '';

        $fb = Sociallink::where('name', 'EmailTemplate.fb_url')->first(['name', 'value', 'status'])->toArray();

        if(isset($fb['name']) &&  $fb['status']==true){

            $fb_page_url = '<a href="'.$fb['value'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/fb.png').'" width="54" /></a>';
        }

        return $fb_page_url;        
    }


    /**
     * Get twitter page url
     * @return \Illuminate\Http\Response
     */
    public function twitterpage()
    {

        $page_url = '';

        $page = Sociallink::where('name', 'EmailTemplate.twitter_url')->first(['name', 'value', 'status'])->toArray();

        if(isset($page['name']) &&  $page['status']==true){

            $page_url = '<a href="'.$page['value'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/tw.png').'" width="54" /></a>';
        }

        return $page_url;        
    }

    /**
     * Get instagram page url
     * @return \Illuminate\Http\Response
     */
    public function instagrampage()
    {

        $page_url = '';

        $page = Sociallink::where('name', 'EmailTemplate.insta_url')->first(['name', 'value', 'status'])->toArray();

        if(isset($page['name']) &&  $page['status']==true){

            $page_url = '<a href="'.$page['value'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/it.png').'" width="54" /></a>';
        }

        return $page_url;        
    }


    /**
     * Get website page url
     * @return \Illuminate\Http\Response
     */
    public function websitepageurl()
    {

        $page_url = '';

        $page = Sociallink::where('name', 'EmailTemplate.web_url')->first(['name', 'value', 'status'])->toArray();

        if(isset($page['name']) &&  $page['status']==true){

            $page_url = '<a href="'.$page['value'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/wd.png').'" width="54" /></a>';
        }

        return $page_url;        
    }

    /**
     * Get linkedin page url
     * @return \Illuminate\Http\Response
     */
    public function linkedinpageurl()
    {

        $page_url = '';

        $page = Sociallink::where('name', 'EmailTemplate.linked_in_url')->first(['name', 'value', 'status'])->toArray();

        if(isset($page['name']) &&  $page['status']==true){

            $page_url = '<a href="'.$page['value'].'" target="_blank"><img alt="" height="54" src="'.url('content/socialicons/linkedin.png').'" width="54" /></a>';
        }

        return $page_url;        
    }


    /**
     * Get site socail links detail
     *
     * @return \Illuminate\Http\Response
     */
    public function sitesocialLinks()
    {
        $names = [];

        $values = [];
        
        $social_links = Sociallink::whereStatus(true)->get(['name','value','status'])->toArray();
        //$social_links = Sociallink::all(['name','value','status'])->toArray();
        
        foreach($social_links as $thing)
        {
            $names[] = $thing['name'];
            $values[] = $thing['value'];
        }
        
        return array_combine($names, $values);
    }
}