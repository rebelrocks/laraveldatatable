<?php

namespace App\Traits\Faqcategory;

use Illuminate\Support\Str;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\URL;
use App\Models\Languagecode;
use App\Models\Faqcategory;

trait FaqcategoryTrait
{
    /**
     * Get the category detail by default language.
     * 
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function categorybyLanguage($id, $languagecode_id)
    {
		return	Faqcategory::where('id', $id)->whereLanguagecode_id($languagecode_id)->first();
    }
	
	
	/**
	 * Set the default category id list
	 * 
	 * @return \Illuminate\Http\Response
	 */
	 public function defaultcatID()
	 {
		return [1, 2, 3, 4, 5, 6];	 
	 } 


	/**
     * Get all categories list.
     *
     * @param  int  $languagecode_id
     * @return \Illuminate\Http\Response
     */
 	public function categories($languagecode_id)
 	{
 		//Get the child category List
        return Faqcategory::whereLanguagecode_id($languagecode_id)
                        //->orderBy('category_order', 'asc')
                        ->get();
 	}

    /**
     * Get all categories list.
     *
     * @param  int  $languagecode_id
     * @return \Illuminate\Http\Response
     */
    public function maincategories($languagecode_id)
    {
        //Get the child category List
        return Faqcategory::whereLanguagecode_id($languagecode_id)
                        ->where('category_id', false)
                        ->get();
    }
}