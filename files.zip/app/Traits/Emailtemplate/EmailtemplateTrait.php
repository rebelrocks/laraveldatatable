<?php

namespace App\Traits\Emailtemplate;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use App\Models\Emailtemplate;

trait EmailtemplateTrait
{
    public function getemplateDetail($id)
    {
        return Emailtemplate::find($id);
    }


    /**
     *	Default email template content
     *
     */
    public function defaulthtmlContent()
    {
    	$html = '<html>
					<head>
						<title></title>
						<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
						<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,600" rel="stylesheet" type="text/css" />
					</head>
					<body leftmargin="0" marginheight="0" marginwidth="0" style="background-color:##MAIN_COLOR##" topmargin="0">
					</body>
				</html>';

		return $html;

		exit();
		//old email default content
		$html = '<html>
					<head>
						<title></title>
						<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
						<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,600" rel="stylesheet" type="text/css" />
					</head>
					<body leftmargin="0" marginheight="0" marginwidth="0" style="background-color:##MAIN_COLOR##" topmargin="0">
					</body>
				</html>';

		return $html;
    }
}