<?php

namespace App\Traits;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use App\Models\Userdevice;

trait LoginTrait
{

    /**
     * Update user device detail.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    protected function adddeviceDetail($device_type, $device_token,$latitude, $longitude, $user_id, $role_id, $device_id,$languagecode_id)
    {
        $userdevice = Userdevice::where('device_type', $device_type)
                                    ->where('device_id', $device_id)
                                    ->orderBy('id', 'desc')
                                    ->first();

        if($userdevice){

            return Userdevice::where('id', $userdevice->id)->update([
                    'device_id' => $device_id,
					'user_id' => $user_id,
					'role_id' => $role_id,
                    'device_token' => $device_token,
                    'device_type' => $device_type,
					'languagecode_id' => $languagecode_id,
					'lat' => $latitude,
                    'lng' => $longitude,
                ]);

        }else{

            //Add user device detail
            return Userdevice::create([
                'user_id' => $user_id,
				'role_id' => $role_id,
                'device_id' => $device_id,
                'device_token' => $device_token,
                'device_type' => $device_type,
				'languagecode_id' => $languagecode_id,
				'lat' => $latitude,
                'lng' => $longitude,
            ]);
        }
    }

    /**
     * Generate access token.
     *
     * @return \Illuminate\Http\Response
     */

    protected function accessToken($email, $password)
    {
        //Access token
        try {                       
        
            //Generate new access token
            $http = new \GuzzleHttp\Client(); 
            
            $oauthurl = url('/oauth/token');
            
            $response = $http->post($oauthurl, [
                'form_params' => [
                    'grant_type' => 'password',
                    'client_id' => '2',
                    'client_secret' => 'F0Z66dgLVRI2NueF4U3bzClI3nv6ZDxycxFEO75q',
                    'username' => $email,
                    'password' => $password,
                    'scope' => '',
                ],
            ]);

            return json_decode((string) $response->getBody(), true);

        } catch (ClientException $e) {            

            // If there are network errors, we need to ensure the application doesn't crash.
            // if $e->hasResponse is not null we can attempt to get the message
            // Otherwise, we'll just pass a network unavailable message.

            if ($e->hasResponse()) {

                $exception = (string) $e->getResponse()->getBody();

                $exception = json_decode($exception);
                // Coverting object to an array
                $jsonArray = (array)$exception;

                $response = [
                    'message' => $jsonArray['message'],
                ];

                return response()->json($response, 401);

            } else {

                $response = [
                    'message' => $e->getMessage(),
                ];

                return response()->json($response, 401);

            }
            
        } catch (RequestException $e) {

            // If there are network errors, we need to ensure the application doesn't crash.
            // if $e->hasResponse is not null we can attempt to get the message
            // Otherwise, we'll just pass a network unavailable message.

            if ($e->hasResponse()) {

                $exception = (string) $e->getResponse()->getBody();

                $exception = json_decode($exception);
                // Coverting object to an array
                $jsonArray = (array)$exception;

                $response = [
                    'message' => $jsonArray['message'],
                ];

                return response()->json($response, 401);

            } else {

                $response = [
                    'message' => $e->getMessage(),
                ];

                return response()->json($response, 401);

            }

        } catch (Exception $e) {
            
            $response = [
                'message' => $e->getMessage(),
            ];

            return response()->json($response, 401);

        }
    }  
}