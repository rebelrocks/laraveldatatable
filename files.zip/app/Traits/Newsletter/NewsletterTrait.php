<?php

namespace App\Traits\Newsletter;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;
use App\Models\Sociallink;
use App\Models\Emailtemplate;

trait NewsletterTrait
{
    /**
     * Newsletter email template.
     * 
     * @param 
     * @return \Illuminate\Http\Response
     */
    public function newsletteremailtemplate($first_name, $support_email_id, $appname, $contact_email_id, $fbpage, $twitterpage, $instagrampage, $websitepageurl, $linkedinpageurl, $message)
    {

        $emailtemplate = Emailtemplate::where('title', 'Newsletter')->first();

        if(empty($emailtemplate))
        {
            return '';
            exit();
        }    
            $image_path = url('application/public/uploads/emailtemplates');

            $header_image = $image_path.'/'.$emailtemplate->header_image;

            //replace template var with value
            $token = array(
                '##MAIN_COLOR##'  => '#'.$emailtemplate->main_color,
                '##HEADER_IMAGE##' => $header_image,
                '##FIRST_NAME##' => $first_name,
                '##SUPPORT_EMAIL##' => $support_email_id,
                '##SITE_NAME##' => $appname,
                '##SECONDARY_COLOR##' => '#'.$emailtemplate->secondary_color,
                '##CONTACT_EMAIL##' => $contact_email_id,
                '##YEAR##' => date('Y'),
                '##FB_LINK##' => $fbpage,
                '##TWITTER_LINK##' => $twitterpage,
                '##INSTA_LINK##' => $instagrampage,
                '##WEBSITE##' => $websitepageurl,
                '##LINKEDIN_LINK##' => $linkedinpageurl,
                '##MESSAGE##' => $message,
            );

            foreach($token as $key=>$val)
            {
                $varMap[sprintf($key)] = $val;
            }
            
            $emailContent = strtr($emailtemplate['description'],$varMap);

            return $emailContent;
               
    }
}