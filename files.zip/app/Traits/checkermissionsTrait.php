<?php

namespace App\Traits;

use Illuminate\Support\Facades\DB;
use App\Models\Site_permission;
use App\Models\Role;
use Illuminate\Support\Facades\Auth;

trait checkermissionsTrait
{
    /**
     * Check site permissions
     * @return true or false
     */
    public function checkPermission($role_id, $manager, $permission)
    {
        $role = Role::where('id', $role_id)->where('id' , '!=', 4)->count();
        if($role > 0){
          $permission_count = DB::table('managers')
            ->join('site_permissions', 'site_permissions.manager_id', '=', 'managers.id')
            ->where('site_permissions.role_id', $role_id)
            ->where('managers.name', $manager)
            ->where('site_permissions.'.$permission, 1)
            ->count();
          if($permission_count > 0){                                  
          
              return true;

          }else{

              return false;
          }
          
        }

        return true;
    }

}