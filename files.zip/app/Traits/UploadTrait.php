<?php

namespace App\Traits;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Image;
use App\Models\Userimage;

trait UploadTrait
{
    /**
     * Upload image
     * @param 
     * @return \Illuminate\Http\Response
     */
    public function uploadOne($file, $image_path)
    {

        $salt_image  = time().rand(1111, 9999);

        $image_name = $salt_image.'.'.$file->getClientOriginalExtension();

        $file->move($image_path, $image_name);

        return $image_name;        
    }


    /**
     * Upload image with compress
     * @param 
     * @return \Illuminate\Http\Response
     */
    public function uploadimageCompress($file, $image_path)
    {

        $salt_image  = time().rand(1111, 9999);

        $image_name = $salt_image.'.'.$file->getClientOriginalExtension();

        // open an image file
        $get_image_size = getimagesize($file->getRealPath());
        $width = $get_image_size[0];
        $height = $get_image_size[1];
        $thumb_image = Image::make($file->getRealPath())->resize($width, $height, function($constraint){
            $constraint->aspectRatio();
        });

        // now you are able to resize the instance
        //$thumb_image->save($image_path.'/'.$image_name, 80);
        $thumb_image->save($image_path.'/'.$image_name, 80);
		
		@copy($image_path.'/'.$image_name, $image_path . '/thumb/' . $image_name);
        $this->resizeImg($image_path . '/thumb/' . $image_name, $image_path . '/thumb/' . $image_name, 100, '', 100);
								
        return $image_name;
    }

    
	public function resizeImg($original, $new_filename, $new_width = 0, $new_height = 0, $quality = 100) {
	
		if(!($image_params = @getimagesize($original))) {
			$this->__errors[] = 'Original file is not a valid image: ' . $orignal;
			return false;
		}

		$width = $image_params[0];
		$height = $image_params[1];

		if(0 != $new_width && 0 == $new_height) {
			$scaled_width = $new_width;
			$scaled_height = floor($new_width * $height / $width);
		} elseif(0 != $new_height && 0 == $new_width) {
			$scaled_height = $new_height;
			$scaled_width = floor($new_height * $width / $height);
		} elseif(0 == $new_width && 0 == $new_height) { //assume we want to create a new image the same exact size
			$scaled_width = $width;
			$scaled_height = $height;
		} else { //assume we want to create an image with these exact dimensions, most likely resulting in distortion
			$scaled_width = $new_width;
			$scaled_height = $new_height;
		}

		//create image
		$ext = $image_params[2];
		switch($ext) {
			case IMAGETYPE_GIF:
				$return = $this->__resizeGif($original, $new_filename, $scaled_width, $scaled_height, $width, $height, $quality);
				break;
			case IMAGETYPE_JPEG:
				$return = $this->__resizeJpeg($original, $new_filename, $scaled_width, $scaled_height, $width, $height, $quality);
				break;
			case IMAGETYPE_PNG:
				$return = $this->__resizePng($original, $new_filename, $scaled_width, $scaled_height, $width, $height, $quality);
				break;
			default:
				$return = $this->__resizeJpeg($original, $new_filename, $scaled_width, $scaled_height, $width, $height, $quality);
				break;
		}

		return $return;
	}
	
	private function __resizeGif($original, $new_filename, $scaled_width, $scaled_height, $width, $height) {
		$error = false;

		if(!($src = imagecreatefromgif($original))) {
			$this->__errors[] = 'There was an error creating your resized image (gif).';
			$error = true;
		}

		if(!($tmp = imagecreatetruecolor($scaled_width, $scaled_height))) {
			$this->__errors[] = 'There was an error creating your true color image (gif).';
			$error = true;
		}

		if(!imagecopyresampled($tmp, $src, 0, 0, 0, 0, $scaled_width, $scaled_height, $width, $height)) {
			$this->__errors[] = 'There was an error creating your true color image (gif).';
			$error = true;
		}

		if(!($new_image = imagegif($tmp, $new_filename))) {
			$this->__errors[] = 'There was an error writing your image to file (gif).';
			$error = true;
		}

		imagedestroy($tmp);

		if(false == $error) {
			return $new_image;
		}

		return false;
	}

	private function __resizeJpeg($original, $new_filename, $scaled_width, $scaled_height, $width, $height, $quality) {
		$error = false;

		if(!($src = imagecreatefromjpeg($original))) {
			$this->__errors[] = 'There was an error creating your resized image (jpg).';
			$error = true;
		}

		if(!($tmp = imagecreatetruecolor($scaled_width, $scaled_height))) {
			$this->__errors[] = 'There was an error creating your true color image (jpg).';
			$error = true;
		}

		if(!imagecopyresampled($tmp, $src, 0, 0, 0, 0, $scaled_width, $scaled_height, $width, $height)) {
			$this->__errors[] = 'There was an error creating your true color image (jpg).';
			$error = true;
		}

		if(!($new_image = imagejpeg($tmp, $new_filename, $quality))) {
			$this->__errors[] = 'There was an error writing your image to file (jpg).';
			$error = true;
		}

		imagedestroy($tmp);

		if(false == $error) {
			return $new_image;
		}

		return false;
	}

	private function __resizePng($original, $new_filename, $scaled_width, $scaled_height, $width, $height, $quality) {
		$error = false;
		/**
		 * we need to recalculate the quality for imagepng()
		 * the quality parameter in imagepng() is actually the compression level,
		 * so the higher the value (0-9), the lower the quality. this is pretty much
		 * the opposite of how imagejpeg() works.
		 */
		$quality = ceil($quality / 10); // 0 - 100 value
		if(0 == $quality) {
			$quality = 9;
		} else {
			$quality = ($quality - 1) % 9;
		}


		if(!($src = imagecreatefrompng($original))) {
			$this->__errors[] = 'There was an error creating your resized image (png).';
			$error = true;
		}

		if(!($tmp = imagecreatetruecolor($scaled_width, $scaled_height))) {
			$this->__errors[] = 'There was an error creating your true color image (png).';
			$error = true;
		}

		imagealphablending($tmp, false);

		if(!imagecopyresampled($tmp, $src, 0, 0, 0, 0, $scaled_width, $scaled_height, $width, $height)) {
			$this->__errors[] = 'There was an error creating your true color image (png).';
			$error = true;
		}

		imagesavealpha($tmp, true);

		if(!($new_image = imagepng($tmp, $new_filename, $quality))) {
			$this->__errors[] = 'There was an error writing your image to file (png).';
			$error = true;
		}

		imagedestroy($tmp);

		if(false == $error) {
			return $new_image;
		}

		return false;
	}
	
	/**
     * Upload multiple images
     * @param 
     * @return \Illuminate\Http\Response
     */
    public function uploadTwo($file, $image_path)
    {

        if($request->hasFile('user_images')){
            foreach ($request->file('user_images') as $fileKey => $fileObject ){

                // make sure each file is valid
                if ($fileObject->isValid()) {

                    $photo  = $user_images[$fileKey];

                    $uplode_image_path = public_path(self::userprofiledirpath());
                    
                    $get_profile_image =  $this->uploadOne($photo, $uplode_image_path);

                    //add user image
                    Userimage::create([
                        'user_id' => $id,
                        'image' => $get_profile_image,
                        'status' => 1,
                    ]);
                }
            }
        }         
    }


    /**
     * get user image detail
     * @param \$user_id, $image_id
     * @return \Illuminate\Http\Response 
     */
    public function getuserimagedetail($user_id, $image_id)
    {
        return Userimage::where('user_id', $user_id)->where('image_id', $image_id)->first();
    }



}