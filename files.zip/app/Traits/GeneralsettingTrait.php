<?php

namespace App\Traits;

use App\Models\Setting;

trait GeneralsettingTrait
{
    /**
     * Get support email ID
     * @return \Illuminate\Http\Response
     */
    public function getsupportEmail()
    {

        return Setting::where('name', 'site.support_email')->first(['name', 'value']);
              
    }

    /**
     * Get contact email ID
     * @return \Illuminate\Http\Response
     */
    public function getcontactEmail()
    {

        return Setting::where('name', 'site.contact_email_address')->first(['name', 'value']);
              
    }


    /**
     * Get sender email ID
     * @return \Illuminate\Http\Response
     */
    public function getsenderEmail()
    {

        return Setting::where('name', 'site.sending_email_address')->first(['name', 'value']);
              
    }


    /**
     * Get report email ID
     * @return \Illuminate\Http\Response
     */
    public function getreportEmail()
    {

        return Setting::where('name', 'site.reportemail')->first(['name', 'value']);
              
    }

    /**
     * Get site setting detail
     *
     * @return \Illuminate\Http\Response
     */
    public function siteSettings()
    {
        $names = [];
        $values = [];
        
        $settings = Setting::all(['name','value'])->toArray();
        
        foreach($settings as $thing)
        {
            $names[] = $thing['name'];
            $values[] = $thing['value'];
        }
        
        return array_combine($names, $values);
    }
	
	public function pushAndroid($registration_id = null, $data = null)
    {  
        
        $url = 'https://fcm.googleapis.com/fcm/send';
        
        if(is_array($registration_id)){
            
            $fields = array(
                'registration_ids' => $registration_id,
                'data' => $data,
                'time_to_live' => 9000,
                'delay_while_idle' => true,
                'priority' => 'high',
                'ttl' => 3600,
                'timestamp' => 3600,
                'sound' => 'default'
            );

        }else{

            $fields = array(
                'to' => $registration_id,
                'data' => $data,
                'ttl' => 3600,
                'timestamp' => 3600,
                'sound' => 'default'
            );
        }

        $headers = array(
                        'Authorization: key= AAAA8XLc_Rs:APA91bGVTR_3uWnboA91vC3YH9rf_pSHEhlo1AuSRjUyQP87SpybmoEf9mdMov0hECM012Mn41sVxSw4EW9uaX4dG5MbP50epI-zdtVrL6bRUS2-SNlPP7jTF5q06ckZtsHsHYSLAxVy',
                        'Content-Type: application/json'
                    );

        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);

        if ($result === FALSE) {
            $error = '0';
            return ($error);
            die('Curl failed: ' . curl_error($ch));
            //curl_get_info();
        }
        // Close connection
        curl_close($ch);
    }
	
	public function pushIOS($registration_id = null, $data = null,$media = NULL,$badge = NULL){
		$passphrase = '123456';
		$pemFile = public_path('/RankOnline.pem');
		$ctx = stream_context_create();
		stream_context_set_option($ctx, 'ssl', 'local_cert',  $pemFile);
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
		/*production mode*/
		// echo $registration_id;die;
		// Open a connection to the APNS server
        $sitesetting = $this->siteSettings();

        if ($sitesetting['site.pem_file_select_mode'] == 1) 
        {
            $fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
        }
        else
        {
            $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
        }
				
		$data['sound'] = 'default';
        if($badge > 0)
        {
            $data['badge'] = $badge;
        }
		$data['mutable-content'] = true;
		$data['category'] = 'NotificationSetting';
		//$data['media-url'] = $media;
		$body['aps'] = $data;
		$body['media-url'] = $media;

		$payload = json_encode($body);
		$msg = chr(0) . pack('n', 32) . pack('H*', $registration_id) . pack('n', strlen($payload)) . $payload;
		
		$result = fwrite($fp, $msg, strlen($msg));
		if (!$result)
        {	
			//echo 'Message not delivered' . PHP_EOL;
			//print_r($result);die;
		}
		// echo $registration_id;die;
		fclose($fp);
		/*production mode*/		
	}
	
	public function pushProIOS($registration_id = null, $data = null,$media = NULL,$badge = NULL){
		$passphrase = '12345';
		$pemFile = public_path('/APNSEatManager_Live.pem');
		$ctx = stream_context_create();
		stream_context_set_option($ctx, 'ssl', 'local_cert',  $pemFile);
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
		
		/*production mode*/
		// echo $registration_id;die;
		// Open a connection to the APNS server
        $sitesetting = $this->siteSettings();

        if ($sitesetting['site.pem_file_select_mode'] == 1) 
        {
            $fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
        }
        else
        {
            $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
        }
		
		//if (!$fp)
		//exit("Failed to connect: $err $errstr" . PHP_EOL);
		
		$data['sound'] = 'default';
		$data['badge'] = $badge;
        // $data['media-url'] = $media;
		//$data['content-availabel'] = true;
		$data['category'] = 'NotificationSetting';
		$body['aps'] = $data;
        $body['media-url'] = $media;
		$payload = json_encode($body);
        // echo '<pre>'; print_r($payload);die;
		$msg = chr(0) . pack('n', 32) . pack('H*', $registration_id) . pack('n', strlen($payload)) . $payload;
		
		// Send it to the server
		$result = fwrite($fp, $msg, strlen($msg));
		
		if (!$result){	
			//echo 'Message not delivered' . PHP_EOL;
			//print_r($result);die;
		}
		// echo $registration_id;die;
		fclose($fp);
		/*production mode*/		
	}
    
}