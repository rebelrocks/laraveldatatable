<?php
  
namespace App\Exports;
  
use App\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
  
class DataExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return User::select('first_name','last_name','email','mobile','dob','gender','address','city','lane','house_number','state','sub_area','block','booth_name','assembly_constituency','voter_id_number','parliamentary_constituency','part_number','part_name','serial_number','polling_station','facebook_url','twitter_url','remarks')
        ->where('role_id',1)
        ->where('is_approved',1)
        ->get();
    }
    public function headings() :array
    {
        return ['first_name','last_name','email','mobile','dob','gender','address','city','lane','house_number','state','sub_area','block','booth_name','assembly_constituency','voter_id_number','parliamentary_constituency','part_number','part_name','serial_number','polling_station','facebook_url','twitter_url','remarks'];
    }
}
