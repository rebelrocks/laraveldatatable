<?php

namespace App\Console\Commands;

use App\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use \Mailjet\Resources;
use App\Models\user_news_notification;
use App\Models\Newsnotification;
use App\Models\Newsletterhistory;

class SendnewsletterDaily extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'newsletter:daily';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send a daily email to all users with a newsletter';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
         
        $users = user_news_notification::all();
        
        $mj = new \Mailjet\Client(getenv('MJ_APIKEY_PUBLIC'), getenv('MJ_APIKEY_PRIVATE'));
        
        foreach ($users as $user) {

            $useremail = User::find($user->user_id);

            if(!empty($useremail->email)){

                $emailcontent = Newsnotification::where('id', $user->newsnotification_id)->first();

                $body = [
                    'FromEmail' => 'noreply@55.agency',
                    'FromName' => "B2Cvertical",
                    'Subject' => $emailcontent->title,
                    'Text-part' => "",
                    'Html-part' => $emailcontent->description,
                    'Recipients' => [
                        [
                            'Email' => $useremail->email
                        ]
                    ]
                ];

                $response = $mj->post(Resources::$Email, ['body' => $body]);

            }
        }
         
        $this->info('Word of the Day sent to All Users');
    }
}
