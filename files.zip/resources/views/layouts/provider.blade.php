<!DOCTYPE html>
<html lang="en">
<head>    
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=1240">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
	<meta http-equiv="Cache-Control" content="public, no-cache, no-store, must-revalidate" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="0" />
	
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>
        {{Helper::getapplicationName()}} - @yield('title')
    </title>
	
    <link rel="apple-touch-icon" sizes="57x57" href="{{ asset('content/img/apple-icon-57x57.png') }}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{ asset('content/img/apple-icon-60x60.png') }}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{ asset('content/img/apple-icon-72x72.png') }}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('content/img/apple-icon-76x76.png') }}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{ asset('content/img/apple-icon-114x114.png') }}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{ asset('content/img/apple-icon-120x120.png') }}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{ asset('content/img/apple-icon-144x144.png') }}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{ asset('content/img/apple-icon-152x152.png') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('content/img/apple-icon-180x180.png') }}">
    <link rel="icon" type="image/png" sizes="192x192"  href="{{ asset('content/img/android-icon-192x192.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('content/img/favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="96x96" href="{{ asset('content/img/favicon-96x96.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('content/img/favicon-16x16.png') }}">
    <link rel="manifest" href="{{ asset('content/img/manifest.json') }}">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{ asset('content/img/ms-icon-144x144.png') }}">
    <meta name="theme-color" content="#ffffff">

	<!-- Bootstrap -->
	<link href="{{ asset('content/assets/css/front/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
	<link href="{{ asset('content/assets/css/front/style.css') }}" rel="stylesheet" type="text/css">
	<link href="{{ asset('content/assets/css/front/font-awesome.css') }}" rel="stylesheet" type="text/css">
	<link href="{{ asset('content/assets/css/front/city-autocomplete.css') }}" rel="stylesheet" type="text/css">
	
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="{{ asset('content/assets/js/front/jquery.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('content/assets/js/front/bootstrap.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('content/assets/js/front/jquery.easing.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('content/assets/js/datepicker/js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
	<script src="{{ asset('content/assets/js/datepicker/js/bootstrap-datepicker.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('content/assets/js/front/jquery.nicescroll.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('content/assets/js/front/jquery.city-autocomplete.js') }}" type="text/javascript"></script>
	
</head>
<body>
	<div class="eatandmatch-bx-site">
	    <!-- Content --> 
           @yield('content')
        <!-- End Content --> 
		
		<!-- Sidebar-->
			@include('includes.providernav')
		<!--  End Sidebar -->

	</div>	
	

	<script src="{{ asset('content/assets/js/front/index.js') }}"></script>
	<script>
	 $(document).ready(function () {
		 $("#submitDiv").click(function () {
			$(".login-staps").addClass("about-section-hide");
		 });
		 $(".popup-close").click(function () {
			$(".get-stared-popup").removeClass("get-popup-active");
		 });
		 $(".modal-backdrop").click(function () {
			$(".get-stared-popup").removeClass("get-popup-active");
		 });
	 });
	</script>
	<script>
	 jQuery(function () {
		 jQuery('#showall').click(function () {
			jQuery('.targetDiv').show();
		 });
		 jQuery('.showSingle').click(function () {
			jQuery("body").addClass("intro"); 
			jQuery('.targetDiv').hide();
			jQuery('#div' + $(this).attr('target')).show();
		 });		 
	 });
	</script>

	<script>
	 $(document).ready(function () {
		 $("#quantity").keypress(function (e) {
			 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				 $("#errmsg").html("Numbers Only").show().fadeOut("slow");
				 return false;
			 }
		 });		 
	 });
	</script>

</body>
</html>