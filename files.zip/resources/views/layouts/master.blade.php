@if((Route::currentRouteName() == 'password.request' || Route::currentRouteName() == 'password.reset') && !auth::check())

@elseif(auth::check() && auth()->user()->role == false)
<script>
    window.location = "{{url('admin')}}/dashboard";
</script>
@else
<script>
    window.location = "{{url('admin')}}/login";
</script>
@endif

<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{Helper::getapplicationName()}}</title>

    <link rel="apple-touch-icon" sizes="57x57" href="{{ asset('content/img/apple-icon-57x57.png') }}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{ asset('content/img/apple-icon-60x60.png') }}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{ asset('content/img/apple-icon-72x72.png') }}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('content/img/apple-icon-76x76.png') }}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{ asset('content/img/apple-icon-114x114.png') }}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{ asset('content/img/apple-icon-120x120.png') }}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{ asset('content/img/apple-icon-144x144.png') }}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{ asset('content/img/apple-icon-152x152.png') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('content/img/apple-icon-180x180.png') }}">
    <link rel="icon" type="image/png" sizes="192x192"  href="{{ asset('content/img/android-icon-192x192.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('content/img/favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="96x96" href="{{ asset('content/img/favicon-96x96.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('content/img/favicon-16x16.png') }}">
    <link rel="manifest" href="{{ asset('content/img/manifest.json') }}">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{ asset('content/img/ms-icon-144x144.png') }}">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- Material Dashboard CSS -->
    @stack('css')
    <link href="{{asset('content/assets/login/css/material-dashboard.min.css')}}" rel="stylesheet"/>
    <script type="text/javascript" src="{{asset('content/assets/login/js/jquery-3.1.0.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('content/assets/login/js/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('content/assets/login/js/material.min.js')}}"></script>

</head>
<body class="off-canvas-sidebar">
    <div class="wrapper wrapper-full-page">
        @php
            $sitesetting = Helper::siteSettings();
            $loginbackground = $sitesetting['site.login_background'] ?? '';
            $logo = $sitesetting['site.logo'] ?? '';
        @endphp
        <div class="page-header login-page header-filter" filter-color="black" style="background-image: url({{asset('application/public/uploads/settings/'.$loginbackground)}}); background-size: cover; background-position: top center;">
            <!-- Begin Page Content -->
            
            @yield('content')
            
            <footer class="footer">
                <div class="container">
                    <div class="copyright">
                        <small>{{date('Y')}} &copy; {{ Helper::getapplicationName() }}</small>
                    </div>
                </div>
            </footer>
        </div>        
    </div>
</body>
</html>
