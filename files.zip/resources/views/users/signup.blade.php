@extends('layouts.provider')
@section('title', 'Provider')
@section('content')
            
<div id="carousel-example-generic" class="carousel slide">
	<div class="carousel-inner" role="listbox">
	   <div class="item active">
		@php
            $sitesetting = Helper::siteSettings();
            $loginbackground = $sitesetting['site.login_background'] ?? '';
            $logo = $sitesetting['site.logo'] ?? '';
        @endphp
		 <!--div class="eatandmatch-banner"></div-->
		  <div class="movi-bx">
			 <div class="container-login">
				<div class="login-bg targetDiv" id="div21" style="display:inline-block">                           
				   <a href="/" class="navbar-brand" alt="Todmarket"><img src="/img/front/logo.png" title="" alt=""></a>				   
				   <h2>Bienvenue sur Eat & Match</h2>
				   <div class="login-btn"> 
					<a href="javascript:void(0);" class="btn btn-primary eatandmatch-primary" data-toggle="modal" data-target="#loginModal" alt="Se connecter">Se connecter</a>					  <a href="javascript:void(0);" class="btn btn-primary eatandmatch-primary" data-toggle="modal" data-target="#myRegister" alt="S’inscrire">S’inscrire</a>				   </div>
				</div>
				<div class="login-bg login-jio-bg targetDiv" id="div11">
				   <a href="javascript:void(0);" class="shop-brand" alt="Todmarket"><img src="/img/front/betclic-logo.png" title="" alt=""></a>				   <p class="joa-txt">Pariez sur BetClic et bénéficiez <br>
					  d’un crédit exceptionnel de 50€*.
				   </p>
				   <div class="login-btn">
					<a href="javascript:void(0);" class="btn btn-default eatandmatch-btn-default eatandmatch-bookmaker" data-eatandmatch-bookmaker="1" data-eatandmatch-bookmaker-status="1" alt="S’inscrire">S’inscrire</a>						   
                    <a href="javascript:void(0);" class="btn btn-default eatandmatch-btn-default eatandmatch-bookmaker" data-eatandmatch-bookmaker="1" data-eatandmatch-bookmaker-status="0" alt="Se connecter">Accéder</a>				   </div>
				</div>
				<div class="login-bg login-jio-bg targetDiv" id="div27">
				   <a href="javascript:void(0);" class="shop-brand" alt="Todmarket"><img src="/img/front/parions.png" title="" alt=""></a>				   <p class="joa-txt">Pariez sur Parions-fr et bénéficiez <br>
					  d’un crédit exceptionnel de 50€*.
				   </p>
				   <div class="login-btn"> 
					<a href="javascript:void(0);" class="btn btn-default eatandmatch-btn-default eatandmatch-bookmaker" data-eatandmatch-bookmaker="2" data-eatandmatch-bookmaker-status="1" alt="S’inscrire">S’inscrire</a>						   
                    <a href="javascript:void(0);" class="btn btn-default eatandmatch-btn-default eatandmatch-bookmaker" data-eatandmatch-bookmaker="2" data-eatandmatch-bookmaker-status="0" alt="Se connecter">Accéder</a>				   </div>
				</div>			
			 </div>
		  </div>
		  
		</div>
	</div>	
</div>

<!-- Sidebar-->
	@include('includes.loginregistermodal')
<!--  End Sidebar -->
		
@endsection
