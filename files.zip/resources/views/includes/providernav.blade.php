<!-- Login Modal -->
<div class="myaccout-bx">
	<button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		<div class="user-profile"> 	   
			<img src="{{asset('application/public/img/front/no-user.png')}}" alt="no-image" id="user-image">	   
		</div>
	</button>
	<div class="dropdown-menu myaccount-menu" aria-labelledby="dLabel">
		<ul>
			<li><a href="javascript:void(0);" class="" data-toggle="modal" data-target="#loginModal" alt="Mon profil">Mon profil</a>		  </li>
			<li><a href="javascript:void(0);" class="" data-toggle="modal" data-target="#loginModal" alt="Mes bookmakers">Mes bookmakers</a></li>
			<li><a href="javascript:void(0);" class="" data-toggle="modal" data-target="#loginModal" alt="FAQ">FAQ</a></li>
			<li><a href="javascript:void(0);" class="" data-toggle="modal" data-target="#loginModal" alt="Réglages">Réglages</a></li>
			<li><a href="javascript:void(0);" class="" data-toggle="modal" data-target="#loginModal" alt="Se connecter">Se connecter</a></li>
		</ul>
	</div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="logout-modal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header" style="text-align: left;">        
        <h4 class="modal-title" id="myModalLabel">Avertissement !</h4>
      </div>
	  <div class="modal-body" style="text-align: left;">
		<div id="ezAlerts-message">Êtes-vous certain de vouloir vous déconnecter ?</div>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" id="modal-logout-si" style="background-color: #ff0000;color: #ffffff;border-color: #ff0000;">Se déconnecter</button>
        <button type="button" class="btn btn-primary" id="modal-logout-no">Annuler</button>
      </div>
    </div>
  </div>
</div>