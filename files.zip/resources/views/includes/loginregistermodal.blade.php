<!-- Login Modal -->

	<div class="modal fade eatandmatch_modal" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel">
		<div class="modal-dialog" role="document">
			<div class="msform">
		
			<div class="remomgo eatandmatchpp" style="display: none;" id="loader_login">
				<img src="{{asset('application/public/img/front/fancybox_loading.gif')}}" title="" alt="">			
			</div>
				
			 <fieldset id="loginfieldset">            
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<img src="{{asset('application/public/img/front/close-img.png')}}" title="" alt="">			
				</button>

				<form method="post" accept-charset="utf-8" id="frontLogin" action="{{ route('frontlogin') }}">
					<div class="alert alert-danger" role="alert" id="loginerror" style="display: none;"></div>
					<div class="alert alert-success" role="alert" id="loginsuccess" style="display: none;"></div>
					
					<p style="line-height: 18px;color: #5D5D5D;font-size: 16px;">Connectez-vous à votre compte Eat & Match<br>pour acceder a cette foctionnnalite !</p>
					
					<div class="form-group">
						<label>Email</label>
						<div class="login-input">
							<div class="input email required">
							<input type="email" name="email" class="form-control" placeholder="Email" required="required" id="email"></div>				
						</div>
					</div>
					<div class="form-group">
						<label>Mot de passe</label>
						<div class="login-input">
						<div class="input password required"><input type="password" name="password" required="required" class="form-control" placeholder="Mot de passe" id="password"></div>				</div>
					</div>
					
					<a href="javascript:void(0);" class="next forg-btn" data-next="#forgotfieldset" data-current="#loginfieldset">Mot de passe oublié ?</a>
					<input type="submit" class="submit-button" value="CONNEXION">
					
				</form>

				<p class="navigation-register">
					Nouveau? <a href="javascript:void(0);" class="nav-register">Inscrivez-vous gratuitement</a>
				</p>
				
			  </fieldset>
			  
			  <fieldset id="forgotfieldset">
				
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<img src="{{asset('application/public/img/front/close-img.png')}}" title="" alt="">			
				</button>
				
				<form method="post" accept-charset="utf-8" id="forgotPassword" action="/users/forgotpassword">
				
					<h2 class="fs-title2">Mot de passe oublié?</h2>
					<div class="alert alert-danger" role="alert" id="forgoterror" style="display: none;">
					</div>
					<p>Entrez votre email<br>
					  pour réinitialiser votre mot de passe</p>
					<div class="form-group">
					  <div class="login-input">
						<div class="input email required"><input type="email" name="email" class="form-control" placeholder="Email" required="required" id="email"></div>				  </div>
					</div>
					<input type="submit" class="submit-button" value="Connexion">
					<br>
					<a href="javascript:void(0);" name="previous" class="previous logins-btn" data-next="#loginfieldset" data-current="#forgotfieldset">RETOUR À LA CONNEXION</a>           
					
					</form> 
			  
			  </fieldset>
			  
			</div>
      </div>
    </div>

	<div class="modal fade register-modal" id="myRegister" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog rig-bx" role="document">
        <div class="msform">
			<div class="remomgo eatandmatchpp" style="display: none;" id="loader_register">
				<img src="/img/front/fancybox_loading.gif" title="" alt="">			
			</div>
          <form method="post" accept-charset="utf-8" id="register" action="/users/register"><div style="display:none;"><input type="hidden" name="_method" value="POST"><input type="hidden" name="_csrfToken" value="28ebe077f876f4385b4d897b53371845e90b0c18bf1a925b70e0a656aba60f9007314a92ccfb9e260d64794ba42a86b894c2527e91302fe1c27ffbb31f74950e"></div>		  <input type="hidden" name="facebook_user_id" value="">		  <fieldset id="inscriptionfieldset">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<img src="{{asset('application/public/img/front/close-img.png')}}" title="" alt="">			</button>
            <h2 class="fs-title">Inscription sur Eat & Match</h2>
            <p>Donnez nous quelques details sur vous.</p>
            
            <div class="row">
              <div class="col-xs-12 col-sm-6 col-md-6">
                <div class="form-group">
                  <label>Prénom</label>
                  <div class="login-input">
					<div class="input text required"><input type="text" name="first_name" autocomplete="off" class="form-control" placeholder="Votre prénom" required="required" id="first-name" value=""></div>                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-6">
                <div class="form-group">
                  <label>Nom</label>
                  <div class="login-input">
					<div class="input text required"><input type="text" name="last_name" autocomplete="off" class="form-control" placeholder="Votre nom" required="required" id="last-name" value=""></div>                  </div>
                </div>
              </div>
            </div>
			
			<div class="row">              
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
					<label>Email</label>
					<div class="login-input">
						<div class="input email required"><input type="email" name="email" autocomplete="off" id="useremail" class="form-control" placeholder="Votre email" required="required" value=""></div>                  
					</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
				<div class="form-group">
				<label>Téléphone (facultatif)</label>
				<div class="login-input">
				<div class="input tel"><input type="tel" name="mobile" autocomplete="off" class="form-control" placeholder="Votre téléphone" id="mobile"></div>																				
				</div>
				</div>
				</div>
            </div>
			
            <div class="row">
              <div class="col-xs-12 col-sm-6 col-md-6">
                <div class="form-group">
                  <label>Choisissez votre mot de passe</label>
                  <div class="login-input">
					<div class="input password required"><input type="password" name="password" class="form-control" placeholder="Choisissez votre mot de passe" required="required" id="password" value=""></div>                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-6">
                <div class="form-group">
                  <label>Confirmez votre mot de passe</label>
                  <div class="login-input">
                    <div class="input password required"><input type="password" name="confirm_password" class="form-control" placeholder="Confirmez votre mot de passe" required="required" id="confirm-password" value=""></div>                  </div>
                </div>
              </div>
            </div>			
			
			<div class="input button">
				<button type="button" class="nextregister action-button" id="etape-suivante">SUIVANT</button>
			</div>          
		</fieldset>
		  
          <fieldset id="bookmakerfieldset">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<img src="{{asset('application/public/img/front/close-img.png')}}" title="" alt="">			</button>
            <h2 class="fs-title">Choisissez vos bookmakers</h2>
            <p>Choisissez les bookmakers que vous utilisez<br>
              au quotidien. Ils vous seront proposés en<br>
              priorité pour faire vos paris.</p>			 
            <div class="sign-don sign-donforem" style="overflow: hidden; outline: currentcolor none medium;" tabindex="1">
             						<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/2e266_logo-parions-sport-2.png" title="Parions Sport" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">Parions Sport</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="2">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/dd26e_bwin.png" title="bwin" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">bwin</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="6">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/2017e_Netbet.png" title="NetBet" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">NetBet</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="3">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/9a12d_feelingbet.png" title="Feeling bet" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">Feeling bet</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="15">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/2d9aa_9b5b31012a18184c_800x800ar.png" title="Unibet" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">Unibet</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="5">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/06670_France_pari.png" title="France-pari" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">France-pari</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="7">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/dfd2f_zebet.png" title="ZEbet" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">ZEbet</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="11">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/f500e_genybet.png" title="GENYbet" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">GENYbet</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="14">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/8ed77_Betstars.png" title="BetStars" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">BetStars</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="8">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/f6077_betclic.png" title="Betclic" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">Betclic</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="1">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/a6676_winamax.png" title="Winamax" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">Winamax</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="4">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/bfcab_logo-pmu-sport.png" title="PMU" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">PMU</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="12">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/6d42a_JOA.png" title="JOA" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">JOA</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="9">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/7bfa6_vbet.png" title="Vbet" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">Vbet</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="13">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
												<div class="form-group">
							<span>
								<img src="https://app.eatandmatchmarket.com/images/bookmarks/712bf_1552304670-Pasinobet-logo.png" title="Pasinobet" style="width: 75px;" alt="">							</span>
							<div class="login-input-register">
							<label class="labeltitle">Pasinobet</label>
							<div class="switchonoff-btn">
								<label class="switch">
									<input type="checkbox" class="default" name="bookmakers[]" value="10">
									<span class="slider round"></span>
								</label>
							</div>					
							</div>
						</div>
							 
			 
            </div>
            <input type="submit" class="action-button" value="Inscription">
            <p class="wel-paragrap">En appuyant sur Terminer mon inscription, j’accepte les<br>
              <a href="/termsofservice" target="_blank" class="" alt="Conditions d’utilisation">Conditions d’utilisation</a>, la <a href="/confidential" target="_blank" class="" alt="Politique d’utilisation des données">Politique d’utilisation des données</a><br> et les <a href="/termsofservice" target="_blank" class="" alt="Conditions de service">Conditions de service</a> de Eat & Match.</p>
          </fieldset>
		  
          <div style="display:none;"><input type="hidden" name="_Token[fields]" value="f1fdd1e664edfd31f1fe5f1918e23cc87cbc9cd3%3Afacebook_user_id"><input type="hidden" name="_Token[unlocked]" value=""></div></form>		</div>
      </div>
    <div id="ascrail2000" class="nicescroll-rails nicescroll-rails-vr" style="width: 8px; z-index: 1050; cursor: default; position: absolute; top: 0px; left: -8px; height: 0px; display: none;"><div style="position: relative; top: 0px; float: right; width: 6px; height: 0px; background-color: rgb(66, 66, 66); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;" class="nicescroll-cursors"></div></div><div id="ascrail2000-hr" class="nicescroll-rails nicescroll-rails-hr" style="height: 8px; z-index: 1050; top: -8px; left: 0px; position: absolute; cursor: default; display: none;"><div style="position: absolute; top: 0px; height: 6px; width: 0px; background-color: rgb(66, 66, 66); border: 1px solid rgb(255, 255, 255); background-clip: padding-box; border-radius: 5px;" class="nicescroll-cursors">
	</div>
	</div>
	</div>
	
<style>
.sign-donforem {
	max-height: 250px;	
	overflow: auto;
}
.pac-container {
    z-index: 10000 !important;
}
.datepicker {
      z-index: 1600 !important; /* has to be larger than 1050 */
    }
</style>

<script type="text/javascript">
$(document).ready(function(){
	$('#datepicker').datepicker({
		minDate: new Date(),
		dateFormat: 'dd/mm/yy',
		eatandmatchayHighlight: true,
		autoclose: true,	   
	});
	
	$("#frontLogin").submit(function(){
		var serdata = $(this).serialize();
		$.ajax({
			type : 'POST',
			url : "{{route('ajax_get_providers')}}",
			data : serdata,
			dataType : 'json',
			beforeSend: function(){
				$('#loader_login').show();
			},
			complete: function(){
				$('#loader_login').hide();
			},
			error : function(e){
				alert("Une erreur c'est produite, veuillez réessayer.");
			},
			success : function(data){
				if (data.code == 401) {
					$("#loginerror").html(data.message);
					$("#loginerror").show();
					setTimeout(function(){ $("#loginerror").hide(); },3000);
				}
				else if (data.code == 200) {
					$("#loginsuccess").html(data.message);
					$("#loginsuccess").show();
					setTimeout(function(){ $("#loginsuccess").hide(); },3000);
					window.location = "";
				}				
			}
		});
		return false;
	});
	
	$("#forgotPassword").submit(function(){
		var serdata = $(this).serialize();
		$.ajax({
			type : 'POST',
			url : "{{route('ajax_get_providers')}}",
			data : serdata,
			dataType : 'json',
			beforeSend: function(){
				$('#loader_login').show();
			},
			complete: function(){
				$('#loader_login').hide();
			},
			error : function(e){
				alert("Une erreur c'est produite, veuillez réessayer.");
			},
			success : function(data){
				if (data.code == 401) {
					$("#forgoterror").removeClass("successmail");
					$("#forgoterror").html(data.message);
					$("#forgoterror").show();
					setTimeout(function(){ $("#forgoterror").hide(); },3000);
				}	
				else if (data.code == 200) {
					$("#forgoterror").addClass("successmail");
					$("#forgoterror").html(data.message);
					$("#forgoterror").show();
					setTimeout(function(){ $("#forgoterror").hide(); },3000);
				}
			}
		});
		return false;
	});
		
	$(".nav-register").click(function(){
		$("#loginModal").modal('toggle');
		$('#myRegister').modal('toggle');		
	});
	
	$(".nextregister").click(function(){
		if(animating) return false;
							animating = true;
							current_fs = $("#inscriptionfieldset");
							next_fs = $("#bookmakerfieldset");
							$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
							next_fs.show(); 
							current_fs.animate({opacity: 0}, {
								step: function(now, mx) {
									scale = 1 - (1 - now) * 0.2;
									left = (now * 50)+"%";
									opacity = 1 - now;
									current_fs.css({
									'transform': 'scale('+scale+')',
									'position': 'absolute'
									});
									next_fs.css({'left': left, 'opacity': opacity});
								}, 
								duration: 800, 
								complete: function(){
									current_fs.hide();
									$(".sign-donforem").getNiceScroll().resize();
									animating = false;
								}, 
								easing: 'easeInOutBack'
							});	
		return true;					
		var password = $('#register #password').val();
        var cpass = $('#register #confirm-password').val();
		
		if($('#username').val()==''){	
		    $('#username').addClass('err_border');
			alert("Merci d'indiquer votre pseudo !");
			$('#username').focus();			
			return false;			
		}else {			
            $('#username').removeClass('err_border');
        }
		
		if($('#useremail').val()==''){	
		    $('#useremail').addClass('err_border');
			alert("Merci d'indiquer votre email !");
			$('#useremail').focus();				
			return false;			
		}else if (!isEmail($('#useremail').val())) {
            $('#useremail').addClass('err_border');
			alert("Merci d'indiquer un email valide !");
			$('#useremail').focus();
			return false;
        }else {			 
            $('#useremail').removeClass('err_border');			
        }
		
		if($('#first-name').val()==''){		
		    $('#first-name').addClass('err_border');
			alert("Merci d'indiquer votre prénom !");
			$('#first-name').focus();			
			return false;			
		}else {
            $('#first-name').removeClass('err_border');
        }
		
		if($('#last-name').val()==''){	
		    $('#last-name').addClass('err_border');
			alert("Merci d'indiquer votre nom !");
			$('#last-name').focus();
			return false;			
		}else {
            $('#last-name').removeClass('err_border');
        }
						
		var mobNum = $('#mobile').val();
		var filter = /^\d*(?:\.\d{1,2})?$/;

		if($('#mobile').val()==''){
			$('#mobile').addClass('err_border');						
			alert("Merci d'indiquer votre téléphone !");
			$('#mobile').focus();		
			return false;			
		}else if (filter.test(mobNum)) {
			if(mobNum.length==10){
				$('#mobile').removeClass('err_border');
			} else {
				$('#mobile').addClass('err_border');						
				alert("Merci d'indiquer un téléphone valide !");
				$('#mobile').focus();	
				return false;				
			}
		}else {
			$('#mobile').addClass('err_border');						
			alert("Merci d'indiquer un téléphone valide !");
			$('#mobile').focus();	
			return false;
		}
		
		if (password == '') {
            $('#register #password').addClass('err_border');						
			alert("Merci d'indiquer un mot de passe !");
			$('#register #password').focus();	
			return false;
        }
        else {
            $('#register #password').removeClass('err_border');
        }

        if (cpass == '') {
            $('#register #confirm-password').addClass('err_border');						
			alert("Merci de bien vouloir confirmer votre mot de passe.");
			$('#register #confirm-password').focus();	
			return false;
        }
        else if (password != '' && cpass != '' && password != cpass) {
            $('#register #confirm-password').addClass('err_border');						
			alert("Les mots de passe ne sont pas identiques !");
			$('#register #confirm-password').focus();	
			return false;
        }
        else {
            $('#register #confirm-password').removeClass('err_border');
        }
		
		if($('#useremail').val()!=''){
			$.ajax({
				type : 'POST',
				url : "{{route('ajax_get_providers')}}",
				data :{useremail:$('#useremail').val()},
				dataType : 'json',
				error : function(e){
					alert("Une erreur c'est produite, veuillez réessayer..");
				},
				success : function(data){
					if (data.code == 401) {
						$('#useremail').addClass('err_border');
						alert("Merci d'indiquer votre email !");
						$('#useremail').focus();
						return false;
					}	
					else if (data.code == 200) {
						$('#useremail').removeClass('err_border');
						if(animating) return false;
							animating = true;
							current_fs = $("#inscriptionfieldset");
							next_fs = $("#bookmakerfieldset");
							$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
							next_fs.show(); 
							current_fs.animate({opacity: 0}, {
								step: function(now, mx) {
									scale = 1 - (1 - now) * 0.2;
									left = (now * 50)+"%";
									opacity = 1 - now;
									current_fs.css({
									'transform': 'scale('+scale+')',
									'position': 'absolute'
									});
									next_fs.css({'left': left, 'opacity': opacity});
								}, 
								duration: 800, 
								complete: function(){
									current_fs.hide();
									$(".sign-donforem").getNiceScroll().resize();
									animating = false;
								}, 
								easing: 'easeInOutBack'
							});						
					}
				}
			});
			//return true;
		}
					
	});
	
	$("#register").submit(function(){
		var serdata = $(this).serialize();
		$.ajax({
			type : 'POST',
			url : "{{route('ajax_get_providers')}}",
			data : serdata,
			dataType : 'json',
			beforeSend: function(){
				$('#loader_register').show();
			},
			complete: function(){
				$('#loader_register').hide();
			},
			error : function(e){
				alert("Une erreur c'est produite, veuillez réessayer.");
			},
			success : function(data){
				if (data.code == 401) {
					$("#forgoterror").removeClass("successmail");
					$("#forgoterror").html(data.message);
					$("#forgoterror").show();
					setTimeout(function(){ $("#forgoterror").hide(); },3000);
				}	
				else if (data.code == 200) {
					window.location = "";
				}
			}
		});
		return false;
	});
	
	//$(".sign-donforem").niceScroll();
});

function isEmail(email) {
	var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	return regex.test(email);
}
</script>
