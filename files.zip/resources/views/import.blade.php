@extends('admin.layouts.app')
@section('title', trans('messages.cms_page_listing'))
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><i class="material-icons iconset">view_list</i> @lang('Import Excel file')</h4>
                            </div>
                            <div class="card-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="container">
                                        <div class="card bg-light mt-3">
                                            <div class="card-header">
                                              
                                            </div>
                                            <div class="card-body">
                                                <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data">
                                                    @csrf
                                                    <input  style="padding: 3px;" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" type="file" name="file" class="form-control" required>
                                                    <br>
                                                    <button class="btn btn-success">Import User Data</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
