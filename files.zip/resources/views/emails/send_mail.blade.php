<?php
echo $templates;
?>