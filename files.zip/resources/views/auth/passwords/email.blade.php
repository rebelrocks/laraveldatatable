@extends('layouts.master')
@push('css')
    <style type="text/css">
        .invalid-feedback{
            margin: 0px 0px 0px 53px;
            font-size: 13px;
        }
		#SubmitBtn{
    
    background: #ffffff;
    color: #000000;
    border: 0 none;
    border-radius: 7px;
    cursor: pointer;
    font-weight: 500;
    padding: 10px 50px;
    margin: 20px 0 0;
    font-size: 12px;
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    height: 50px;
    box-shadow: 0 0 10px lightgrey;
   
}
    #LoginCards{
		padding-top:25px;
		padding-bottom:25px;
	}
    </style>
@endpush
@section('content')
<div class="container">
    <div class="col-lg-4 col-md-6 col-sm-6 ml-auto mr-auto">
        <form method="POST" action="{{ route('password.email') }}">
            @csrf
            @if (session('status'))
                <div class="alert alert-success" role="alert">
                    {{ session('status') }}
                </div>
            @endif
            @php
                $sitesetting = Helper::siteSettings();
                $loginbackground = $sitesetting['site.login_background'] ?? '';
                $logo = $sitesetting['site.logo'] ?? '';
            @endphp
            <div class="card card-login" id="LoginCards">
                <div class="card-header card-header-rose text-center">
                    <h4 class="card-title">
                        <img src="{{asset('application/public/uploads/settings/'.$logo)}}" title="Logo" alt="Logo" style="width: 80px; margin-top: 25px; border-radius: 10px;"/>
                    </h4>
                </div>
                <h4 class="text-center">@lang('messages.forgot_password')</h4>
                <div class="card-body ">
                    <span class="bmd-form-group">
                        <div class="input-group">
                            <div class="input-group-prepend">
                              <span class="input-group-text">
                                <i class="material-icons">email</i>
                              </span>
                            </div>

                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" placeholder="@lang('messages.email')" required autocomplete="email" autofocus>

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </span>
                </div>
                <div class="card-footer justify-content-center">
                    <button type="submit" class="btn btn-rose btn-link btn-lg" >
                        @lang('messages.reset_my_password') <i class="m-icon-swapright m-icon-white"></i>
                    </button> 
                </div>

                <div class="card-footer justify-content-center">
                    <span class="" style="color: rgb(0, 0, 0); font-size: 12px; margin-bottom: 7px;">
                        <a href="{{ route('admin_login') }}" class="forgot_admin_btn" style="text-decoration: none; color: rgb(0, 0, 0);">@lang('messages.Back to the login')</a>
                    </span> 
                </div>
            </div>
        </form>       

    </div>    
    
</div>

@endsection
