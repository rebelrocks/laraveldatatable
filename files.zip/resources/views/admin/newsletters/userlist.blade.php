@extends('admin.layouts.app')
@section('title', 'Newshistory')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title ">News Notifications</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th width="30%">{{ __('messages.username') }}</th>
                                            <th>{{ __('messages.profileimage') }}</th>
                                            <th>{{ __('messages.email') }}</th>
                                        </thead>
                                        <tbody>
                                            @forelse($newsletterhistories as $newsletter)
                                            <tr>
                                                <td>{{ $newsletter->user->first_name ?? '' }}</td>
                                                <td>
                                                    @if(!empty($newsletter->user->profile_pic) && File::exists('application/public/uploads/users/'.$newsletter->user->profile_pic))
                                                    <img src="{{asset('application/public/uploads/users/'.$newsletter->user->profile_pic)}}" alt="{{$newsletter->user->first_name ?? '' }}" style="width: 20%;" />
                                                    @else 
                                                    <img src="{{asset('content/img/default_user_image.png') }}" alt="{{$newsletter->user->first_name ?? '' }}" style="width: 20%;" /> 
                                                    @endif
                                                </td>
                                                <td>{{ $newsletter->user->email ?? '' }}</td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                    <div class="pull-right"> {{ $newsletterhistories->links() }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
