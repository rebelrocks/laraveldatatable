@extends('admin.layouts.app')
@section('title', 'Wordlists')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title ">@lang('messages.newsletters')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>{{ __('messages.name') }}</th>
                                            <th>{{ __('messages.email') }}</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
                                            @forelse($newsletters as $newsletter)
                                            <tr>
                                                <td>{{ $newsletter->name }}</td>
                                                <td>{{ $newsletter->email }}</td>
                                                <td class="text-right">
                                                    <a href="{{ route('delete_newsletter', $newsletter->id) }}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')">
                                                        <i class="material-icons">clear</i> SUPPRIMER
                                                    </a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                    <div class="pull-right"> {{ $newsletters->links() }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
