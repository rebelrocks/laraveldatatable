@extends('admin.layouts.app')
@section('title', 'Newsletter Notification')
@push('css')
<link rel="stylesheet" href="{{ asset('content/assets/back-end/css/bootstrap-datetimepicker.css') }}">
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }

    #map {
        width: 100%;
        height: 295px;
        margin-top:10px;
    }

    #address{
        z-index: 999;
        position: relative;
        left: 0px !important;
        top: 0px;
        width: 100% !important;
        border: 1px solid #ccc;
        background: #fff;
        padding:4px;
    }

    .gmnoprint{
        margin-top: 33px !important;
    }

    #spingif, #spingifnewsletter{
        display:none;
    }

    #progress_bar{
        margin-top: 15px;
        background: #aaa;
    }

    .ui-widget-header {
        border: 1px solid #d81b60;
        background: #d81b60;
        color: #fff;
        font-weight: bold;
    }

    .ui-progressbar .ui-progressbar-value{
        margin:0px !important;
    }

    #percentageShow{
        width: 100%;
        float: left;
        text-align: center;
        bottom: 26px;
        position: relative;
        color: #fff;
        font-weight: bold;
    }
    
    #searchInput{
        z-index: 999 !important;
        position: relative;
        left: 0px !important;
        top: 0px;
        width: 100% !important;
        background: #D81B60;
        padding: 5px;
        color: #fff;
    }
    
    .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
        float: left;
    }

    /*
    .card form [class*="col-"] {
        padding: 6px;
    }*/

    .bootstrap-datetimepicker-widget{
        width: 25% !important;
        height: 150px !important;
    }

</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('newsletterhistory')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                <h4 class="card-title">@lang('messages.newsletters')</h4>
                            </div>
                            <div class="card-body">
							
								<!-- Language tabs -->
								@include('admin.includes.language_tabs')
							
                                <form method="post" id="newslettersForms" action="{{route('create_newsletter')}}">
                                    @csrf
									<div class="tab-content">
										@php
											$i = 0;
										@endphp
										@foreach($languagecodes as $languagecode)
										@php
											$i++;
										@endphp
										<div id="{{$languagecode->name}}" class="tab-pane fade in @if($i==1) active @endif">
										
											@php
												$lang_name = strtolower($languagecode->name);
											@endphp
											<input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
											<input type="hidden" class="testemaillanguage" value="{{$languagecode->name}}">
											
											<input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$languagecode->id}}">
											
											<div class="row">
												<div class="col-md-12">
													<div class="form-group label-floating is-empty">
														<label class="">{{ __('messages.subject') }}</label>
														<input name="subject[{{$lang_name}}]" class="form-control subject" type="text" value="{{old('subject.'.$lang_name)}}" id="subject_{{$languagecode->name}}" {{ $languagecode->is_default == 1 ? 'required' : '' }} autocomplete="off" autofocus="">
														@if($errors->has('subject.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$subject_error_message = str_replace('.', ' ', $errors->first('subject.'.$lang_name));
																@endphp
																<strong>{{ $subject_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>
											
											<div class="row">
												<div class="col-md-12">
													<div class="form-group label-floating is-empty">
														<label class="control-label content-label">@lang('messages.message')</label>
														<div class="input textarea required">
															<label for="content"></label>
															<textarea class="form-control" id="txtEditor_{{ $languagecode->name }}" name="content[{{$lang_name}}]">{{ old('content.'.$lang_name)}}</textarea>
														</div>
														@if($errors->has('content.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$content_error_message = str_replace('.', ' ', $errors->first('content.'.$lang_name));
																@endphp
																<strong>{{ $content_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>
										</div>
										@endforeach
									</div>
									<div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group label-floating is-empty">
                                                <label class="control-label">@lang('messages.address')</label>
                                                <div class="input text required">
                                                    <label for="address"></label>
                                                    <input type="text" name="address" class="form-control" value="{{old('address')}}" maxlength="254" id="address" required="required" />
                                                    @error('address')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                                <div id="map"></div>
                                            </div>

                                            <ul id="geoData" style="display:none;">
                                                <span id="location"></span>
                                                <span id="postal_code"></span>
                                                <span id="country"></span>
                                                <span class="help-block">
                                                    <strong>Latitude : </strong>
                                                    <span id="latid"></span>
                                                    &nbsp;&nbsp;,&nbsp;&nbsp;
                                                    <strong>Longitude : </strong>
                                                    <span id="lngid"></span>
                                                </span>    
                                            </ul>

                                        </div>

                                        <input type="hidden" class="m-wrap span12 inp-2" name="latitude" id="latitude" value="{{old('latitude')}}" readonly="readonly" />
                                        <input type="hidden" class="m-wrap span12 inp-2" name="longitude" id="longitude" value="{{old('longitude')}}" readonly="readonly" />
                                        
                                        <div class="col-md-6">
                                            
                                            <div class="col-md-6">
                                                <div class="form-group label-floating is-empty">
                                                    <label class="">Min Age</label>
                                                    <input name="min_age" id="min_age" min="1" class="form-control" type="number" value="{{old('min_age')}}" required="required">
                                                    @error('min_age')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group label-floating is-empty">
                                                    <label class="">Max Age</label>
                                                    <input name="max_age" id="max_age" min="1" class="form-control" type="number" value="{{old('max_age')}}" required="required">
                                                    @error('max_age')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="">Location Radius (KM)</label>
                                                    <input name="rad" value="5" class="form-control" placeholder="Enter location Radius" min="1" id="rad" type="number" value="{{old('rad')}}" required="required">
                                                    @error('rad')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="">Total users</label>
                                                    <span id="userCount">0</span>
                                                    <img src="{{ asset('content/img/loading.gif') }}" id="spingif" style="width:25px;" alt="">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
									
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group label-floating">
                                                <div class="togglebutton">
                                                    <label>Test Email 
                                                        <input type="hidden" name="testEmail_status" id="testEmail_" value="0">
                                                        <input type="checkbox" name="testEmailstatus" id="testEmail" class="" value="1" {{ old('testEmailstatus') ? 'checked' : '' }}>
                                                        <span class="toggle"></span>            
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4" id="test_email" style="display: {{ old('testEmailstatus') ? 'block' : 'none' }};">
                                            <div class="form-group label-floating is-empty">
                                                <input name="notificationemail" class="form-control" placeholder="Enter Email" type="email" value="{{old('notificationemail', Auth::user()->email)}}" id="notificationemail">
                                                @error('notificationemail')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
										
										<div class="col-md-4" id="send_test_email" style="display: {{ old('testEmailstatus') ? 'block' : 'none' }};">
										   <div class="form-group label-floating">
												<button type="button" id="ajaxStart" data-id="1" class="sendtestEmail btn btn-primary">{{ __('messages.send_test_email') }}</button>
                                                <img src="{{ asset('content/img/loading.gif') }}" id="spingifnewsletter" style="width:25px;" alt="">
                                            </div>
                                        </div>
                                        
                                    </div>
									
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group label-floating is-empty">
                                                <label class="">Monday</label>
                                                <input name="monday" class="form-control datepicker" type="text" value="{{old('monday')}}" id="monday">
                                                <span class="material-input"></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group label-floating is-empty">
                                                <label class="">Tuesday</label>
                                                <input name="tuesday" class="form-control datepicker" type="text" value="{{old('tuesday')}}" id="tuesday">
                                                <span class="material-input"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group label-floating is-empty">
                                                <label class="">Wednesday</label>
                                                <input name="wednesday" class="form-control datepicker" type="text" value="{{old('wednesday')}}" id="wednesday">
                                                <span class="material-input"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group label-floating is-empty">
                                                <label class="">Thursday</label>
                                                <input name="thursday" class="form-control datepicker" type="text" value="{{old('thursday')}}" id="thursday">
                                                <span class="material-input"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group label-floating is-empty">
                                                <label class="">Friday</label>
                                                <input name="friday" class="form-control datepicker" type="text" value="{{old('friday')}}" id="friday">
                                                <span class="material-input"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group label-floating is-empty">
                                                <label class="">Saturday</label>
                                                <input name="saturday" class="form-control datepicker" type="text" value="{{old('saturday')}}" id="saturday">
                                                <span class="material-input"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group label-floating is-empty">
                                                <label class="">Sunday</label>
                                                <input name="sunday" class="form-control datepicker" type="text" value="{{old('sunday')}}" id="sunday">
                                                <span class="material-input"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" id="savebtn" class="btn btn-primary pull-right">@lang('messages.send_notification')</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection

@push('js')
    
    <script type="text/javascript" src="{{asset('content/assets/ckeditor/ckeditor.js')}}"></script>
    
    <script type="text/javascript">
        var ajax_user_count = '{{route("ajax_newsletter_user_count")}}';
        var ajax_send_newsletter = '{{route("create_newsletter")}}';
    </script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="{{ asset('content/assets/back-end/js/moment.min.js') }}"></script>
    <script src="{{ asset('content/assets/back-end/js/moment-with-locales.js') }}"></script>
    <script type="text/javascript" src="{{ asset('content/assets/back-end/js/bootstrap-datetimepicker.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('content/assets/back-end/js/newsletter-custom.js') }}"></script>
	<!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAsvYS-v-n3gqoXKPtMVIaNqjwaHfj_TNY&libraries=places&callback=initMap" async defer></script>
	<script type="text/javascript">
        $(function(){
            <?php
                foreach($languagecodes as $languagecode){
            ?>
            CKEDITOR.replace('txtEditor_<?php echo $languagecode->name; ?>', {
                fullPage: false,
                // want to  freely enter any HTML content in source mode without any limitations.
                allowedContent: true,
                height:380,
            });
            <?php } ?>
        });

        function isEmail(email) {
              var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              return regex.test(email);
        }

        $(document).ready(function (){

            $('.sendtestEmail').on('click', function () {

                //Generate csrf token for ajax request
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                var next_step = true;

                var $thisbutton = $(this).data('id');
                var subject = $(".tab-pane.active input:text.subject").val();
                var notificationemail = $("#notificationemail").val();
                var testemaillanguage = $(".tab-pane.active .testemaillanguage").val();
                var emailcontent = 'txtEditor_'+testemaillanguage;
                var desc = CKEDITOR.instances[emailcontent].getData();

                if(subject==''){
                    alert("{{ __('messages.Subject field is required')}}");
                    $(".tab-pane.active input:text.subject").focus();
                    next_step = false;
                }else if(desc==''){
                    alert("{{ __('messages.Content field is required')}}");
                    next_step = false;
                }else if(notificationemail==''){
                    alert("{{ __('messages.Email field is required')}}");
                    $("#notificationemail").focus();
                    next_step = false;
                }else if(!isEmail(notificationemail)){
                    alert("{{ __('messages.Email must be a valid email address') }}");
                    $("#notificationemail").focus();
                    next_step = false;
                }

                if(next_step){

                    $("#spingifnewsletter").show();
                    $("#ajaxStart").attr("disabled", true);
                    $.ajax({
                        url: "{{route('ajax_send_test_email_newsletter')}}",
                        type: "post",
                        data: {
                                desc:desc,
                                subject:subject,
                                notificationemail:notificationemail
                            },
                        success: function (result) {
                            console.log(result);
                            $("#spingifnewsletter").hide();
                            $("#ajaxStart").attr("disabled", false);
                            alert(result.success);
                        },
                    });
                }
            });
        });  


		//Google map JS Start
		function initMap() {

			var map = new google.maps.Map(document.getElementById('map'), {
			  center: {lat: -33.8688, lng: 151.2195},
			  zoom: 13
			});
			var input = document.getElementById('address');
			map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

			var autocomplete = new google.maps.places.Autocomplete(input);
			autocomplete.bindTo('bounds', map);

			var infowindow = new google.maps.InfoWindow();
			var marker = new google.maps.Marker({
				map: map,
				anchorPoint: new google.maps.Point(0, -29)
			});

			autocomplete.addListener('place_changed', function() {
				infowindow.close();
				marker.setVisible(false);
				var place = autocomplete.getPlace();
				if (!place.geometry) {
					window.alert("Autocomplete's returned place contains no geometry");
					return;
				}
	  
				// If the place has a geometry, then present it on a map.
				if (place.geometry.viewport) {
					map.fitBounds(place.geometry.viewport);
				} else {
					map.setCenter(place.geometry.location);
					map.setZoom(17);
				}
				marker.setIcon(({
					url: place.icon,
					size: new google.maps.Size(71, 71),
					origin: new google.maps.Point(0, 0),
					anchor: new google.maps.Point(17, 34),
					scaledSize: new google.maps.Size(35, 35)
				}));
				marker.setPosition(place.geometry.location);
				marker.setVisible(true);
		
				var address = '';
				if (place.address_components) {
					address = [
					  (place.address_components[0] && place.address_components[0].short_name || ''),
					  (place.address_components[1] && place.address_components[1].short_name || ''),
					  (place.address_components[2] && place.address_components[2].short_name || '')
					].join(' ');
				}
		
				infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
				infowindow.open(map, marker);
		  
				//Location details
				for (var i = 0; i < place.address_components.length; i++) {
					if(place.address_components[i].types[0] == 'postal_code'){
						document.getElementById('postal_code').innerHTML = place.address_components[i].long_name;
					}
					if(place.address_components[i].types[0] == 'country'){
						document.getElementById('country').innerHTML = place.address_components[i].long_name;
					}
				}
				document.getElementById('address').value = place.formatted_address;
				document.getElementById('latitude').value = place.geometry.location.lat();
				document.getElementById('longitude').value = place.geometry.location.lng();

				document.getElementById('latid').innerHTML = place.geometry.location.lat();
				document.getElementById('lngid').innerHTML = place.geometry.location.lng();
			});
		}
		//Google map JS End
    </script>

@endpush
