@extends('admin.layouts.app')
@section('title', 'Newshistory')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('create_newsletter')}}" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> {{ __('messages.create_new_newsletter') }}<div class="ripple-container"></div></a>
                                <h4 class="card-title "><i class="material-icons iconset">email</i> @lang('messages.newsletter')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>#</th>
                                            <th>{{ __('messages.news_subject') }}</th>
                                            <th>{{ __('messages.news_created_at') }}</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
                                            @forelse($newsletterhistories as $key => $newsletter)
                                            <tr>
                                                <td>{{ $newsletterhistories->firstItem() + $key }}</td>
                                                <td>{{ $newsletter->title }}</td>
                                                <td>{{ \Carbon\Carbon::parse($newsletter->created_at)->format('d/m/Y H:i') }}</td>
                                                
                                                <td class="text-right">

                                                    <a href="{{route('newsletteruserlist', $newsletter->id)}}" class="btn btn-twitter" title=""><i class="material-icons">person</i> @lang('messages.user_list')<div class="ripple-container"></div></a>

                                                    <a href="{{ route('viewnewsstatus', $newsletter->id)}}" class="btn btn-info" title=""><i class="material-icons">remove_red_eye</i> @lang('messages.statuts')</a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                    <div class="pull-right"> {{ $newsletterhistories->links() }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
