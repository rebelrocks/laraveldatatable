@extends('admin.layouts.app')
@section('title', 'Notifications')
@push('css')
    <style type="text/css">
        .progress{
            height: 24px;
        }
        .progress-bar{
            width: 25%;
            background-color: #00C7FF;
			background: linear-gradient(to right, #01F8FF 0%,#00C7FF 100%);
        }
    </style>
@endpush
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                    <!-- alert messages -->
                    @include('admin.layouts.flash-message')
                    <!-- End alert messages -->
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="card card-stats">
                            <div class="card-header card-header-success card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">person</i>
                                </div>
                                <p class="card-category">
                                    {{ __('messages.numberofusernotsend') }}
                                </p>
                                <h3 class="card-title">{{$totalFail}}</h3>
                            </div>
                            <div class="card-footer" style="border: none;"></div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="card card-stats">
                            <div class="card-header card-header-success card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">person</i>
                                </div>
                                <p class="card-category">
                                    {{ __('messages.numberofusersent') }}
                                </p>
                                <h3 class="card-title">{{$totalSend}}</h3>
                            </div>
                            <div class="card-footer" style="border: none;"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-6 col-sm-6">

                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width: {{$percentage}}%;" aria-valuenow="{{$percentage}}" aria-valuemin="0" aria-valuemax="100">{{$percentage}}%</div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
@endsection
