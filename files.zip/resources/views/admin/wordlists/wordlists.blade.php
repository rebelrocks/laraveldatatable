@extends('admin.layouts.app')
@section('title', trans('messages.listwords'))
@push('css')

<!-- Datatable CSS -->
<link href="{{ asset('content/assets/datatables/jquery.dataTables.min.css')}}" rel="stylesheet" type="text/css">

<style type="text/css">

    #datatable span{
      _display:none;
    } 

    .card .card-content {
        padding: 15px 20px;
    }

    .dataTables_wrapper .dataTables_processing {
        position: absolute;
        top: 30%;
        left: 50%;
        width: 30%;
        height: 40px;
        margin-left: -20%;
        margin-top: -25px;
        padding: 8px;
        text-align: center;
        font-size: 1.2em;
        background: none;
        background: linear-gradient(to right, #a3d154 0%, #99cd43 25%, #3f7501 75%, #3f7501 100%);
        color:#fff;
        border: none;
        box-shadow: 0 12px 20px -10px
        rgba(202, 255, 249, 0.28), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(202, 255, 249, 0.2);
        border-radius: 25px;
    }

    .dataTables_wrapper .dataTables_paginate{
        padding: 15px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current, .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        color: #fff !important;
        border: 0;
        border-radius: 30px !important;
        -webkit-transition: all .3s;
        transition: all .3s;
        padding: 0px 11px;
        margin: 0 3px;
        min-width: 30px;
        height: 30px;
        line-height: 30px;
        color: #999999;
        font-weight: 400;
        font-size: 12px;
        text-transform: uppercase;
        text-align: center;
        background-color: #3f7501;
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #3f7501), color-stop(100%, #99cd43));
        background: -webkit-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: -moz-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: -ms-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: -o-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: linear-gradient(to bottom, #99cd43 0%, #3f7501 100%);
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        color: #000 !important;
        border: 0;
        background-color: #fff;
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #fff), color-stop(100%, #fff));
        background: -webkit-linear-gradient(top, #fff 0%, #fff 100%);
        background: -moz-linear-gradient(top, #fff 0%, #fff 100%);
        background: -ms-linear-gradient(top, #fff 0%, #fff 100%);
        background: -o-linear-gradient(top, #fff 0%, #fff 100%);
        background: linear-gradient(to bottom, #fff 0%, #fff 100%);
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        box-sizing: border-box;
        display: inline-block;
        min-width: 1.5em;
        padding: 0.5em 1em;
        margin-left: 2px;
        padding: 0px 11px;
        margin: 0 3px;
        min-width: 30px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        text-decoration: none !important;
        cursor: pointer;
        color: #333 !important;
        border: 0;
        border-radius:  30px !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:active {
        outline: none;
        background-color: #ffffff;
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #ffffff), color-stop(100%, #0c0c0c));
        background: -webkit-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: -moz-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: -ms-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: -o-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: linear-gradient(to bottom, #ffffff 0%, #ffffff 100%);
        box-shadow: inset 0 0 3px #fff;
    }

    table.dataTable thead th, table.dataTable thead td {
        padding: 10px 18px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.06);
    }
    table.dataTable thead th, table.dataTable tfoot th {
        font-weight: bold;
        border-bottom-width: 1px;
        font-size: 1.0625rem;
        font-weight: 300;
    }

    table.dataTable.no-footer {
        border-bottom: 0px solid #111;
    }

    div#datatable_filter, lable {
        padding: 0px 0px 0px 0px !important;
    }
</style>

@endpush
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('create_new_word_list')}}" title="@lang('messages.addword')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.addword')<div class="ripple-container"></div></a>
                                <h4 class="card-title"><i class="material-icons iconset">text_format</i> @lang('messages.listwords')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive material-datatables">
                                    <table id="datatable" class="table dataTable dtr-inline">
                                        <thead class=" text-primary">
                                            <tr role="row">
                                                <th>{{ __('messages.Key Name') }}</th>
                                                <th>{{ __('messages.Key Value') }}</th>
                                                <th>{{ __('messages.Language Code') }}</th>
                                                <th>{{ __('messages.status') }}</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection

@push('js')
    
    <!-- jQuery Library -->
    <script src="{{ asset('content/assets/jquery/3.3.1/jquery.min.js') }}"></script>

    <!-- Datatable JS -->
    <script src="{{ asset('content/assets/datatables/jquery.dataTables.min.js') }}"></script>
    
    <script type="text/javascript">

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function(){
            $('#datatable').DataTable({
                'processing': true,
                'responsive': true,
                'serverSide': true,
                'pageLength': 10,
                'info': false,
                'lengthChange': false,
                'serverMethod': 'post',
                'ajax': {
                    'url':'{{route("ajax_get_wordlists")}}'
                },

                'columns': [
                    { data: 'key_name', name: 'key_name'},
                    { data: 'key_value', name: 'key_value'},
                    { data: 'language_code', name: 'language_code', searchable: false, orderable: false },
                    { data: 'status', name: 'status', searchable: false, orderable: false },
                    { data: 'action', name: 'action', orderable: false, searchable: false, className:"text-right" },
                ],
                language: {
                    paginate: {
                      "first": false,
                      "previous": "{{ __('messages.Pre') }}",
                      "next": "{{ __('messages.Next') }}",
                      "last": false,
                    },
                    emptyTable: "{{ __('messages.No data available') }}",
                    lengthMenu: "Show _MENU_ entries.",             
                    search: "_INPUT_",
                    searchPlaceholder: "{{ __('messages.Search') }}",
                    zeroRecords: "{{ __('messages.No matching records found') }}",
                    processing: "{{ __('messages.Processing') }}",
                },
            });
        });
    </script>
@endpush
