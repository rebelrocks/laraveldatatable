@extends('admin.layouts.app')
@section('title', trans('messages.addword'))
@push('css')
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <a href="{{route('wordlists')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                    <h4 class="card-title">{{ __('messages.addword')}}</h4>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="{{route('create_new_word_list')}}">
                                        @csrf
										
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">{{ __('messages.Key Name') }}</label>
                                                    <input type="text" name="key_name" value="{{old('key_name') }}" class="form-control" maxlength="191" placeholder="Example:key_name" id="key_name" required="required" autofocus >
                                                    @error('key_name')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
										@php
											$str = [".", "1"];
											$rplc   = [" ", "default"];
										@endphp
                                        @foreach($languagecodes as $languagecode)
										@php
											$lang_name = strtolower($languagecode->name);
										@endphp
										<input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$languagecode->id}}">
                                        
										<input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="bmd-label-floating">Word {{ strtolower($languagecode->name) }}</label>
                                                    <input type="text" name="word[{{$lang_name}}]" value="{{ old('word.'.$lang_name) }}" class="form-control" maxlength="191" id="word-{{$languagecode->id}}" autocomplete="word[{{$lang_name}}]" {{ $languagecode->is_default == 1 ? 'required' : '' }} >
                                                    @if($errors->has('word.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$word_error_message = str_replace($str, $rplc, $errors->first('word.'.$lang_name));
															@endphp
															<strong>{{ $word_error_message }}</strong>
														</span>
													@endif
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        <input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status') ? 'checked' : '' }}> @lang('messages.status')
                                                        <span class="form-check-sign">
                                                            <span class="check"></span>
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
