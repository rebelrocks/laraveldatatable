@extends('admin.layouts.app')
@section('title', trans('messages.Edit Word'))
@push('css')
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <a href="{{route('wordlists')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                    <h4 class="card-title">{{ __('messages.Edit Word') }}</h4>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="{{route('edit_word_detial', ['id' => $word_detail->id])}}">
                                        @method('PUT')
                                        @csrf
										<input type="hidden" name="parent_id" value="{{$word_detail->wordlist_id}}" />
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Key Name</label>
                                                    <input type="text" name="key_name" value="{{old('key_name', $word_detail->key_name) }}" class="form-control" maxlength="191" placeholder="Example:key_name" id="key_name" required="required" autofocus >
                                                    @error('key_name')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
										@php
											$str = [".", "1"];
											$rplc   = [" ", "default"];
										@endphp
                                        @foreach($languagecodes as $languagecode)
										@php
											$lang_name = strtolower($languagecode->name);
											$languagecode_id = $languagecode->id;
										@endphp
										<input type="hidden" name="languagecode[{{$languagecode_id}}]" value="{{$languagecode->id}}" placeholder="Languagecode ID">
                                        
										<input type="hidden" name="local[{{$languagecode_id}}]" value="{{ $languagecode->is_default }}"  placeholder="Default Local">
										
										<input type="hidden" name="word_id[{{$languagecode_id}}]" value="{{ Helper::getwordDetail($word_detail->wordlist_id, $languagecode->id)->id ?? '' }}" placeholder="Wordlist ID">
										
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="bmd-label-floating">Word {{ strtolower($languagecode->name) }}</label>
                                                    <input type="text" name="word[{{ $languagecode_id }}]" value="{{ old('word.'.$languagecode->id, Helper::getwordDetail($word_detail->wordlist_id, $languagecode->id)->key_value ?? '') }}" class="form-control" maxlength="191" id="word-{{$languagecode->id}}" autocomplete="word[{{$languagecode_id}}]" >
                                                    @if($errors->has('word.'.$languagecode_id))
														<span class="invalid-feedback" role="alert">
															@php
																$word_error_message = str_replace($str, $rplc, $errors->first('word.'.$languagecode_id));
															@endphp
															<strong>{{ $word_error_message }}</strong>
														</span>
													@endif
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        <input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status', $word_detail->status) ? 'checked' : '' }}> @lang('messages.status')
                                                        <span class="form-check-sign">
                                                            <span class="check"></span>
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
