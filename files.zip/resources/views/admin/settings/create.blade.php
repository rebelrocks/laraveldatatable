@extends('admin.layouts.app')
@section('title', 'Add Settings')
@push('css')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style type="text/css">
    .invalid-feedback{
        display: block !important;
    }
	#map {
        width: 100%;
        height: 295px;
        margin-top:10px;
    }

    #location{
        z-index: 999;
        position: relative;
        left: 0px !important;
        top: 0px;
        width: 100% !important;
        border: 1px solid #ccc;
        background: #fff;
        padding:4px;
    }
	.gmnoprint{
        margin-top: 33px !important;
    }
	#AdsSelectImageType{
		width:100%;
	}
	.form-group input[type=file] {
		opacity: 1 !important;
		position: inherit !important;
		top: 0px;
		right: 0;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 100;
	}
	#ui-datepicker-div{
		z-index : 9999999 !important;	
	}		
	.col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
        float: left;
    }
	.select2-container--default .select2-selection--multiple {
        background-color: white;
        border: 0px solid #aaa !important;
        border-bottom: 1px solid #aaa !important;
        border-radius: 0px;
        cursor: text;
        padding-bottom: 5px;
        padding-right: 5px;
        position: relative;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />

@endpush

@section('content')
            
	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<!-- alert messages -->
					@include('admin.layouts.flash-message')
					<!-- End alert messages -->
					<div class="card">
						<div class="card-header card-header-primary">
							<a href="{{route('questions')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
							<h4 class="card-title"><i class="material-icons iconset">add_to_photos</i> @lang('messages.add_questions')</h4>
						</div>
						<div class="card-body">
						
							<form method="post" action="{{route('store_questions')}}" enctype="multipart/form-data">
							@csrf
							
								<div class="tab-content">
								   <div class="row">
										<div class="col-md-12">
											<div class="form-group label-floating is-empty">
												<label for="title" class="">@lang('messages.title')</label>
												<input type="text" name="title" value="{{ old('title') }}" class="form-control" maxlength="191" >
											</div>
										</div>										
									</div>
									<div class="row">
										<div class="col-md-12" id="BannerImg}">
											<div class="form-group label-floating">
												<label for="banner-image" class="">{{ __('Image') }}</label>
												<input type="file" name="slide_image" class="form-control slugclass" id="banner-image" accept="image/*">
												
											</div>
										</div>
									</div>									
									<div class="row">										
										<div class="col-md-3">
											<div class="form-group label-floating is-empty">
												<label for="category_id" class="">@lang('Catégorie')</label>
												<select name="category_id" id="category_id" class="form-control" required>
													<option value="">@lang('messages.choose_category')</option>
													<?php
													if(count($categories) > 0){
														foreach($categories as $category){
														?>
														<option value="{{ $category->id }}">{{ $category->title}}</option>
														<?php
														}
													} ?>
												</select>
												
											</div>
										</div>
										<div class="col-md-3">
                                            <div class="form-group bmd-form-group is-filled">
                                                <label >@lang('messages.select_content_type')</label>
                                                <select name="content_type" class=" form-control" required id="content_type">
												    <option class="form-control" value="">{{ __('messages.select_content_type') }}</option>
												    <option class="form-control" value="VTC">{{ __('VTC') }}</option>
                                                    <option class="form-control" value="Taxi">{{ __('Taxi') }}</option>
													
                                                </select>
                                                @error('content_type')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
										
										<div class="col-md-3 mt-2">
                                            <div class="form-group bmd-form-group is-filled">
                                                <label >@lang('messages.department')</label>
                                                <select name="department[]" multiple class=" form-control select2" required id="department">
                                                    
                                                </select>
                                                @error('department')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
										<div class="col-md-3">
											<div class="form-group label-floating is-empty">
												<label for="level" class="">@lang('messages.level')</label>
												<select name="level" class="form-control" required>
													<option value="">@lang('messages.choose_level')</option>
													<option value="Easy">Facile</option>
													<option value="Medium">Moyen</option>
													<option value="Expert">Expert</option>
												</select>
												
											</div>
										</div>
										
									</div>	
									
									<div class="row">
									    <div class="col-md-3">
											<div class="form-group label-floating">
												<label for="first_option" class="">{{ __('messages.first_option') }}</label>
												<input type="text" name="first_option" class="form-control slugclass" id="first_option">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label for="second_option" class="">{{ __('messages.second_option') }}</label>
												<input type="text" name="second_option" class="form-control slugclass" id="second_option">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label for="third_option" class="">{{ __('messages.third_option') }}</label>
												<input type="text" name="third_option" class="form-control slugclass" id="third_option">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label for=" fourth_option" class="">{{ __('messages.fourth_option') }}</label>
												<input type="text" name=" fourth_option" class="form-control slugclass" id=" fourth_option">
											</div>
										</div>

									</div>

									<div class="row">
										<div class="col-md-12">
											<div class="form-group label-floating is-empty">
												<label for="description" class="">@lang('messages.explications')</label>
												<textarea name="description" class="form-control"> {{ old('description') }}</textarea>
											</div>
										</div>
										
									</div>
																
									<div class="row">
									    <div class="col-md-3">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="radio" name="correct_option" value="1" {{ old('correct_option') ? 'checked' : '' }}> @lang('messages.correct_option') 
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="radio" name="correct_option" value="2" {{ old('correct_option') ? 'checked' : '' }}>  @lang('messages.correct_option')
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="radio" name="correct_option" value="3" {{ old('correct_option') ? 'checked' : '' }}>  @lang('messages.correct_option')
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="radio" name="correct_option" value="4" {{ old('correct_option') ? 'checked' : '' }}>  @lang('messages.correct_option')
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
									</div>
									<br><br>
									<div class="row">
										<div class="col-md-12">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status') ? 'checked' : 'checked' }}> @lang('messages.status')
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
									</div>		
								
								<button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
								<div class="clearfix"></div>
							</form>
						</div>
					</div>                        
				</div>
			</div>
		</div>
	</div>
@endsection

@push('js')

<script>

</script>
	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- Language script -->
<script type="text/javascript" src="{{ asset('content/assets/back-end/jquery-ui-master/ui/i18n/datepicker-fr.js') }}"></script>
<script type="text/javascript" src="{{asset('content/assets/js/jscolor.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$(document).ready(function(){
	$('.select2').select2({
		language: "fr"
	});

	$('#content_type').change(function(){
		var content_type= $('#content_type').val();
		var HTMLDom='';
		if(content_type == 'VTC'){
			HTMLDom+=`
			<option class="form-control" value="VTC">{{ __('VTC') }}</option>
			`;

		}else if(content_type == 'Taxi'){
			HTMLDom+=`
			<option class="form-control" value="Taxi 75">{{ __('Taxi 75') }}</option>
			<option class="form-control" value="Taxi 93">{{ __('Taxi 93') }}</option>
			`;

		}else{
			
		}
		$('#department').html(HTMLDom);
	});
});
</script>
@endpush
