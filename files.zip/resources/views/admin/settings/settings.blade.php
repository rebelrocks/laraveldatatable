@extends('admin.layouts.boostapp')
@section('title', 'Settings')
@push('css')
<style type="text/css">
    .invalid-feedback{
        display: block !important;
    }

    .form-group input[type=file]{
            z-index: 0;
        }

        .custom-file-upload {
            background: #737373 none repeat scroll 0 0;     
            cursor: pointer;
            display: inline-block;
            padding: 6px 12px;
        }

        .fileinput .thumbnail {
            display: inline-block;
            margin-bottom: 5px;
            overflow: hidden;
            text-align: center;
            vertical-align: middle;
        }

        .thumbnail {
            padding: 4px;
            _line-height: 1.42857;
            _background-color: #fff;
            _border: 1px solid #ddd;
            _border-radius: 4px;
            -webkit-transition: border .2s ease-in-out;
            -o-transition: border .2s ease-in-out;
            transition: border .2s ease-in-out;
        }
        .header_image{
            line-height: 0px !important;
        }
        
        .login-6{
            margin: 0px;
            padding: 0px;
        }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/bootstrap-fileinput/bootstrap-fileinput.css') }}" />
@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><i class="material-icons iconset">settings</i> @lang('messages.general_settings')</h4>
                            </div>
                            <div class="card-body">
                                <form method="post" action="{{ route('web_settings') }}" enctype="multipart/form-data">
                                    @method('PUT')
                                    @csrf
                                    
                                    @foreach($settings as $setting)
                                    <div class="row">

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">
                                                    @php
														$setting->name = trim($setting->name);
                                                        $lable_name = str_replace('.', '_', $setting->name);
                                                        $lable_name = \Str::slug($setting->label,'_');
														$lable_name = trim($lable_name);
                                                    @endphp
                                                    {{ __('messages.'.$lable_name)}}
                                                </label>
                                                @if($setting->type=='select')
                                                @php
                                                    $optionvalues = explode(',', $setting->options);
                                                @endphp
                                                <div class="input text">
                                                    <select class="form-control" name="name[{{$setting->id}}]" class="form-control" id="name-{{$setting->id}}" required="required">
                                                    @foreach($optionvalues as $key => $value)
                                                    @php
                                                        if($value=='No'){
                                                            $value = 'Non';
                                                        }elseif($value=='Yes'){
                                                            $value = 'Oui';
                                                        }else{
                                                            $value = $value;
                                                        }
                                                    @endphp    
                                                    <option {{ $setting->value == $key ? 'selected' : '' }} value="{{$key}}">{{$value}}</option>
                                                    @endforeach        
                                                    </select>
                                                </div>
                                                @elseif($setting->type=='checkbox')
                                                <div class="input text">
                                                    <div class="checkbox statuscheckbox">
                                                        <label> 
                                                            <input type="checkbox" name="name[{{$setting->id}}]" id="name-{{$setting->id}}" value="{{$setting->value == '1' ? '0' : '1' }}" {{ $setting->value == '1' ? 'checked' : '' }}>
                                                            <span class="checkbox-material"><span class="check"></span></span> Statut                                              
                                                        </label>
                                                    </div>
                                                </div>
                                                @elseif($setting->type=='file')
                                                <div class="col-md-6 login-6">
                                                    <div class="label-floating is-empty is-fileinput">
                                                        <div class="fileinput fileinput-exists" data-provides="fileinput">
                                                            <div class="fileinput-new thumbnail header_image" id="header_image" style="width: 100%; height: auto;">
                                                                <img src="{{asset('content/img/image-placeholder.png')}}" alt="">
                                                            </div>
                                                            <div class="fileinput-preview fileinput-exists thumbnail header_image" style="width: 100%; height: auto;"> <img src="{{ asset('application/public/uploads/settings/'.$setting->value) }}" alt="Login background Image"></div>
                                                            <div>
                                                                <span class="btn btn-primary custom-file-upload default btn-file">
                                                                    <span class="fileinput-new"><i class="fa fa-upload"></i> @lang('messages.selectimage') </span>
                                                                    <span class="fileinput-exists"><i class="fa fa-upload"></i> @lang('messages.edit_image') </span>
                                                                    <input type="file" name="files[]" id="" accept="image/*">
                                                                    <input type="hidden" name="images_id[]" value="{{$setting->id}}">
                                                                </span>
                                                                <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"><i class="fa fa-trash"></i> @lang('messages.remove') </a>
                                                            </div>
                                                        </div>
                                                        @if($errors->has('files.'.$setting->id))
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $errors->first('files.'.$setting->id) }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
												
												@elseif($setting->type=='textarea')
                                                <div class="input text">
                                                    <textarea name="name[{{$setting->id}}]" id="name-{{$setting->id}}"  class="form-control">{{ old('name.'.$setting->id, $setting->value) }}</textarea>
                                                    
                                                    @if($errors->has('name.'.$setting->id))
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $errors->first('name.'.$setting->id) }}</strong>
                                                    </span>
                                                    @endif
                                                </div>
                                                
                                                @else
                                                <div class="input text">
                                                    <input type="text" name="name[{{$setting->id}}]" class="form-control" id="name-{{$setting->id}}" value="{{ old('name.'.$setting->id, $setting->value) }}" required="required">
                                                    @if($errors->has('name.'.$setting->id))
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $errors->first('name.'.$setting->id) }}</strong>
                                                    </span>
                                                    @endif
                                                </div>
                                                @endif
                                                <p style="opacity: 0.4;">
                                                    @php
                                                        $desc = \Str::slug($setting->description, '_')
                                                    @endphp
                                                    {{ __('messages.'.$desc) }}
                                                </p>
                                                <span class="material-input"></span>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach                                    
                                    <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection

@push('js')
<script type="text/javascript" src="{{ asset('content/assets/back-end/bootstrap-fileinput/bootstrap-fileinput.js')}}"></script>

@endpush

