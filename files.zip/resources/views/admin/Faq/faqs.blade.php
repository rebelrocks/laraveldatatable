@extends('admin.layouts.app')
@section('title', trans('FAQs'))
@section('content')
            
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                @include('admin.layouts.flash-message')
                <div class="card">
                    <div class="card-header card-header-primary">
						<a href="{{route('faqcategories')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                        <a href="{{route('create_faqs')}}" title="@lang('Ajouter de nouvelles diapositives Premium')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('NOUVELLE QUESTION')<div class="ripple-container"></div></a>
                        <h4 class="card-title"><i class="material-icons iconset">add_to_photos</i> @lang('FAQs')</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class=" text-primary">
                                    <th>@lang('messages.title')</th>
                                    <!-- <th>@lang('messages.category')</th> -->
                                    <th>@lang('messages.status')</th>
                                    <th class="text-right">Actions</th>
                                </thead>
                                <tbody>
                                    @forelse($slides as $slide)
                                    <tr>
                                        <td>{{$slide->title}}</td>
                                        <!-- <td>{{ Helper::getfaqcategoryDetail($slide->faq_category_id, $defaultlanguage->id)->title ?? '' }}</td> -->
                                        <td>
                                            <a id="atag{{$slide->id}}" class="btn btn-{{ $slide->status == 1 ? 'success' : 'danger' }}" data-id="{{$slide->id}}" data-status="{{$slide->status}}" href="javascript:void(0)" onclick="updateSlideStatus(this)">
                                                {{ $slide->status == 1 ? __('messages.statusactive') : __('messages.statusinactive') }}
                                            </a>
                                        </td>
                                        <td class="text-right">
                                            <a href="{{route('edit_faqs', $slide->faq_id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                            <a href="{{ route('delete_faqs', $slide->faq_id) }}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a>
                                        </td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('js')
<script>
function updateSlideStatus(elem){
        var appURL="{{URL::to('/')}}";
        var status = $(elem).attr("data-status");
        var id = $(elem).attr("data-id");	
        $.ajax({
            type: "POST",
            url: appURL+"/admin/faqs/status",
            data: {id:id,status:status},
            success: function(data){
                if(data.success!=''){
                    if(status == 1){	
                        $("#atag"+id).html(inactive); 
                        $("#atag"+id).attr("data-status","0");
                        $("#atag"+id).removeClass('btn-success');		
                        $("#atag"+id).addClass('btn-danger');						
                    }

                    if(status == 0){
                        $("#atag"+id).html(active); 
                        $("#atag"+id).attr("data-status","1");
                        $("#atag"+id).removeClass('btn-danger');		
                        $("#atag"+id).addClass('btn-success');
                    }
                }else if(data.error!=''){
                    alert(data.error);
                }
            }
        });
    }
</script>
@endpush

