@extends('admin.layouts.app')
@section('title', trans('messages.Edit new FAQs'))
@push('css')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<style type="text/css">
   .invalid-feedback{
   display: block !important;
   }
   #map {
   width: 100%;
   height: 295px;
   margin-top:10px;
   }
   #location{
   z-index: 999;
   position: relative;
   left: 0px !important;
   top: 0px;
   width: 100% !important;
   border: 1px solid #ccc;
   background: #fff;
   padding:4px;
   }
   .gmnoprint{
   margin-top: 33px !important;
   }
   #AdsSelectImageType{
   width:100%;
   }
   .form-group input[type=file] {
   opacity: 1 !important;
   position: inherit !important;
   top: 0px;
   right: 0;
   bottom: 0;
   left: 0;
   width: 100%;
   height: 100%;
   z-index: 100;
   }
   #ui-datepicker-div{
   z-index : 9999999 !important;	
   }		
   .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
   float: left;
   }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
@endpush
@section('content')
<div class="content">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-12">
            <!-- alert messages -->
            @include('admin.layouts.flash-message')
            <!-- End alert messages -->
            <div class="card">
               <div class="card-header card-header-primary">
                  <a href="{{route('faqs')}}" class="btn btn-add pull-right">
                     <i class="material-icons">reply</i> @lang('messages.back')
                     <div class="ripple-container"></div>
                  </a>
                  <h4 class="card-title"><i class="material-icons iconset">add_to_photos</i> @lang('messages.Edit new FAQs')</h4>
               </div>
               <div class="card-body">
                  <!-- Language tabs -->
                  <div class="card-content">
                     <ul class="nav nav-tabs" id="myTab">
                        <?php 
						   $i = 0;
                           foreach($languagecodes as $languagecode) {
                           $i++;
                           ?>
                        <li class="@if($i == 1) active @endif"><a data-toggle="tab" href="#{{$languagecode->name}}">{{$languagecode->name}}</a></li>
                        <?php  }?>
                     </ul>
                     <form method="post" action="{{route('update_faqs')}}" enctype="multipart/form-data">
                        @csrf
                        {{ method_field('PUT') }}
                        
								
                        <div class="tab-content">
                        <?php 
                        foreach($slides as $slide)
                        { 
                        $language_arr[] = $slide->getLanguage->id;
                        $lang_name = strtolower($slide->getLanguage->name);
                        
                        ?>
						   
                           <div id="{{$slide->getLanguage->name}}" class="tab-pane fade in <?php echo  ($slide->getLanguage->id == 1) ? 'active':''  ?>">
                            
                              <input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
                              <input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$slide->getLanguage->id}}">
                              <div class="row">
                                 <div class="col-md-12">
                                    <div class="form-group label-floating is-empty">
                                       <label for="title_{{$slide->getLanguage->name}}" class="">@lang('messages.title')</label>
                                       <input type="text" name="title[{{$lang_name}}]" value="{{ $slide->title }}" class="form-control" maxlength="191" id="title_{{$slide->getLanguage->name}}" autocomplete="off" {{ $languagecode->is_default == 1 ? 'required' : '' }} autofocus >
                                       @if($errors->has('title.'.$lang_name))
                                       <span class="invalid-feedback" role="alert">
                                       @php
                                       $title_error_message = str_replace('.', ' ', $errors->first('title.'.$lang_name));
                                       @endphp
                                       <strong>{{ $title_error_message }}</strong>
                                       </span>
                                       @endif
                                    </div>
                                 </div>
                                 
                              </div>
                              <div class="row">
                                 <div class="col-xs-12 col-sm-6 col-md-6 col-lg-12">
                                    <div class="form-group label-floating">
                                       <label class="control-label">@lang('messages.description')</label>
                                       <div class="input text">
                                          <label for="content_{{$slide->getLanguage->name}}"></label>
                                          <textarea class="form-control ckeditor" name="description[{{$lang_name}}]" id="content_{{$slide->getLanguage->name}}" rows="5">{{ $slide->description }}</textarea>
                                          <input type="hidden" name="slide_id" value="{{ $slide->faq_id }}" >
                                       </div>
                                       @if($errors->has('description.'.$lang_name))
                                       <span class="invalid-feedback" role="alert">
                                       @php
                                       $title_error_message = str_replace('.', ' ', $errors->first('description.'.$lang_name));
                                       @endphp
                                       <strong>{{ $title_error_message }}</strong>
                                       </span>
                                       @endif
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php } ?>
							<?php 
							
							foreach($languagecodes as $languagecode) { 
								$lang_name = strtolower($languagecode->name);
							if(in_array($languagecode->id,$language_arr)){
								continue;
							}
							
							?>
							
							<div id="{{$languagecode->name}}" class="tab-pane fade in ">
							 <input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
							<input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$languagecode->id}}">
								<div class="row">
                                 <div class="col-md-12">
                                    <div class="form-group label-floating is-empty">
                                       <label for="title_{{$slide->getLanguage->name}}" class="">@lang('messages.title')</label>
                                       <input type="text" name="title[{{$lang_name}}]" value="" class="form-control" maxlength="191" id="title_{{$slide->getLanguage->name}}" autocomplete="off">
                                       @if($errors->has('title.'.$lang_name))
                                       <span class="invalid-feedback" role="alert">
                                       @php
                                       $title_error_message = str_replace('.', ' ', $errors->first('title.'.$lang_name));
                                       @endphp
                                       <strong>{{ $title_error_message }}</strong>
                                       </span>
                                       @endif
                                    </div>
                                 </div>
                                 
                              </div>
                              <div class="row">
                                 <div class="col-xs-12 col-sm-6 col-md-6 col-lg-12">
                                    <div class="form-group label-floating">
                                       <label class="control-label">@lang('messages.description')</label>
                                       <div class="input text">
                                          <label for="content_{{$slide->getLanguage->name}}"></label>
                                          <textarea class="form-control ckeditor" name="description[{{$lang_name}}]" id="content_{{$slide->getLanguage->name}}" rows="5"></textarea>
                                          <input type="hidden" name="slide_id" value="{{ $slide->faq_id }}" >
                                       </div>
                                       @if($errors->has('description.'.$lang_name))
                                       <span class="invalid-feedback" role="alert">
                                       @php
                                       $title_error_message = str_replace('.', ' ', $errors->first('description.'.$lang_name));
                                       @endphp
                                       <strong>{{ $title_error_message }}</strong>
                                       </span>
                                       @endif
                                    </div>
                                 </div>
                              </div>
							
							</div>
							
							
							
							<?php } ?>
                        </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-check form-check-inline">
                                    <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" name="status" value="1" {{ $slide->status ? 'checked' : '' }}> @lang('messages.status')
                                    <span class="form-check-sign">
                                    <span class="check"></span>
                                    </span>
                                    </label>
                                 </div>
                              </div>
                           </div>
                        <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                        <div class="clearfix"></div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@push('js')
<script></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- Language script -->
<script type="text/javascript" src="{{ asset('content/assets/back-end/jquery-ui-master/ui/i18n/datepicker-fr.js') }}"></script>
<script type="text/javascript" src="{{asset('content/assets/js/jscolor.js')}}"></script>
<script></script>
@endpush