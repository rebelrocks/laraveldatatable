@extends('admin.layouts.app')
@section('title', 'Category')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
								<a href="{{route('faqs')}}" title="@lang('messages.addcategory')" class="btn btn-twitter pull-right"><i class="material-icons">add_to_photos</i> @lang('messages.view_faqlist')<div class="ripple-container"></div></a>
                                <a href="{{route('add_faqcategory')}}" title="@lang('messages.addcategory')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.addcategory')<div class="ripple-container"></div></a>
                                <h4 class="card-title"><i class="material-icons iconset">extension</i> @lang('messages.listfaqcategories')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>#</th>
                                            <th>@lang('messages.title')</th>
											<?php /*@if(!empty(request('id')))*/?>
                                            <th>@lang('messages.status')</th>
											<?php /*@endif*/?>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody class="row_position">
                                            @forelse($faqcategories as $key => $category)
                                            <tr id="{{ $category->id }}">
                                                <td>{{$faqcategories->firstItem() + $key}}</td>
                                                <td>{{$category->title}}</td>
                                                <!--td>{{$category->parentcategory->title ?? ''}}</td-->
												
                                                <td>
                                                    <a id="atag{{$category->id}}" class="btn btn-{{ $category->status == 1 ? 'success' : 'danger' }}" data-id="{{$category->id}}" data-status="{{$category->status}}" href="javascript:void(0)" onclick="updatecategoryStatus(this)">
                                                        {{ $category->status == 1 ? __('messages.statusactive') : __('messages.statusinactive') }}
                                                    </a>
                                                </td>
												
                                                <td class="text-right">
													<a href="{{route('update_faqcategory', ['id' => $category->id])}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
													
													<a href="{{route('delete_faqcategory', ['id' => $category->id])}}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a>
													
													<a href="javascript:void(0);" style="margin-left: 5px;"><i class="material-icons" style="font-size: 42px; color: #ccc;">dehaze</i></a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection

@push('js')
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
	$(".row_position").sortable({
		delay: 150,
		stop: function () {
			var selectedData = new Array();
			$('.row_position>tr').each(function () {
				selectedData.push($(this).attr("id"));
			});
			updateOrder(selectedData);
		}
	});
	
	function updateOrder(data) {
		console.log(data);
		$.ajax({
			url	: "{{route('faqcategories_sortTable')}}",
			type: 'POST',
			data: {position: data},
			success: function () {
				//alert("La disposition a été changée avec succès.");
				//location.reload(true);
			}
		})
	}
</script>
@endpush

