@extends('admin.layouts.app')
@section('title', 'Add Category')
@push('css')

<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />

@endpush

@section('content')
            
	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<!-- alert messages -->
					@include('admin.layouts.flash-message')
					<!-- End alert messages -->
					<div class="card">
						<div class="card-header card-header-primary">
							<a href="{{route('faqcategories', request('id'))}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
							<h4 class="card-title"><i class="material-icons iconset">send</i> @lang('messages.addcategory')</h4>
						</div>
						<div class="card-body">
						
							<!-- Language tabs -->
							@include('admin.includes.language_tabs')
							
							<form method="post" action="{{route('store_faqcategory')}}" enctype="multipart/form-data">
								@csrf
								<div class="tab-content">
									@php
										$i = 0;
										$str = [".", "1", $default_lng_id];
										$rplc   = [" ", "default", $default_lng];
									@endphp
									@foreach($languagecodes as $languagecode)
									@php
										$i++;
									@endphp
									<div id="{{$languagecode->name}}" class="tab-pane fade in @if($i==1) active @endif">
									
										@php
											$lang_name = strtolower($languagecode->name);
											$languagecode_id = $languagecode->id;
										@endphp
										
										<input type="hidden" name="local[{{$languagecode_id}}]" value="{{ $languagecode->is_default }}" >
										
										<input type="hidden" name="languagecode[{{$languagecode_id}}]" value="{{$languagecode->id}}">
										
										@if($languagecode->is_default)
										<?php /*
										<div class="row">
											<div class="col-md-6">
												<div class="form-group label-floating is-empty">
													<label for="category{{$lang_name}}" class="">@lang('messages.category')</label>
													<select name="category[{{$languagecode_id}}]" class="form-control" id="category{{$lang_name}}" {{ $languagecode->is_default == 1 ? 'required' : '' }}>
													@foreach($faqcategories as $category)
													<option {{ old('category.'.$languagecode_id) == $category->id ? 'selected' : '' }} value="{{$category->id }}">{{$category->title}}</option>
													@endforeach
													</select>
													@if($errors->has('category.'.$languagecode_id))
														<span class="invalid-feedback" role="alert">
															<strong>{{ str_replace($str, $rplc, $errors->first('category.'.$languagecode_id)) }}</strong>
														</span>
													@endif
												</div>
											</div>
										</div>
										*/?>
										@endif
										
										<div class="row">
											<div class="col-md-12">
												<div class="form-group label-floating is-empty">
													<label for="name{{$lang_name}}" class="">@lang('messages.name')</label>
													<input type="text" name="name[{{$languagecode_id}}]" value="{{ old('name.'.$languagecode_id) }}" class="form-control" maxlength="191" id="name{{$lang_name}}" autocomplete="off" {{ $languagecode->is_default == 1 ? 'required' : '' }} >
													@if($errors->has('name.'.$languagecode_id))
														<span class="invalid-feedback" role="alert">
															<strong>{{ str_replace($str, $rplc, $errors->first('name.'.$languagecode_id)) }}</strong>
														</span>
													@endif
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-md-6">
												<div class="form-group label-floating is-empty">
													<div class="form-check form-check-inline">
														<label class="form-check-label">
															<input class="form-check-input" type="checkbox" name="status[{{$languagecode_id}}]" value="1" {{ old('status.'.$languagecode_id) ? 'checked' : '' }}> @lang('messages.status')
															<span class="form-check-sign">
																<span class="check"></span>
															</span>
														</label>
													</div>
													@if($errors->has('status.'.$languagecode_id))
														<span class="invalid-feedback" role="alert">
															<strong>{{ str_replace($str, $rplc, $errors->first('status.'.$languagecode_id)) }}</strong>
														</span>
													@endif
												</div>
											</div>
										</div>
									</div>
									@endforeach
								</div>
								<button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
								<div class="clearfix"></div>
							</form>
						</div>
					</div>                        
				</div>
			</div>
		</div>
	</div>
@endsection

@push('js')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
@endpush
