@extends('admin.layouts.app')
@section('title', trans('messages.manage_roles'))
@push('css')
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->
                        
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <!-- <a href="{{route('create_new_role')}}" title="@lang('messages.add_role')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_role')<div class="ripple-container"></div></a> -->
                                <h4 class="card-title"><i class="material-icons iconset">supervisor_account</i> @lang('messages.manage_roles')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <tr role="row">
                                                <th>#</th>
                                                <th>{{ __('messages.title') }}</th>
                                                <th class="text-right">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($roles as $key => $role)
                                            <?php $admin_role = $role->id; ?>
                                            <tr>
                                                <td>{{ $roles->firstItem() + $key }}</td>
                                                <td>{{ $user_role = $role->name }}</td>
                                                <td class="text-right">
													@if($admin_role != 4)
													<a class="btn btn-success" href="{{route('sitepermissions', $role->id)}}">
                                                        {{ __('messages.Edit permissions') }}
                                                    </a>
													@endif
                                                    <a href="{{route('edit_role', $role->id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                    <?php if($role->id  > 16){ ?>
                                                    <a href="{{ route('delete_role', $role->id) }}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a>
                                                    <?php }?>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                    <div class="pull-right"> {{ $roles->links() }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
