            <footer class="footer ">
                <div class="container-fluid">
                    <div class="copyright pull-right" style="font-size: 14px;">
                        Copyright &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script> 
                        {{Helper::getapplicationName()}} - Powered by  
                        <a href="http://perfectseo.in/" target="_blank"> Perfect Marketing agency <div class="ripple-container"></div></a>
                    </div>
                </div>
            </footer>