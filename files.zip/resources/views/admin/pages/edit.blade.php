@extends('admin.layouts.app')
@section('title', trans('messages.edit_page'))
@push('css')
<style type="text/css">
    .invalid-feedback{
        display: block !important;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('cms_pages')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                <h4 class="card-title">@lang('messages.edit_page')</h4>
                            </div>
                            <div class="card-body">
								<!-- Language tabs -->
								@include('admin.includes.language_tabs')
								<form method="post" action="{{route('editpage', $page->id)}}" enctype="multipart/form-data">
									@method('PUT')
									@csrf
									<input type="hidden" name="parent_id" value="{{$page->page_id}}" />
									<div class="tab-content">
										@php
											$i = 0;
											$str = [".", "1"];
											$rplc   = [" ", "default"];
										@endphp
										@foreach($languagecodes as $languagecode)
										@php
											$i++;
											$page_id = $page->id;
										@endphp
										
										<div id="{{$languagecode->name}}" class="tab-pane fade in @if($i==1) active @endif">
											
											@php
												$lang_name = strtolower($languagecode->name);
											@endphp
												
											<input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$languagecode->id}}">
                                        
											<input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
												
											<input type="hidden" name="page_id[{{$lang_name}}]" value="{{ Helper::cmspageDetail($page->page_id, $languagecode->id)->id ?? '' }}">
												
											<div class="row">
												<div class="col-xs-12 col-sm-6 col-md-6 col-lg-12">
													<div class="form-group label-floating">
														<label class="control-label">@lang('messages.title')</label>
														<div class="input text">
															<label for="title_{{$languagecode->name}}"></label>
															<input type="text" class="form-control" name="title[{{$lang_name}}]" value="{{ old('title.'.$lang_name,  Helper::cmspageDetail($page->page_id, $languagecode->id)->title ?? '') }}" autocomplete="off">
														</div>
														@if($errors->has('title.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$title_error_message = str_replace($str, $rplc, $errors->first('title.'.$lang_name));
																@endphp
																<strong>{{ $title_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>

											<div class="row">
												<div class="col-xs-12 col-sm-6 col-md-6 col-lg-12">
													<div class="form-group label-floating">
														<label class="control-label">@lang('messages.description')</label>
														<div class="input text">
															<label for="content_{{$languagecode->name}}"></label>
															<textarea class="form-control ckeditor" name="content[{{$lang_name}}]" id="content_{{$languagecode->name}}" rows="10">{{ old('content.'.$lang_name,  Helper::cmspageDetail($page->page_id, $languagecode->id)->content ?? '') }}</textarea>
														</div>
														@if($errors->has('content.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$content_error_message = str_replace($str, $rplc, $errors->first('content.'.$lang_name));
																@endphp
																<strong>{{ $content_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>
												
											<div class="row">
												<div class="col-md-12">
													<div class="form-check form-check-inline">
														<label class="form-check-label">
															<input class="form-check-input" type="checkbox" name="status[{{$lang_name}}]" value="1" {{ old('status.'.$lang_name, Helper::cmspageDetail($page->page_id, $languagecode->id)->status ?? '') ? 'checked' : '' }}> @lang('messages.status')
															<span class="form-check-sign">
																<span class="check"></span>
															</span>
														</label>
													</div>
													@if($errors->has('status.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$status_error_message = str_replace($str, $rplc, $errors->first('status.'.$lang_name));
															@endphp
															<strong>{{ $status_error_message }}</strong>
														</span>
													@endif
												</div>
											</div>
										</div>
										@endforeach	
									</div>
									<button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
									<div class="clearfix"></div>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection


@push('js')
	<script>

		$(document).ready(function(){

			$('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
				localStorage.setItem('activeTab', $(e.target).attr('href'));
			});

			var activeTab = localStorage.getItem('activeTab');

			if(activeTab){
				$('#myTab a[href="' + activeTab + '"]').tab('show');
			}
		});
	</script>
    <script type="text/javascript" src="{{asset('content/assets/ckeditor/ckeditor.js')}}"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
@endpush
