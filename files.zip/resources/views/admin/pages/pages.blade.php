@extends('admin.layouts.app')
@section('title', trans('messages.cms_page_listing'))
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><i class="material-icons iconset">view_list</i> @lang('messages.cms_page_listing')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>@lang('messages.title')</th>
                                            <th>@lang('messages.status')</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
                                            @forelse($pages as $page)
                                            <tr>
                                                <td>{{$page->title}}</td>
                                                <td>
                                                    <a id="atag{{$page->id}}" class="btn btn-{{ $page->status == 1 ? 'success' : 'danger' }}" data-id="{{$page->id}}" data-status="{{$page->status}}" href="javascript:void(0)" onclick="updatecmsStatus(this)">
                                                        {{ $page->status == 1 ? __('messages.statusactive') : __('messages.statusinactive') }}
                                                    </a>
                                                </td>
                                                <td class="text-right">
                                                    <a href="{{route('editpage', $page->id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
