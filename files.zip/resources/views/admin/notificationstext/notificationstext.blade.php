@extends('admin.layouts.app')
@section('title', 'Notification')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('add_notification_text')}}" title="@lang('messages.add_notification_text')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_notification_text')<div class="ripple-container"></div></a>
                                <h4 class="card-title "><i class="material-icons iconset">notifications</i> @lang('messages.manage_notification_text')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>#</th>
                                            <th>@lang('messages.title')</th>
                                            <th>@lang('messages.description')</th>
                                            <th>@lang('messages.notification_text_added')</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
                                            @php
                                                $i = 1;
                                            @endphp
                                            @forelse($notifications as $notification)
                                            <tr>
                                                <td>{{$i++}}</td>
                                                <td>{{$notification->title}}</td>
                                                <td>{{$notification->description}}</td>
                                                <td>{{ Helper::dateformatDmy($notification->created_at)}} </td>
                                                <td class="text-right">
                                                    <a href="{{route('edit_notification_text', $notification->id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                    <a href="{{ route('delete_notification_text', $notification->id) }}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a-->
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="7" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                    <div class="pull-right"> {{ $notifications->links() }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
