@extends('admin.layouts.app')
@section('title', 'Notification Text')
@push('css')
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
							<div class="card-header card-header-primary">
								<a href="{{route('notificationtext')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
								<h4 class="card-title">Add Notification Text</h4>
							</div>
							<div class="card-body">

								<!-- Language tabs -->
								@include('admin.includes.language_tabs')

								<form method="post" id="form" action="{{route('add_notification_text')}}">
									@csrf
									<div class="tab-content">
										@php
											$i = 0;
										@endphp
										@foreach($languagecodes as $languagecode)
										@php
											$i++;
										@endphp
										<div id="{{$languagecode->name}}" class="tab-pane fade in @if($i==1) active @endif">
											@php
												$lang_name = strtolower($languagecode->name);
											@endphp
											<input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
											<input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$languagecode->id}}">
											<div class="row">
												<div class="col-xs-12 col-sm-6 col-md-6 col-lg-10">
													<div class="form-group label-floating">
														<label class="control-label">@lang('messages.title')</label>
														<div class="input text">
															<label for="title_{{$languagecode->name}}"></label>
															<input type="text" class="form-control" name="title[{{$lang_name}}]" id="title_{{$languagecode->name}}" value="{{ old('title.'.$lang_name) }}" {{ $languagecode->is_default == 1 ? 'required' : '' }} autocomplete="off">
														</div>
														@if($errors->has('title.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$title_error_message = str_replace('.', ' ', $errors->first('title.'.$lang_name));
															@endphp
															<strong>{{ $title_error_message }}</strong>
														</span>
														@endif
													</div>
												</div>
											</div>

											<div class="row">
												<div class="col-xs-12 col-sm-6 col-md-6 col-lg-10">
													<div class="form-group label-floating">
														<label class="control-label">@lang('messages.description')</label>
														<div class="input text">
															<label for="description_{{$languagecode->name}}"></label>
															<textarea class="form-control" name="description[{{$lang_name}}]" rows="5" id="description_{{$languagecode->name}}" {{ $languagecode->is_default == 1 ? 'required' : '' }}>{{ old('description.'.$lang_name) }}</textarea>
														</div>
														@if($errors->has('description.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$description_error_message = str_replace('.', ' ', $errors->first('description.'.$lang_name));
															@endphp
															<strong>{{ $description_error_message }}</strong>
														</span>
														@endif
														
													</div>
												</div>
											</div>   
										</div>
										@endforeach	
									</div>    
									<button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
									<div class="clearfix"></div>
								</form>
							</div>
						</div>
                    </div>
                </div>
            </div>
        </div>
@endsection


@push('js')

    <script type="text/javascript">

        $(document).ready(function () {
			
            /* $(".languagecode_title").change(function () {
                var selectedValue = $(this).val();
                $('.languagecode_des option:selected').removeAttr('selected', 'selected'); 
                $(".languagecode_des option[value="+selectedValue+"]").attr('selected', 'selected');                
                $('.languagecode_title option:selected').removeAttr('selected', 'selected');
            }); */
	/* 		
			$('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
                localStorage.setItem('activeTab', $(e.target).attr('href'));
            });

            var activeTab = localStorage.getItem('activeTab');

            if(activeTab){
                $('#myTab a[href="' + activeTab + '"]').tab('show');
            } */

        });
		
		/* 		
		$(document).ready(function() {
			$('#form').validate({
				ignore: ".ignore",
				invalidHandler: function(){             
					$("#tabs").tabs("select", $("#form .input-validation-error").closest(".tab-pane").get(0).id);
				}
			});
		}); */

    </script>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

@endpush
