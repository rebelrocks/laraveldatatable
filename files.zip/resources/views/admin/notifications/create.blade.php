@extends('admin.layouts.app')
@section('title', trans('messages.add_new_notification'))
@push('css')
<style type="text/css">
    .invalid-feedback{
        display: block !important;
    }

    #map {
        width: 100%;
        height: 295px;
        margin-top:10px;
    }

    #address{
        z-index: 999;
        position: relative;
        left: 0px !important;
        top: 0px;
        width: 100% !important;
        border: 1px solid #ccc;
        background: #fff;
        padding:4px;
    }

    .gmnoprint{
        margin-top: 33px !important;
    }

    #spingif{
        display:none;
    }
	
	.col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
        float: left;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('notifications')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                <h4 class="card-title">@lang('messages.add_new_notification')</h4>
                            </div>
                            <div class="card-body">
								<!-- Language tabs -->
								@include('admin.includes.language_tabs')
								
                                <form method="post" action="{{route('create_notification')}}" onsubmit="return validateForm();">
                                    @csrf
									<div class="tab-content">
										@php
											$i = 0;
										@endphp
										@foreach($languagecodes as $languagecode)
										@php
											$i++;
										@endphp
										<div id="{{$languagecode->name}}" class="tab-pane fade in @if($i==1) active @endif">
										
											@php
												$lang_name = strtolower($languagecode->name);
											@endphp
											
											<input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
											
											<input type="hidden" class="testemaillanguage" value="{{$languagecode->name}}">
											
											<input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$languagecode->id}}">
											
											<div class="row">												
												<div class="col-md-12">
													<div class="form-group label-floating is-empty">
														<label class="">Notification Title</label>
														<input name="title[{{$lang_name}}]" class="form-control" type="text" value="{{old('title.'.$lang_name)}}" id="title{{$languagecode->name}}" {{ $languagecode->is_default == 1 ? 'required' : '' }} autocomplete="off" autofocus="">
														@if($errors->has('title.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$title_error_message = str_replace('.', ' ', $errors->first('title.'.$lang_name));
																@endphp
																<strong>{{ $title_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>
											
											<div class="row">
												<div class="col-md-12">
													<div class="form-group label-floating is-empty">
														<label class="">@lang('messages.message')</label>
														<textarea name="description[{{$lang_name}}]" class="form-control" id="description{{$languagecode->name}}" rows="5" {{ $languagecode->is_default == 1 ? 'required' : '' }} autocomplete="off">{{old('description.'.$lang_name)}}</textarea>
														@if($errors->has('description.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$description_error_message = str_replace('.', ' ', $errors->first('description.'.$lang_name));
																@endphp
																<strong>{{ $description_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>
											
											<div class="row">
												<div class="col-md-12">
													<div class="form-group label-floating is-empty">
														<label class="">@lang('messages.link')</label>
														<input type="url" name="link[{{$lang_name}}]" value="{{old('link.'.$lang_name)}}" class="form-control" maxlength="254" id="link{{$lang_name}}" {{ $languagecode->is_default == 1 ? 'required' : '' }} />
														@if($errors->has('link.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$link_error_message = str_replace('.', ' ', $errors->first('link.'.$lang_name));
																@endphp
																<strong>{{ $link_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>
										</div>
										@endforeach
									
										
										<div class="row">
											<div class="col-md-7">
												<div class="form-group label-floating is-empty">
													@error('address')
														<span class="invalid-feedback" role="alert">
															<strong>{{ $message }}</strong>
														</span>
													@enderror	
													<label for="address">@lang('messages.address')</label>
													<input type="text" name="address" class="form-control" value="{{old('address')}}" maxlength="254" id="address" required="required" />
													<div id="map"></div>
												</div>

												<ul id="geoData" style="display:none;">
													<span id="location"></span>
													<span id="postal_code"></span>
													<span id="country"></span>
												</ul>
											</div>

											<div class="col-md-5">
												<div class="row">
													<div class="col-md-12">
														<div class="form-group label-floating is-empty">
															<label class="">Type d'utilisateur</label>
															<div class="pull-left" style="width: 100%;">
																<div class="radio">
																	<label>
																		<input type="radio" value="1" id="both_user_type" class="user_type user_type_radio" name="user_type" checked=""> Tous les utilisateurs
																	</label>
																</div>
															</div>

															<!-- <div class="pull-left" style="width: 100%;">
																<div class="radio">
																	<label>
																		<input type="radio" value="2" id="traveler" class="user_type user_type_radio" name="user_type" > @lang('Utilisateurs basic')
																	</label>
																 </div>
                                                            </div>
                                                            <div class="pull-left" style="width: 100%;">
																<div class="radio">
																	<label>
																		<input type="radio" value="3" id="traveler" class="user_type user_type_radio" name="user_type" > @lang('Utilisateurs premium')
																	</label>
																 </div>
                                                            </div> -->
                                                            
                                                            <div class="pull-left" style="width: 100%;">
                                                                <div class="radio">
                                                                    <label>
                                                                        <input type="radio" value="1" id="selected_single_user" class="user_type user_type_radio" name="user_type" > @lang('Utilisateur sélectionné')
                                                                        &nbsp;&nbsp;&nbsp;<select class="form-control" name="single_user" id="single_user_container">
                                                                        <option value="">Choisissez un utilisateur...</option>
                                                                        <?php
                                                                        $users=App\Models\User::whereIn('role_id',[1,2])->where('status',1)->get();
                                                                        foreach($users as $user){
																			if( !empty($user->name) && $user->name != 'NULL'){
																				echo '<option value="'.$user->id.'">'.$user->name.' | '.$user->email.'</option>';
																			}
                                                                        }
                                                                        ?>
                                                                        </select>
                                                                        <input type="hidden" name="is_single_user" id="isSingleUser">
                                                                    </label>
                                                                    </div>
                                                            </div>

															
															@error('user_type')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-12">
														<div class="form-group label-floating" style="margin-top: 5px;">
															<label class="">Rayon de localisation (km)</label>
															<input name="srcradiusius" value="5" class="form-control" min="1" id="srcradius" type="number" value="{{old('srcradiusius')}}" required="required">
															@error('srcradiusius')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-12">
														<div class="form-group label-floating" style="margin-top: 5px;">
															<input type="hidden" name="totalusercount" id="totalusercount" value="0" >
															<label class="">Nombre d'utilisateurs ciblés</label>
															<span id="userCount">0</span>
															<img src="{{ asset('content/img/loading.gif') }}" id="spingif" style="width:25px;" alt="loading">
														</div>
													</div>
												</div>
												
												<div class="row">
													<div class="col-md-12">
														<div class="form-group label-floating" style="margin-top: 5px;">
															<label class="">Latitude</label>
															<input name="latitude" id="latitude" value="{{old('latitude')}}" class="form-control" type="text" value="{{old('srcradiusius')}}" readonly autocomplete="off" required="required">
															@error('latitude')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>
												</div>
												
												<div class="row">
													<div class="col-md-12">
														<div class="form-group label-floating" style="margin-top: 5px;">
															<label class="">Longitude</label>
															<input name="longitude" id="longitude" value="{{old('longitude')}}" class="form-control" type="text" value="{{old('srcradiusius')}}" readonly autocomplete="off" required="required">
															@error('longitude')
																<span class="invalid-feedback" role="alert">
																	<strong>{{ $message }}</strong>
																</span>
															@enderror
														</div>
													</div>
												</div>											
											</div>
										</div>
									</div>
                                    <button type="submit" class="btn btn-primary pull-right">@lang('messages.send_notification')</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection

@push('js')
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
    <!--  Google Maps Plugin    -->
    
    <script type="text/javascript">

        jQuery(document).ready(function(){

            $('#single_user_container').hide();

            $('.user_type_radio').change(()=>{
                
                if($('#selected_single_user').is(':checked')){  
                    $('#single_user_container').show();
                    $("#single_user_container").prop('required',true); 
                    $('#isSingleUser').val('1');
                }else{
                    $("#single_user_container").prop('required',false); 
                    $('#single_user_container').hide();
                    $('#isSingleUser').val('0');
                }
            });


            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#srcradius').on('change keyup', function() {
                var sanitized = $(this).val().replace(/[^0-9]/g, '');
                $(this).val(sanitized);
            });

            var checkteck = 0;
    
            //this below code for select state when show city
            $('#address').focusout(function(e) {
                $("#userCount").hide();
                $("#spingif").show();
                setTimeout(function(){
                    var lat = jQuery('#latitude').val();
                    var lng = jQuery('#longitude').val();
                    var srcradius = jQuery('#srcradius').val();
                    var user_type = $("input[name='user_type']:checked").val();
                    $.ajax({
                        type: 'POST', 
                        data: {lat:lat,lng:lng,srcradius:srcradius,user_type:user_type},
                        url: '{{route("ajax_user_count")}}',
                        success: function(response){
                            $("#spingif").hide();
                            $("#userCount").show();
                            $("#userCount").html(response);
							$("#totalusercount").val(response);
                        }
                    });
                },1000);
            });
    
            $('#srcradius').change(function(e) {
                if(checkteck == 1){
                    checkteck = 0;
                    return false;
                }
                checkteck = 1;
                if($("#address").val() == ''){
                    alert("please select an address");
                    return false;
                }
                $("#userCount").hide();
                $("#spingif").show();
                setTimeout(function(){
                    var lat = jQuery('#latitude').val();
                    var lng = jQuery('#longitude').val();
                    var srcradius = jQuery('#srcradius').val();
                    var user_type = $("input[name='user_type']:checked").val();
                    $.ajax({
                        type: 'POST', 
                        data: {lat:lat,lng:lng,srcradius:srcradius,user_type:user_type},
                        url: '{{route("ajax_user_count")}}',
                        success: function(response){
                            $("#spingif").hide();
                            $("#userCount").show();
                            $("#userCount").html(response);
							$("#totalusercount").val(response);
                        }
                    });
                },1000);
            });
    
            $('#srcradius').keyup(function(e) {
                if(checkteck == 1){
                    checkteck = 0;
                    return false;
                }
                checkteck = 1;
                if($("#address").val() == ''){
                    alert("please select an address");
                    return false;
                }
                $("#userCount").hide();
                $("#spingif").show();
                setTimeout(function(){
                    var lat = jQuery('#latitude').val();
                    var lng = jQuery('#longitude').val();
                    var srcradius = jQuery('#srcradius').val();
                    var user_type = $("input[name='user_type']:checked").val();
                    $.ajax({
                        type: 'POST', 
                        data: {lat:lat,lng:lng,srcradius:srcradius,user_type:user_type},
                        url: '{{route("ajax_user_count")}}',
                        success: function(response){
                            $("#spingif").hide();
                            $("#userCount").show();
                            $("#userCount").html(response);
							$("#totalusercount").val(response);
                        }
                    });
                },1000);
            });
        });
		
	function validateForm()
	{
		if($('#totalusercount').val()==0){
            if($('#selected_single_user').is(':checked')===false){		
			alert("Users not found in this criteria.");				
			return false;			
			$("input[type=submit]").attr('disabled','disabled');
            }else{
                $("#single_user_container").prop('required',true); 
            }
		}		
		return true;
	}
    function initMap() {

        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -33.8688, lng: 151.2195},
          zoom: 13
        });
        var input = document.getElementById('address');
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);

        var infowindow = new google.maps.InfoWindow();
        var marker = new google.maps.Marker({
            map: map,
            anchorPoint: new google.maps.Point(0, -29)
        });

        autocomplete.addListener('place_changed', function() {
            infowindow.close();
            marker.setVisible(false);
            var place = autocomplete.getPlace();
            if (!place.geometry) {
                window.alert("Autocomplete's returned place contains no geometry");
                return;
            }
  
            // If the place has a geometry, then present it on a map.
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);
            }
            marker.setIcon(({
                url: place.icon,
                size: new google.maps.Size(71, 71),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(17, 34),
                scaledSize: new google.maps.Size(35, 35)
            }));
            marker.setPosition(place.geometry.location);
            marker.setVisible(true);
    
            var address = '';
            if (place.address_components) {
                address = [
                  (place.address_components[0] && place.address_components[0].short_name || ''),
                  (place.address_components[1] && place.address_components[1].short_name || ''),
                  (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
            }
    
            infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
            infowindow.open(map, marker);
      
            //Location details
            for (var i = 0; i < place.address_components.length; i++) {
                if(place.address_components[i].types[0] == 'postal_code'){
                    document.getElementById('postal_code').innerHTML = place.address_components[i].long_name;
                }
                if(place.address_components[i].types[0] == 'country'){
                    document.getElementById('country').innerHTML = place.address_components[i].long_name;
                }
            }
            document.getElementById('address').value = place.formatted_address;
            document.getElementById('latitude').value = place.geometry.location.lat();
            document.getElementById('longitude').value = place.geometry.location.lng();
        });
    }
</script>
@endpush
