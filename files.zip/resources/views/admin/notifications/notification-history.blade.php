@extends('admin.layouts.app')
@section('title', 'Notifications')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                    <!-- alert messages -->
                    @include('admin.layouts.flash-message')
                    <!-- End alert messages -->
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="card card-stats">
                            <div class="card-header card-header-success card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">person</i>
                                </div>
                                <p class="card-category">
                                    Total notifications
                                </p>
                                <h3 class="card-title">{{$total_notifications}}</h3>
                            </div>
                            <div class="card-footer" style="border: none;"></div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="card card-stats">
                            <div class="card-header card-header-success card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">person</i>
                                </div>
                                <p class="card-category">
                                    Number of remaining notifications
                                </p>
                                <h3 class="card-title">{{$remaining_notifications}}</h3>
                            </div>
                            <div class="card-footer" style="border: none;"></div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="card card-stats">
                            <div class="card-header card-header-success card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">person</i>
                                </div>
                                <p class="card-category">
                                    Number of notifications sent
                                </p>
                                <h3 class="card-title">{{$sent_notifications}}</h3>
                            </div>
                            <div class="card-footer" style="border: none;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
