@extends('admin.layouts.app')
@section('title', trans('messages.Notification receive users'))
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('notifications')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                <h4 class="card-title ">@lang('messages.Notification receive users')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class="text-primary">
                                            <th>@lang('messages.first_name')</th>
                                            <th>@lang('messages.profile_image')</th>
                                        </thead>
                                        <tbody>
                                            @forelse($users as $user)
                                            <tr>
                                                <td>{{$user->first_name}}</td>
                                                <td>
                                                    @if(!empty($user->profile_pic) && File::exists('application/public/uploads/users/'.$user->profile_pic))
                                                    @php $user_profile = 'application/public/uploads/users/'.$user->profile_pic; @endphp
                                                    @else
                                                    @php $user_profile = 'content/img/default_user_image.png'; @endphp
                                                    @endif
                                                    <img src="{{ asset($user_profile) }}" style="max-width: 130px; max-height: 130px;"; class="img img-circle" alt="{{$user->first_name}}">
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
