@extends('admin.layouts.app')
@section('title', trans('messages.add_notification'))
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('create_notification')}}" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_notification')<div class="ripple-container"></div></a>
                                <h4 class="card-title "><i class="material-icons iconset">notifications</i> @lang('messages.add_notification')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class="text-primary">
                                            <th>@lang('messages.title')</th>
                                            <th>@lang('messages.description')</th>
                                            <th>@lang('messages.address')</th>
                                            <th>@lang('messages.sent_on')</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
                                            @forelse($notifications as $notification)
                                            <tr>
                                                <td>{{ ($notification->title) }}</td>
                                                <td>{{ $notification->description }}</td>
                                                <td>{{ $notification->address }}</td>
                                                <td>{{ \Carbon\Carbon::parse($notification->created_at)->format('d/m/Y H:i') }}</td>
                                                <td class="text-right">

                                                    <a href="{{route('notification_receive_users', $notification->id)}}" class="btn btn-twitter" title=""><i class="material-icons">person</i> @lang('messages.user_list')<div class="ripple-container"></div></a>

                                                    <a href="{{ route('notification_history', $notification->id)}}" class="btn btn-info" title=""><i class="material-icons">history</i> @lang('messages.statuts')</a>

                                                    <a href="{{route('delete_notifications', $notification->id)}}" class="btn btn-danger" title="Delete" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER<div class="ripple-container"></div></a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
