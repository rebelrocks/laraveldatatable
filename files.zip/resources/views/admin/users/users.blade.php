@extends('admin.layouts.app')
@section('title', trans('messages.user_lists'))
@push('css')

<!-- Datatable CSS -->
<link href="{{ asset('content/assets/datatables/jquery.dataTables.min.css')}}" rel="stylesheet" type="text/css">

<style type="text/css">

    #datatable span{
      display:none;
    } 

    .card .card-content {
        padding: 15px 20px;
    }

    .dataTables_wrapper .dataTables_processing {
        position: absolute;
        top: 30%;
        left: 50%;
        width: 30%;
        height: 40px;
        margin-left: -20%;
        margin-top: -25px;
        padding: 8px;
        text-align: center;
        font-size: 1.2em;
        background: none;
        background: linear-gradient(to right, #a3d154 0%, #99cd43 25%, #3f7501 75%, #3f7501 100%);
        color:#fff;
        border: none;
        box-shadow: 0 12px 20px -10px
        rgba(202, 255, 249, 0.28), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(202, 255, 249, 0.2);
        border-radius: 25px;
    }

    .dataTables_wrapper .dataTables_paginate{
        padding: 15px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current, .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        color: #fff !important;
        border: 0;
        border-radius: 30px !important;
        -webkit-transition: all .3s;
        transition: all .3s;
        padding: 0px 11px;
        margin: 0 3px;
        min-width: 30px;
        height: 30px;
        line-height: 30px;
        color: #999999;
        font-weight: 400;
        font-size: 12px;
        text-transform: uppercase;
        text-align: center;
        background-color: #3f7501;
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #3f7501), color-stop(100%, #99cd43));
        background: -webkit-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: -moz-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: -ms-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: -o-linear-gradient(top, #99cd43 0%, #3f7501 100%);
        background: linear-gradient(to bottom, #99cd43 0%, #3f7501 100%);
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        color: #000 !important;
        border: 0;
        background-color: #fff;
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #fff), color-stop(100%, #fff));
        background: -webkit-linear-gradient(top, #fff 0%, #fff 100%);
        background: -moz-linear-gradient(top, #fff 0%, #fff 100%);
        background: -ms-linear-gradient(top, #fff 0%, #fff 100%);
        background: -o-linear-gradient(top, #fff 0%, #fff 100%);
        background: linear-gradient(to bottom, #fff 0%, #fff 100%);
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        box-sizing: border-box;
        display: inline-block;
        min-width: 1.5em;
        padding: 0.5em 1em;
        margin-left: 2px;
        padding: 0px 11px;
        margin: 0 3px;
        min-width: 30px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        text-decoration: none !important;
        cursor: pointer;
        color: #333 !important;
        border: 0;
        border-radius:  30px !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:active {
        outline: none;
        background-color: #ffffff;
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #ffffff), color-stop(100%, #0c0c0c));
        background: -webkit-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: -moz-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: -ms-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: -o-linear-gradient(top, #2b2b2b 0%, #0c0c0c 100%);
        background: linear-gradient(to bottom, #ffffff 0%, #ffffff 100%);
        box-shadow: inset 0 0 3px #fff;
    }

    table.dataTable thead th, table.dataTable thead td {
        padding: 10px 12px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.06);
    }
    table.dataTable thead th, table.dataTable tfoot th {
        font-weight: bold;
        border-bottom-width: 1px;
        font-size: 1.0625rem;
        font-weight: 300;
    }

    table.dataTable.no-footer {
        border-bottom: 0px solid #111;
    }

    div#datatable_filter, lable {
        padding: 0px 0px 0px 0px !important;
    }
    .dataTables_wrapper .dataTables_filter input {
  
        display: none !important;
    }
    
</style>

@endpush
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('adduser')}}" title="@lang('messages.add_ads')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('Add new voter')<div class="ripple-container"></div></a>

                                <a href="{{route('export')}}" title="@lang('messages.add_ads')" class="btn btn-add pull-right"><i class="material-icons">cloud_download</i> @lang('Export All Voters')<div class="ripple-container"></div></a>

                                <h4 class="card-title "><i class="material-icons iconset">person</i> @lang('Voters List')</h4>
                            </div>

                            <div class="card-content table-responsive material-datatables">
                                <table id="datatable" class="table-hover table dataTable dtr-inline">
                                    <thead class="text-primary">
                                        <tr role="row">
                                            <th>Voter ID</th>
                                            <th>@lang('Name')</th>
                                            <th>@lang('House No')</th>
                                            <th>@lang('Mobile')</th>
                                            <?php if($type==1 || $type==3){ ?>
                                            <th>@lang('Rating')</th>
                                            <?php } ?>
                                            <th>@lang('Block')</th>
                                            <th>@lang('Booth')</th>
                                             <th>@lang('Part No')</th>
                                            <th>@lang('messages.status')</th>
                                            <th class="all text-right">Actions</th>
                                        </tr>    
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                </table>                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection

@push('js')
    
    <!-- jQuery Library -->
    <script src="{{ asset('content/assets/jquery/3.3.1/jquery.min.js') }}"></script>

    <!-- Datatable JS -->
    <script src="{{ asset('content/assets/datatables/jquery.dataTables.min.js') }}"></script>
    
    <script type="text/javascript">

        function updateuserStatus(elem){
            var appURL="{{URL::to('/')}}";
            var status = $(elem).attr("data-status");
            var id = $(elem).attr("data-id");	
            $.ajax({
                type: "POST",
                url: appURL+"/admin/users/status",
                data: {id:id,status:status},
                success: function(data){
                    if(data.success!=''){
                        if(status == 1){	
                            $("#atag"+id).html(inactive); 
                            $("#atag"+id).attr("data-status","0");
                            $("#atag"+id).removeClass('btn-success');		
                            $("#atag"+id).addClass('btn-danger');						
                        }

                        if(status == 0){
                            $("#atag"+id).html(active); 
                            $("#atag"+id).attr("data-status","1");
                            $("#atag"+id).removeClass('btn-danger');		
                            $("#atag"+id).addClass('btn-success');
                        }
                    }else if(data.error!=''){
                        alert(data.error);
                    }
                }
            });
        }

        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
			
			$('#datatable thead tr').clone(true).appendTo( '#datatable thead' );
			<?php if($type == 3 || $type== 1){ ?>
			var filterIndexes = [0, 1, 2, 3, 4, 5, 6, 7, 8];
			<?php }else{ ?>
			var filterIndexes = [0, 1, 2, 3, 4, 5, 6, 7];
			<?php } ?>
			$('#datatable thead tr:eq(1) th').each( function (i) {
					
					if ($.inArray(i, filterIndexes) != -1) {				
                        var title = $(this).text();
                        console.error(title);
						$(this).html('<input type="text" class="form-control" placeholder="'+title+'" />');
				 
						$('input', this ).on('keyup change', function () {
							if ( dataTable.column(i).search() !== this.value ) {
								dataTable
									.column(i)
									.search( this.value )
									.draw();
							}
						} );
					}else{
						$(this).html('');
					}
				} 
			);
	        
                
            <?php if($type == 3 || $type== 1){ ?>
            var ColumnObjArray= [
                    { data: 'voter_id_number', name: 'voter_id_number' },
                    { data: 'first_name', name: 'first_name' },
                    { data: 'house_number', name: 'house_number' },
                    { data: 'mobile', name: 'mobile' },
                    { data: 'rating', name: 'rating' },
                    { data: 'block', name: 'block' },
                    { data: 'booth_name', name: 'booth_name' },
                    { data: 'part_number', name: 'part_number' },
                    { data: 'status', name: 'status'},
                    { data: 'action', name: 'action', orderable: false, searchable: false, className:"text-right" }
                ];
            <?php }else{ ?>
            var ColumnObjArray= [
                    { data: 'voter_id_number', name: 'voter_id_number' },
                    { data: 'first_name', name: 'first_name' },
                    { data: 'house_number', name: 'house_number' },
                    { data: 'mobile', name: 'mobile' },
                    { data: 'block', name: 'block' },
                    { data: 'booth_name', name: 'booth_name' },
                    { data: 'part_number', name: 'part_number' },
                    { data: 'status', name: 'status'},
                    { data: 'action', name: 'action', orderable: false, searchable: false, className:"text-right" }
                ];
            <?php } ?>
            var dataTable =  $('#datatable').DataTable({
				orderCellsTop: true,
				fixedHeader: true,
                pagingType: "full_numbers",
                processing: true,
                responsive: true,
                serverSide: true,
                pageLength: 5,
                info: false,
                lengthChange: false,
                order: [[ 0, "desc" ]],
                serverMethod: 'post',
                ajax: "{{route('ajax_get_users',$type)}}",
                initComplete:function(settings,json){
                    console.log(json);                  
                },
                columnDefs: [
                    { orderable: false, targets: -1 },
                    { orderable: false, targets: 7 },
                ],
                
                columns:ColumnObjArray,
                language: {
                    paginate: {
                      "first": false,
                      "previous": "{{ __('messages.Pre') }}",
                      "next": "{{ __('messages.Next') }}",
                      "last": false,
                    },
                    emptyTable: "{{ __('messages.No data available') }}",
                    lengthMenu: "Show _MENU_ entries.",             
                    search: "_INPUT_",
                    searchPlaceholder: "{{ __('messages.Search') }}",
                    zeroRecords: "{{ __('messages.No matching records found') }}",
                    processing: "{{ __('messages.Processing') }}",
                },
            });
        });
    </script>
@endpush    
