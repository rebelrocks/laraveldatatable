@inject('canchk', 'App\Repositories\ChepremissionClassForBlade')
@extends('admin.layouts.app')
@section('title', 'Reported Users')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        @if($canchk->checkPermission(Auth::user()->role_id, 'users', 'is_read') || (Auth::user()->role_id == 4 ))
                        <div class="row">
                            <div class="col-lg-6 col-md-12">
                                <div class="card">
                                <div class="card-header card-header-primary">
                                    <?php 
                                    if($previous != null){
                                    ?>
                                    <a href="{{route('viewuser', $previous)}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('Previous')<div class="ripple-container"></div></a>
                                    <?php
                                    } 
                                    ?>
                                    <h4 class="card-title">@lang('Updated Voter Details')</h4>
                                </div>
                                <div class="card-body table-responsive">
                                    <table class="table table-hover">
                                        <thead class="text-warning">
                                            <th>Title</th>
                                            <th>Details</th>
                                        </thead>
                                        <tbody>
                                            @php $id=1; @endphp
                                            @if($user)
                                            <tr>
                                                <th style="color:#000 !important">Name : </th>
                                                <td>{{ ucwords($user->first_name.' '.$user->last_name)}}</td>
                                            </tr>
                                            <tr>
                                                <th>Email : </th>
                                                <td>{{$user->email}}</td>
                                            </tr>
                                            <tr>
                                                <th>Mobile : </th>
                                                <td>{{$user->mobile}}</td>
                                            </tr>
                                            <tr>
                                                <th>DOB : </th>
                                                <td>{{$user->dob}}</td>
                                            </tr>
                                            <tr>
                                                <th>Gender : </th>
                                                <td>{{$user->gender}}</td>
                                            </tr>
                                            <tr>
                                                <th>House Number : </th>
                                                <td>{{$user->house_number}}</td>
                                            </tr>
                                            <tr>
                                                <th>Lane : </th>
                                                <td>{{$user->lane}}</td>
                                            </tr>
                                            <tr>
                                                <th>City : </th>
                                                <td>{{$user->city}}</td>
                                            </tr>
                                            <tr>
                                                <th>State : </th>
                                                <td>{{$user->state}}</td>
                                            </tr>
                                            <tr>
                                                <th>Address : </th>
                                                <td>{{$user->address}}</td>
                                            </tr>
                                            <tr>
                                                <th>Pin Code : </th>
                                                <td>{{$user->pincode}}</td>
                                            </tr>
                                            <tr>
                                                <th>Block Name : </th>
                                                <td>{{$user->block}}</td>
                                            </tr>
                                            <tr>
                                                <th>Booth Name : </th>
                                                <td>{{$user->booth_name}}</td>
                                            </tr>
                                            <tr>
                                                <th>Sub Area : </th>
                                                <td>{{$user->sub_area}}</td>
                                            </tr>

                                            <tr>
                                                <th>Facebook ID : </th>
                                                <td>{{$user->facebook_url}}</td>
                                            </tr>
                                            <tr>
                                                <th>Twitter ID : </th>
                                                <td>{{$user->twitter_url}}</td>
                                            </tr>
                                            
                                            <tr>
                                                <th>Remarks : </th>
                                                <td>{{$user->remarks}}</td>
                                            </tr>
                                            <tr>
                                                <th>Registed at</th>
                                                <td>
                                                    @if(!empty($user->created_at))
                                                    {{ \Carbon\Carbon::parse($user->created_at)->format('d/m/Y') ?? '-' }}
                                                    @else
                                                    -    
                                                    @endif
                                                </td>
                                            </tr>
                                            
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-12">
                                <div class="card">
                                <div class="card-header card-header-primary">
                                <?php 
                                if($next != null){
                                ?>
                                <a href="{{route('viewuser', $next)}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('Next')<div class="ripple-container"></div></a>
                                <?php 
                                }
                                ?>    
                                <h4 class="card-title">@lang('Original Voter Details')</h4>
                                </div>
                                <div class="card-body table-responsive">
                                    <table class="table table-hover">
                                        <thead class="text-warning">
                                            <th>@lang('Title')</th>
                                            <th>@lang('Details')</th>
                                        </thead>
                                        <tbody>
                                            @php $id=1; @endphp
                                            @if($original_user)
                                            <tr>
                                                <th style="color:#000 !important">Name : </th>
                                                <td>{{ ucwords($original_user->first_name.' '.$original_user->last_name)}}</td>
                                            </tr>
                                            <tr>
                                                <th style="color:#000 !important">Father's/ Husband's Name : </th>
                                                <td>{{ ucwords($original_user->father_or_husband_name)}}</td>
                                            </tr>
                                            <tr>
                                                <th>Email : </th>
                                                <td>{{$original_user->email}}</td>
                                            </tr>
                                            <tr>
                                                <th>Mobile : </th>
                                                <td>{{$original_user->mobile}}</td>
                                            </tr>
                                            <tr>
                                                <th>DOB : </th>
                                                <td>{{$original_user->dob}}</td>
                                            </tr>
                                            <tr>
                                                <th>Gender : </th>
                                                <td>{{$original_user->gender}}</td>
                                            </tr>
                                            <tr>
                                                <th>House Number : </th>
                                                <td>{{$original_user->house_number}}</td>
                                            </tr>
                                            <tr>
                                                <th>Lane : </th>
                                                <td>{{$original_user->lane}}</td>
                                            </tr>
                                            <tr>
                                                <th>City : </th>
                                                <td>{{$original_user->city}}</td>
                                            </tr>
                                            <tr>
                                                <th>State : </th>
                                                <td>{{$original_user->state}}</td>
                                            </tr>
                                            <tr>
                                                <th>Address : </th>
                                                <td>{{$original_user->address}}</td>
                                            </tr>
                                            <tr>
                                                <th>Block Name : </th>
                                                <td>{{$original_user->block}}</td>
                                            </tr>
                                            <tr>
                                                <th>Pin Code : </th>
                                                <td>{{$original_user->pincode}}</td>
                                            </tr>
                                            <tr>
                                                <th>Booth Name : </th>
                                                <td>{{$original_user->booth_name}}</td>
                                            </tr>
                                            <tr>
                                                <th>Sub Area : </th>
                                                <td>{{$original_user->sub_area}}</td>
                                            </tr>

                                            <tr>
                                                <th>Facebook ID : </th>
                                                <td>{{$original_user->facebook_url}}</td>
                                            </tr>
                                            <tr>
                                                <th>Twitter ID : </th>
                                                <td>{{$original_user->twitter_url}}</td>
                                            </tr>
                                            
                                            <tr>
                                                <th>Assembly Constituency : </th>
                                                <td>{{$original_user->assembly_constituency}}</td>
                                            </tr>
                                            <tr>
                                                <th>Voter ID Number : </th>
                                                <td>{{$original_user->voter_id_number}}</td>
                                            </tr>
                                            <tr>
                                                <th>Parliamentary Constituency : </th>
                                                <td>{{$original_user->parliamentary_constituency}}</td>
                                            </tr>
                                            <tr>
                                                <th>Part Number : </th>
                                                <td>{{$original_user->part_number}}</td>
                                            </tr>
                                            <tr>
                                                <th>Part Name : </th>
                                                <td>{{$original_user->part_name}}</td>
                                            </tr>
                                            <tr>
                                                <th>Serial Number : </th>
                                                <td>{{$original_user->serial_number}}</td>
                                            </tr>
                                            <tr>
                                                <th> Polling Station : </th>
                                                <td>{{$original_user->polling_station}}</td>
                                            </tr>
                                            <tr>
                                                <th>Registed at</th>
                                                <td>
                                                    @if(!empty($original_user->created_at))
                                                    {{ \Carbon\Carbon::parse($original_user->created_at)->format('d/m/Y') ?? '-' }}
                                                    @else
                                                    -    
                                                    @endif
                                                </td>
                                            </tr>
                                            
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                            
                        </div>
                        @endif
                        
                    </div>

                    @if($canchk->checkPermission(Auth::user()->role_id, 'activities', 'is_read') || (Auth::user()->role_id >= 4))
                    
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-header card-header-primary">
                            <h4 class="card-title">@lang('User Activities')</h4>
                            <p class="card-category">@lang('New activity List')</p>
                            </div>
                            <div class="card-body table-responsive">
                            <table class="table table-hover" id="example">
                                <thead class="text-warning">
                                    <th>#</th>
                                    <th>@lang('Activity')</th>
                                    <th>@lang('Performed By')</th>
                                    <th>@lang('Role')</th>
                                    <th>@lang('messages.created')</th>
                                </thead>
                                <tbody>
                                    @php $id=1; @endphp
                                    @forelse($activities as $activity)
                                    <tr>
                                        <td>{{$id}}</td>
                                        <td><b>{{ ucwords($activity->activities)}}</b></td>
                                        <td>{{ ucwords($activity->first_name.' '.$activity->last_name)}}</td>
                                        <td>{{ ucwords($activity->name)}}</td>
                                        <td>
                                        @if(!empty($activity->created_at))
                                        {{ \Carbon\Carbon::parse($activity->created_at)->format('d/m/Y H:i:s') ?? '-' }}
                                        @else
                                        -    
                                        @endif
                                        </td>
                                    </tr>
                                    @php $id++; @endphp
                                    @empty
                                    <tr>
                                        <td colspan="4" class="text-center">@lang('NO Activity Available...')</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
		
@endsection

@push('js')
<!-- DataTables CSS -->

<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.css">

<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/tabletools/2.2.2/css/dataTables.tableTools.css">



<script type="text/javascript" charset="utf8" src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.js"></script>

<script type="text/javascript" charset="utf8" src="http://cdn.datatables.net/tabletools/2.2.2/js/dataTables.tableTools.min.js"></script>
<script>

$(document).ready( function () {
    $('#example').dataTable( {
        "dom": 'T<"clear">lfrtip',
        "tableTools": {
            "sSwfPath": "http://cdn.datatables.net/tabletools/2.2.2/swf/copy_csv_xls_pdf.swf"
        }
    } );
} );
</script>
@endpush