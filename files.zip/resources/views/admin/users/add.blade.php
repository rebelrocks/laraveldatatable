@extends('admin.layouts.app')
@section('title', trans('messages.create_new_user'))
@push('css')
<!-- <link rel="stylesheet" href="{{ asset('content/assets/back-end/css/demo.css') }}">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"> -->

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style>
    @media(max-width:3840px){
        .mainbigimg{
            width:19%;
        }
    }

    @media(max-width:1920px){
        .mainbigimg{
            width:43.2%;
        }
    }

    @media(max-width:1441px){
        .mainbigimg{
            width:62.5%;
        }
    }

    @media(max-width:1366px){
        .mainbigimg{
            width:67.5%;
        }
    }

    @media(max-width:1112px){
        .mainbigimg {
            width: 75%;
        }
        .smallmain-img{
            width: 66px !important;
            height: 82px !important;
            min-height: 70px !important;
        }
        .main-img{
            width: 140px !important;
            height: 175px !important;
        }
    }

    @media(max-width:1024px){
        .mainbigimg {
            width: 75%;
        }
        .smallmain-img{
            width: 55px !important;
            height: 70px !important;
            min-height: 70px !important;
        }
        .main-img{
            width: 120px !important;
            height: 150px !important;
        }
    }

</style>

<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }

    #map {
        width: 100%;
        height: 295px;
        margin-top:10px;
    }

    #address{
        z-index: 999;
        position: relative;
        left: 0px !important;
        top: 0px;
        width: 100% !important;
        border: 1px solid #ccc;
        background: #fff;
        padding:4px;
    }

    .gmnoprint{
        margin-top: 33px !important;
    }

    #spingif{
        display:none;
    }
	
	.form-group input[type=fileeee] {
		opacity: 1 !important;
		position: inherit !important;
		top: 0px;
		right: 0;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 100;
	}
	
	#ui-datepicker-div{
		z-index : 9999999 !important;	
	}
		
	.col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
        float: left;
    }
	
	.card .tab-content .form-check {
		margin: 27px 0 0;
	}
	
	.card img {
		width: 100%;
		height: 100%;
		object-fit: cover;
	}
	
	.form-group input[type=file]{
            z-index: 0;
        }

	.custom-file-upload {
		background: #737373 none repeat scroll 0 0;     
		cursor: pointer;
		display: inline-block;
		padding: 6px 12px;
	}

	.fileinput .thumbnail {
		display: inline-block;
		margin-bottom: 5px;
		overflow: hidden;
		text-align: center;
		vertical-align: middle;
	}

	.thumbnail {
		padding: 4px;
		line-height: 1.42857;
		_background-color: #fff;
		_border: 1px solid #ddd;
		_border-radius: 4px;
		-webkit-transition: border .2s ease-in-out;
		-o-transition: border .2s ease-in-out;
		transition: border .2s ease-in-out;
	}

	.featured_image{
		line-height: 0px !important;
	}
    .select2-container--default .select2-selection--multiple {
        background-color: white;
        border: 0px solid #aaa !important;
        border-bottom: 1px solid #aaa !important;
        border-radius: 0px;
        cursor: text;
        padding-bottom: 5px;
        padding-right: 5px;
        position: relative;
    }
    
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/bootstrap-fileinput/bootstrap-fileinput.css') }}" />
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                    <!-- alert messages -->
                    @include('admin.layouts.flash-message')
                    <?php
                   
                    ?>
                    <!-- End alert messages -->
                    </div> 
					<div class="col-md-12 row">	
                        <div class="col-md-9">
							
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <a href="{{route('users')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                    <h4 class="card-title">@lang('Add New Voter')</h4>
                                </div>
                                <div class="card-body">  
									<form method="post" action="{{route('storeuser')}}" enctype="multipart/form-data" id="UserAddForm">
									@csrf
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="">@lang('messages.first_name')</label>
                                                <input type="text" class="form-control" name="first_name" value="{{old('first_name')}}" required>
                                                @error('first_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="">@lang('messages.last_name')</label>
                                                <input type="text" class="form-control" name="last_name" value="{{old('last_name')}}">
                                                @error('last_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="">@lang('messages.email')</label>
                                                <input type="email" id="UserEmailID" class="form-control" name="email" value="{{old('email')}}">
                                                @error('email')
                                                    <span class="error ui red pointing label transition">
                                                        <strong style="width: auto;">{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="">@lang('messages.telephone')</label>
                                                <input type="text" class="form-control" name="mobile" value="{{old('mobile')}}" required>
                                                @error('mobile')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
									
                                    </div>
									
                                    <div class="row">
                                        
                                        <div class="col-md-4">
                                            <div class="form-group bmd-form-group is-filled">
                                                <label class="">@lang('DOB')</label>
                                                <input type="text" id="expired_at" class="form-control" name="dob" value="{{old('dob')}}" readonly style="background-color: transparent;">
                                                @error('dob')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="">@lang('House Number')</label>
                                                <input type="text" class="form-control" name="house_number" value="{{old('house_number')}}">
                                                @error('house_number')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="">@lang('Lane')</label>
                                                <input type="text" class="form-control" name="lane" value="{{old('lane')}}">
                                                @error('lane')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                       		
                                    </div>

                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="">@lang('City')</label>
                                                <input type="text" class="form-control" name="city" value="{{old('city')}}">
                                                @error('city')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group bmd-form-group is-filled">
                                                <label class="">@lang('State')</label>
                                                <input type="text" id="" class="form-control" name="state" value="{{old('state')}}">
                                                @error('state')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="">@lang('Facebook id')</label>
                                                <input type="url" class="form-control" name="facebook_url" value="{{old('facebook_url')}}">
                                                @error('facebook_url')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="">@lang('Twitter id')</label>
                                                <input type="url" class="form-control" name="twitter_url" value="{{old('twitter_url')}}">
                                                @error('twitter_url')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                       		
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="">@lang('Block Name')</label>
                                                <input type="text" class="form-control" name="block" value="{{old('block')}}">
                                                @error('block')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group bmd-form-group is-filled">
                                                <label class="">@lang('Booth Name')</label>
                                                <input type="text" id="" class="form-control" name="booth_name" value="{{old('booth_name')}}">
                                                @error('booth_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="">@lang('Sub Area')</label>
                                                <input type="text" class="form-control" name="sub_area" value="{{old('sub_area')}}">
                                                @error('sub_area')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                       		
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="">@lang('Address')</label>
                                                <textarea class="form-control" name="address">{{old('address')}}</textarea>
                                                @error('address')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="">@lang('Remarks')</label>
                                                <textarea class="form-control" name="remark">{{old('remark')}}</textarea>
                                                @error('remark')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                       		
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="">@lang('Rate')</label>
                                                <input type="number" maxlength="10" class="form-control" name="rating" value="{{old('rating')}}" required>
                                                @error('rating')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
										<div class="col-md-3">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status') ? 'checked' : 'checked' }} checked> @lang('messages.status')
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
                                        <div class="col-md-3">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
                                                <input class="form-check-input" type="checkbox" name="is_approved" value="1" > @lang('Approved') 
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
									</div>

                                    <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
							
                        </div>

                        <div class="col-md-3">
                            <div class="card">                                
                                <div class="card-body">
									<div class="row">
										<div class="col-md-12 ml-auto mr-auto text-center">
											<h4 class="card-title" style="font-size: 15px;">
												@lang('messages.Images de profil')
											</h4>
										</div>
									</div>
								   <div class="row" style="margin-left: -30px;">
                                        
										@php $count = 1; @endphp	
										@for($i=1; $i<=$count;$i++)
										<div class="col-md-12">
											<div class="fileinput fileinput-new" data-provides="fileinput">
												<div class="fileinput-new thumbnail" style="width: 200px; height: 200px;min-height: 80px;max-height: 200px;">
													<img src="{{asset('content/img/image-placeholder.png')}}" alt="">
												</div>
												<div class="fileinput-preview fileinput-exists thumbnail" style="width: 200px; height: 200px;min-height: 80px;max-height: 200px;"> </div>
												<div>
													<span class="btn btn-primary custom-file-upload default btn-file">
														<span class="fileinput-new"><i class="fa fa-upload"></i> @lang('messages.select_image') </span>
														<span class="fileinput-exists"><i class="fa fa-upload"></i> @lang('messages.edit_image') </span>
														<input type="file" name="gallery_picture[]" accept="image/*">
													</span>
														<a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"><i class="fa fa-trash"></i> @lang('messages.remove') </a>
												</div>
											</div>
										</div>
										@endfor
										
										<div class="clearfix"></div>
										<div class="col-md-12">
											@error('gallery_picture')
												<span class="invalid-feedback" role="alert">
													<strong>{{ $message }}</strong>
												</span>
											@endif
											@error('gallery_picture.*')
												<span class="invalid-feedback" role="alert">
													<strong>{{ $message }}</strong>
												</span>
											@endif 
										</div>
									</div>
                                   
                            </div>
                        </div>

                    </form>
                    </div> 
                </div>
            </div>
        </div>
@endsection

@push('js')
    
    <script src="{{ asset('content/assets/back-end/bootstrap-fileinput/bootstrap-fileinput.js') }}"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>    
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/semantic-ui/2.1.4/semantic.min.css" />
    <!--  Google Maps Plugin    -->
    <script type="text/javascript">

        function in_array(needle, haystack) {
            for (var i=0, j=haystack.length; i < j; i++) {
                if (needle == haystack[i])
                    return true;
            }
            return false;
        }

        function getExt(filename) {
            var dot_pos = filename.lastIndexOf(".");
            if(dot_pos == -1)
                return "";
            return filename.substr(dot_pos+1).toLowerCase();
        }

        function eventreadURL(input,event_img_no) {
                
            switch (event_img_no) {
                case "user_img_1":      
                    var filename = document.getElementById("user-images-1").value;
                break;
                case "user_img_2":      
                    var filename = document.getElementById("user-images-2").value;
                break;
                case "user_img_3":      
                    var filename = document.getElementById("user-images-3").value;
                break;
                case "user_img_4":      
                    var filename = document.getElementById("user-images-4").value;
                break;
                case "user_img_5":      
                    var filename = document.getElementById("user-images-5").value;
                break;
                case "user_img_6":      
                    var filename = document.getElementById("user-images-6").value;
                break;      
            }
            
            var filetype = ['jpeg', 'png', 'jpg', 'gif'];
            if(filename !=''){
                var ext = getExt(filename);
                ext = ext.toLowerCase();
                var checktype = in_array(ext, filetype);
                if(!checktype){
                    alert(ext+" file not allowed for event.");
                    return false;
                }else{
                    if (input.files && input.files[0]) {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                            $('#'+event_img_no).attr('src', e.target.result);
                            $("#del_"+event_img_no).show();
                        };
                        reader.readAsDataURL(input.files[0]);
                    }
                }   
            }
        }

        function changePictureFunc(event_img_no){   
            $('#'+event_img_no).attr('src', '{{ asset("content/img/default_user_image.png") }}'); 
            $("#del_"+event_img_no).hide();
        }
    </script>

    <script type="text/javascript">

		function dismissimg(img_type,gallery_id)
		{
			switch(img_type) {
			  case "gallery_picture":
				if($("#" + gallery_id).length != 0) {
				  $("#" + gallery_id).val(gallery_id);
				}
				break;			  		  
			}				
		}
	</script>
	
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <!-- Language script -->
    <!-- <script type="text/javascript" src="{{ asset('content/assets/back-end/jquery-ui-master/ui/i18n/datepicker-fr.js') }}"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js"></script>
    <style>
        .ui.red.label, .ui.red.labels .label {
            background-color: white !important;
            border-color: #000!important;
            color: #000 !important;
            border: 1px solid !important;
        }
        .ui.pointing.label:before, .ui[class*="pointing above"].label:before {
            top: -2px !important;
            left: 15px !important;
        }
    </style>
    <script>
        $(document).ready(function(){
            $('.select2').select2({
                language: "fr"
            });

            setTimeout(function() {
                $('.ui.red.label, .ui.red.labels').fadeOut('fast');
            }, 2000);
            $('#UserEmailID').change(function(){
                $('#UserAddForm').validate({
                    rules: {
                    email: {email:true, required: true},
                    user_type: { required: true}
                    },
                    messages: {
                    email: '<i class="fa fa-exclamation-circle" style="font-size:15px;color:#fcba03;"></i> Merci de bien vouloir ajouter un email valide.',
                    user_type:'Choisissez le type d\'utilisateur',
                    },
                    errorPlacement: function ( error, element ) {
                        error.addClass( "ui red pointing label transition" );
                        error.insertAfter( element.parent() );
                    },
                    highlight: function ( element, errorClass, validClass ) {
                        $( element ).parents( ".row" ).addClass( errorClass );
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $( element ).parents( ".row" ).removeClass( errorClass );
                    }
                });
            });
        });
        $(function() {
            var today = new Date();
            var lastDate = '<?php echo date('Y-m-d',strtotime('-18 years',time()));?>';

            $('#expired_at').val('<?php echo date('d-m-Y',strtotime('-18 years',time()));?>');

            $("#expired_at").datepicker({
               
                dateFormat: "dd-mm-yy",
                changeYear: true,
                changeMonth: true,
                yearRange: '1900:2021',
                maxDate: lastDate, 
            });

            // Initialize and change language to France
            $('#expired_at').datepicker();
        });
    </script>
@endpush
