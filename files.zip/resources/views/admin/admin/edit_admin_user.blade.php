@extends('admin.layouts.app')
@section('title', trans('messages.edit'))
@inject('can', 'App\Repositories\ChepremissionClassForBlade')

@push('css')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }

    .select2-container--default .select2-selection--multiple {
        background-color: white;
        border: 0px solid #aaa !important;
        border-bottom: 1px solid #aaa !important;
        border-radius: 0px;
        cursor: text;
        padding-bottom: 5px;
        padding-right: 5px;
        position: relative;
    }
</style>
@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <a href="{{route('admin_users')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                    <h4 class="card-title">{{ __('messages.edit')}}</h4>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="{{route('edit_admin_user', $user->id)}}">
                                        @method('PUT')
                                        @csrf
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class=" ">{{ __('messages.first_name') }}</label>
                                                    <input type="text" name="first_name" value="{{old('first_name', $user->first_name) }}" class="form-control" maxlength="191" required="required" autofocus >
                                                    @error('first_name')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class=" ">{{ __('messages.last_name') }}</label>
                                                    <input type="text" name="last_name" value="{{old('last_name', $user->last_name) }}" class="form-control" maxlength="191" required="required" >
                                                    @error('last_name')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class=" ">{{ __('messages.email') }}</label>
                                                    <input type="email" name="email" value="{{old('email', $user->email) }}" class="form-control" maxlength="191" required="required" readonly>
                                                    @error('email')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class=" ">{{ __('messages.password') }}</label>
                                                    <input type="text" name="password" value="{{old('password') }}" class="form-control" >
                                                    @error('password')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <?php 
                                        $AuthUser=\Auth::user()->role_id;
                                        $userRoles=[];
                                        if($AuthUser == 4){
                                            $userRoles=[4,13,14,15,16];
                                        }
                                        if($AuthUser == 13){
                                            $userRoles=[14,15,16]; 
                                        }
                                        if($AuthUser == 14){
                                            $userRoles=[15,16]; 
                                        }
                                        if($AuthUser == 15){
                                            $userRoles=[16]; 
                                        }
                                        ?>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group label-floating">
                                                    <label class=" ">{{ __('messages.roles') }}</label>
                                                    <select class="form-control" name="role" required="required">
                                                    <option value="">--@lang('messages.selectrole')--</option>
                                                    @foreach($roles as $role)
                                                    <?php if(in_array($role->id,$userRoles)){ ?>
                                                    <option {{ old('role', $user->role_id) == $role->id ? 'selected' : '' }} value="{{$role->id}}">{{$role->name}}</option>
                                                    <?php } ?>
                                                    @endforeach
                                                </select>
                                                    @error('email')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <?php
                                                $blocks=explode(',',$user->block_id);
                                                $booths=explode(',',$user->booth_id);
                                                $booth_member_ids=explode(',',$user->booth_member_ids);
                                                $block_member_ids=explode(',',$user->block_member_ids);
                                                $pincodes=explode(',',$user->pincode);
                                            ?>
                                            @if($can->checkPermission(Auth::user()->role_id, 'block', 'is_read'))
                                            <div class="col-md-4 mt-2">
                                                <div class="form-group label-floating is-empty">
                                                    <label for="block" class="">@lang('Select Blocks')</label>
                                                    <select multiple name="block[]" class="form-control select2" onchange="" id="block_input">
                                                    <?php
                                                    if(count($block_categories) > 0){
                                                        foreach($block_categories as $category){
                                                        ?>
                                                        <option value="{{ $category->block }}" <?php if(in_array($category->block,$blocks)){ echo 'selected'; }?>>{{ $category->block}}</option>
                                                        <?php
                                                        }
                                                    } ?>
                                                    </select>
                                                    
                                                </div>
                                            </div>
                                            @endif
                                            @if($can->checkPermission(Auth::user()->role_id, 'booth', 'is_read'))
                                            <div class="col-md-5 mt-2">
                                                <div class="form-group label-floating is-empty">
                                                    <label for="booth" class="">@lang('Select Booths')</label>
                                                    <select multiple name="booth_name[]" class="form-control select2" onchange="" id="booth_name_input">
                                                    <?php
                                                    if(count($booth_categories) > 0){
                                                        foreach($booth_categories as $boothcategory){
                                                        ?>
                                                        <option value="{{ $boothcategory->booth_name }}" <?php if(in_array($boothcategory->booth_name,$booths)){ echo 'selected'; }?>>{{ $boothcategory->booth_name}}</option>
                                                        <?php
                                                        }
                                                    } ?>
                                                    </select>
                                                    
                                                </div>
                                            </div>
                                            @endif
                                        </div> 


                                        <div class="row">
                                            @if($can->checkPermission(Auth::user()->role_id, 'block', 'is_read'))
                                            <div class="col-md-4">
                                                <div class="form-group label-floating is-empty">
                                                    <label for="block" class="">@lang('Assign Block Members')</label>
                                                    <select multiple name="block_members[]" class="form-control select2" onchange="" id="block_members">
                                                    <?php
                                                    if(count($block_members) > 0){
                                                        foreach($block_members as $block_member){
                                                        ?>
                                                        <option value="{{ $block_member->id }}" <?php if(in_array($block_member->id,$block_member_ids)){ echo 'selected'; }?>>{{ $block_member->first_name.' | '.$block_member->email}}</option>
                                                        <?php
                                                        }
                                                    } ?>
                                                    </select>
                                                    
                                                </div>
                                            </div>
                                            @endif
                                            @if($can->checkPermission(Auth::user()->role_id, 'booth', 'is_read'))
                                            <div class="col-md-4">
                                                <div class="form-group label-floating is-empty">
                                                    <label for="booth" class="">@lang('Assign Booth members')</label>
                                                    <select multiple name="booth_members[]" class="form-control select2" onchange="" id="booth_members">
                                                    <?php
                                                    if(count($booth_members) > 0){
                                                        foreach($booth_members as $booth_member){
                                                        ?>
                                                        <option value="{{ $booth_member->id }}" <?php if(in_array($booth_member->id,$booth_member_ids)){ echo 'selected'; }?>>{{ $booth_member->first_name.' | '.$booth_member->email}}</option>
                                                        <?php
                                                        }
                                                    } ?>
                                                    </select>
                                                    
                                                </div>
                                            </div>
                                            @endif

                                            <div class="col-md-4">
                                                <div class="form-group label-floating is-empty">
                                                    <label for="booth" class="">@lang('Assign Pin codes')</label>
                                                    <select multiple name="pin_codes[]" class="form-control select2" onchange="" id="pin_codes">
                                                    <?php
                                                    if(count($pin_codes) > 0){
                                                        foreach($pin_codes as $pin_code){
                                                        ?>
                                                        <option value="{{ $pin_code->pincode }}" <?php if(in_array($pin_code->pincode,$pincodes)){ echo 'selected'; }?>>{{ $pin_code->pincode}}</option>
                                                        <?php
                                                        }
                                                    } ?>
                                                    </select>
                                                    
                                                </div>
                                            </div>


                                        </div> 

                                        <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
                                        
@push('js')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$('.select2').select2({
    placeholder: "----Select-----",
    allowClear: true 
});
</script>

@endpush
