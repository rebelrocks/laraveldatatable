@extends('admin.layouts.app')
@section('title', trans('messages.users'))
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('create_new_admin_user')}}" title="@lang('messages.add_new_user')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_new_user')<div class="ripple-container"></div></a>
                                <h4 class="card-title"><i class="material-icons iconset">person</i> @lang('messages.users')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <tr role="row">
                                                <th>{{ __('messages.name') }}</th>
                                                <th>{{ __('messages.email') }}</th>
                                                <th>{{ __('messages.user_type') }}</th>
                                                <th class="text-right">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($users as $user)
                                            <tr>
                                                <td>{{ $user->first_name }} {{$user->last_name}}</td>
                                                <td>{{ $user->email }}</td>
                                                <td><span class="btn btn-success">{{ $user->userrole->name ?? '' }}</span></td>
                                                <td class="text-right">
                                                    <a href="{{route('edit_admin_user', $user->id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                     @if($user->role_id != 4)
                                                    <a href="{{route('delete_admin_user', $user->id)}}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a>
                                                    @endif
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                    <div class="pull-right"> {{ $users->links() }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
