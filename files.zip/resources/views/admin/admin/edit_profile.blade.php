@extends('admin.layouts.app')
@section('title', trans('messages.edit_profile'))
@push('css')
<style type="text/css">
    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title">@lang('messages.edit_profile')</h4>
                            </div>
                            <div class="card-body">
                                <form method="post" action="{{route('admin.edit_profile')}}" enctype="multipart/form-data">
                                    @method('PUT')
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">@lang('messages.first_name')</label>
                                                <input type="text" class="form-control" name="first_name" value="{{old('first_name', auth::user()->first_name ?? '')}}" required="required" autofocus>
                                                @error('first_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">@lang('messages.name')</label>
                                                <input type="text" class="form-control" name="last_name" value="{{old('last_name', auth::user()->last_name ?? '')}}">
                                                @error('last_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">@lang('messages.email')</label>
                                                <input type="email" class="form-control" name="email" value="{{old('email', auth::user()->email ?? '')}}" required="required" readonly>
                                                @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    {{--
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">@lang('messages.password')</label>
                                                <input type="password" class="form-control" name="password">
                                                @error('password')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    --}}
                                    <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
@endsection

