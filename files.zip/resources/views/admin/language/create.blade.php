@extends('admin.layouts.app')
@section('title', trans('messages.add_language'))
@push('css')
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <a href="{{route('languages')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                    <h4 class="card-title">@lang('messages.add_language')</h4>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="{{route('addlanguagecode')}}">
                                        @csrf

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="bmd-label-floating">@lang('messages.name')</label>
                                                    <input type="text" name="name" value="{{old('name') }}" class="form-control" maxlength="255" id="name" required="required" autofocus >
                                                    @error('name')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group bmd-form-group is-filled">
                                                    <label class="bmd-label-floating">@lang('messages.code')</label>
                                                    <select class="form-control" name="code" required="required">
                                                        <option value="">--Select code--</option>
                                                        @foreach($codelists as $key => $value)
                                                        <option value="{{$key}}" {{ old('code') == $key ? 'selected' : '' }}>{{ $value }}</option>
                                                        @endforeach
                                                    </select>
                                                    @error('code')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                     
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        <input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status') ? 'checked' : '' }}> @lang('messages.status')
                                                        <span class="form-check-sign">
                                                            <span class="check"></span>
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
