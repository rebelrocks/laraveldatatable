@extends('admin.layouts.app')
@section('title', trans('messages.language'))
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('addlanguagecode')}}" title="@lang('messages.add_language')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_language')<div class="ripple-container"></div></a>
                                <h4 class="card-title"><i class="material-icons iconset">language</i> @lang('messages.language')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>@lang('messages.title')</th>
                                            <th>@lang('messages.code')</th>
                                            <th>@lang('messages.status')</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
											<!--tr>
												<td>
													<form action=" method="POST">
														@method('PUT')
														
														@csrf
														<input type="hidden" name="new_local" id="new_local" value="{{old('local', str_replace('_', '-', app()->getLocale())) }}" />
														<div class="row">
															<div class="col-md-6">
																<select class="form-control" id="languagecode" name="default_language">
																	@foreach($languages as $row)
																	<option value="{{$row->id}}" data-val="{{ $row->code }}" {{ old('default_language', $defaultlanguage->id ?? '') == $row->id ? 'selected' : '' }}>{{$row->name}}</option>
																	@endforeach
																</select>
															</div>
															<div class="col-md-6">
																<button type="submit" class="btn btn-sm btn-primary pull-right">{{ __('Set default language') }}<div class="ripple-container"></div></button>
															</div>
														</div>		
													</form>
												</td>
											</tr-->
											@forelse($languagecodes as $languagecode)
                                            <tr>
                                                <td>{{$languagecode->name}}</td>
                                                <td>{{$languagecode->code}}</td>
                                                <td>
                                                    <a id="atag{{$languagecode->id}}"  class="btn btn-{{ $languagecode->status == 1 ? 'success' : 'danger' }}" data-id="{{$languagecode->id}}" data-status="{{$languagecode->status}}" href="javascript:void(0)" onclick="updateadlanguageStatus(this)">
                                                        {{ $languagecode->status == 1 ? __('messages.statusactive') : __('messages.statusinactive') }}
                                                    </a>
                                                </td>
                                                <td class="text-right">
                                                    @if($languagecode->is_default)
                                                        <a class="btn btn-{{ $languagecode->is_default == 1 ? 'success' : 'danger' }}" href="javascript:void(0)"><i class="material-icons">star</i> {{ $languagecode->is_default == 1 ? __('messages.set_detault_language') : __('messages.set_detault_language') }}
                                                        </a>
                                                    @else
                                                       <a class="btn btn-{{ $languagecode->is_default == 1 ? 'success' : 'danger' }}" href="{{ route('set_default_language', ['new_local' => $languagecode->code, 'default_language' => $languagecode->id]) }}"><i class="material-icons">star</i> {{ $languagecode->is_default == 1 ? __('messages.set_detault_language') : __('messages.set_detault_language') }}
                                                        </a> 
                                                    @endif

                                                    <a href="{{route('editlanguagecode', $languagecode->id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                    <a href="{{ route('delete_language_code', $languagecode->id) }}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection

@push('js')
	<script>
		// JavaScript using jQuery
		$(function(){
			$('#languagecode').change(function(){
			   var selected = $(this).find('option:selected');
			   var extra = selected.data('val'); 
			   $("#new_local").val(extra);
			});
		});
	</script>

@endpush
