@extends('admin.layouts.app')
@section('title', 'Site Permissions')
@push('css')
    <style type="text/css">
        a img.spingif{
            width: 25px;
            position: absolute;
            z-index: 99999999;
            top: 161px;
            left: 264px;
        }
    </style>
@endpush
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('roles')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                <h4 class="card-title ">
									<i class="material-icons iconset">build</i> 
									{{ $current_role ? 'Autorisation '.$current_role : __('messages.site_permissions') }}	
								</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>@lang('messages.permission_for')</th>
                                            <th>@lang('messages.is_read')</th>
                                            <th>@lang('messages.is_add')</th>
                                            <th>@lang('messages.is_edit')</th>
                                            <th>@lang('messages.is_delete')</th>
                                        </thead>
                                        <tbody>
											@if(count($sitepermissions))
                                            <tr>
												<td colspan="1">&nbsp;</td>
												<td>
													<a href="{{ route('admin.updateallsitepermissionstatus', ['status' => 'is_read', 'role_id' => $id]) }}" class="btn btn-primary">{{ __('messages.all_status') }}<div class="ripple-container"></div></a>
												</td>
												<td>
													<a href="{{ route('admin.updateallsitepermissionstatus', ['status' => 'is_add', 'role_id' => $id]) }}" class="btn btn-primary">{{ __('messages.all_status') }}<div class="ripple-container"></div></a>
												</td>
												<td>
													<a href="{{ route('admin.updateallsitepermissionstatus', ['status' => 'is_edit', 'role_id' => $id]) }}" class="btn btn-primary">{{ __('messages.all_status') }}<div class="ripple-container"></div></a>
												</td>
												<td>
													<a href="{{ route('admin.updateallsitepermissionstatus', ['status' => 'is_delete', 'role_id' => $id]) }}" class="btn btn-primary">{{ __('messages.all_status') }}<div class="ripple-container"></div></a>
												</td>
											</tr>
											@endif
                                            @forelse($sitepermissions as $permission)
                                            <tr>
                                                <td>
                                                    <span style="width: 181px;">
                                                        {{ ucfirst(trim($permission->manager->slug)) }}
                                                    </span>
                                                </td>

                                                <td class="is_read site_permission_status_1_{{ $permission->id}}">
                                                    <a href="javascript:void(0)" onclick="updatesitepermissions(<?php echo $id;?>, <?php echo $permission->id; ?>, 1,  <?php echo $permission->is_read ? '1' : '0'; ?>)">
                                                        <span class="btn btn-sm btn-{{ $permission->is_read == 1 ? 'success' : 'danger' }}">{{ $permission->is_read == 1 ? __('messages.yes') : __('messages.no') }}</span>
                                                    </a>
                                                </td>

                                                <td class="is_add site_permission_status_2_{{ $permission->id}}">

                                                    <a href="javascript:void(0)" onclick="updatesitepermissions(<?php echo $id;?>, <?php echo $permission->id; ?>, 2,  <?php echo $permission->is_add ? '1' : '0'; ?>)">
                                                        <span class="btn btn-sm btn-{{ $permission->is_add == 1 ? 'success' : 'danger' }}">{{ $permission->is_add == 1 ? __('messages.yes') : __('messages.no') }}</span>
                                                    </a>

                                                </td>

                                                <td class="is_edit site_permission_status_3_{{ $permission->id}}">
                                                    <a href="javascript:void(0)" onclick="updatesitepermissions(<?php echo $id;?>, <?php echo $permission->id; ?>, 3,  <?php echo $permission->is_edit ? '1' : '0'; ?>)">
                                                        <span class="btn btn-sm btn-{{ $permission->is_edit == 1 ? 'success' : 'danger' }}">{{ $permission->is_edit == 1 ? __('messages.yes') : __('messages.no') }}</span>
                                                    </a>
                                                </td>

                                                <td class="is_delete site_permission_status_4_{{ $permission->id}}">
                                                    <a href="javascript:void(0)" onclick="updatesitepermissions(<?php echo $id;?>, <?php echo $permission->id; ?>, 4,  <?php echo $permission->is_delete ? '1' : '0'; ?>)">
                                                        <span class="btn btn-sm btn-{{ $permission->is_delete == 1 ? 'success' : 'danger' }}">{{ $permission->is_delete == 1 ? __('messages.yes') : __('messages.no') }}</span>
                                                    </a>
                                                </td>

                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="7" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                    <div class="pull-right"> {{ $sitepermissions->links() }} </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection

@push('js')
    
    <script type="text/javascript">

        //Generate csrf token for ajax request
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        /**
         * update site permission status
         */
        function updatesitepermissions(role_id, site_permission_id, status, current_status)
        {
            var role_id = role_id;
            var site_permission_id = site_permission_id;
            var status = status;
            var current_status = current_status;
            //$(".site_permission_status_"+status+"_"+site_permission_id+ "img.spingif").show();
            $.ajax({
                type: 'post',
                data: {role_id:role_id,site_permission_id:site_permission_id,status:status,current_status:current_status},
                url: "{{route('site_permissionstatus')}}",
                success: function(response){
                    $(".site_permission_status_"+status+"_"+site_permission_id).html(response.is_read);
                }

            });
        }

        /**
         * update site permission status
         */
        function updatestatus(site_permission_id)
        {
            var site_permission_id = site_permission_id;
            $.ajax({
                type: 'post',
                data: {site_permission_id:site_permission_id},
                url: "{{route('site_permission_status')}}",
                success: function(response){
                    $(".permission_status_"+site_permission_id).html(response.is_read);
                }

            });
        }
		
		/**
         * update all permission status
         */
        function updateallstatus(site_permission_id)
        {
            var site_permission_id = site_permission_id;
            $.ajax({
                type: 'post',
                data: {site_permission_id:site_permission_id},
                url: "{{route('site_permission_status')}}",
                success: function(response){
                    $(".permission_status_"+site_permission_id).html(response.is_read);
                }

            });
        }

    </script>
@endpush
