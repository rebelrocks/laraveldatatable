@extends('admin.layouts.app')
@section('title', 'Add Site Permission')
@push('css')
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('sitepermissions', $id)}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                <h4 class="card-title">@lang('messages.add_site_permission')</h4>
                            </div>
                            <div class="card-body">
                                <form method="post" action="{{route('add_site_permissions', $id)}}">
                                    @csrf
                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">@lang('messages.role')</label>
                                                <select class="form-control" name="role" required="required">
                                                    <option value="">--@lang('messages.selectrole')--</option>
                                                    @foreach($roles as $role)
                                                    <option {{ old('role') == $role->id ? 'selected' : '' }} value="{{$role->id}}">{{$role->name}}</option>
                                                    @endforeach
                                                </select>

                                                @error('role')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">@lang('messages.manager')</label>
                                                <select class="form-control" name="manager" required="required">
                                                    <option value="">--@lang('messages.selectmanager')--</option>
                                                    @foreach($managers as $manager)
                                                    <option {{ old('manager') == $manager->id ? 'selected' : '' }} value="{{$manager->id}}">{{$manager->name}}</option>
                                                    @endforeach
                                                </select>

                                                @error('manager')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-sm-2 checkbox-radios">
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="read" value="1" {{ old('read') ? 'checked' : '' }}> {{ __('messages.view_data') }}
                                                    <span class="form-check-sign">
                                                        <span class="check"></span>
                                                    </span>
                                                </label>
                                            </div>

                                            @error('read')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror

                                        </div>

                                        <div class="col-sm-2 checkbox-radios">   
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="add" value="1" {{ old('add') ? 'checked' : '' }}> {{ __('messages.add_data') }}
                                                    <span class="form-check-sign">
                                                        <span class="check"></span>
                                                    </span>
                                                </label>
                                            </div>
                                            @error('add')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-sm-2 checkbox-radios">    
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="edit" value="1" {{ old('edit') ? 'checked' : '' }}> {{ __('messages.edit_data') }}
                                                    <span class="form-check-sign">
                                                        <span class="check"></span>
                                                    </span>
                                                </label>
                                            </div>
                                            @error('edit')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        
                                        <div class="col-sm-2 checkbox-radios">    
                                            <div class="form-check form-check-inline">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="delete" value="1" {{ old('delete') ? 'checked' : '' }}> {{ __('messages.delete_data') }}
                                                    <span class="form-check-sign">
                                                        <span class="check"></span>
                                                    </span>
                                                </label>
                                            </div>
                                            @error('delete')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>    
                                    </div>

                                    <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
