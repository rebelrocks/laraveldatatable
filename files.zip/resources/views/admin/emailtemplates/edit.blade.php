@extends('admin.layouts.app')
    @section('title',trans('messages.edit_email_template'))
    @push('css')

    <style type="text/css">

        .invalid-feedback{
            display: block !important;
        }

        .form-group input[type=file]{
            z-index: 0;
        }

        .custom-file-upload {
            background: #737373 none repeat scroll 0 0;     
            cursor: pointer;
            display: inline-block;
            padding: 6px 12px;
        }

        .fileinput .thumbnail {
            display: inline-block;
            margin-bottom: 5px;
            overflow: hidden;
            text-align: center;
            vertical-align: middle;
        }

        .thumbnail {
            padding: 4px;
            line-height: 1.42857;
            _background-color: #fff;
            _border: 1px solid #ddd;
            _border-radius: 4px;
            -webkit-transition: border .2s ease-in-out;
            -o-transition: border .2s ease-in-out;
            transition: border .2s ease-in-out;
        }

        .header_image{
            line-height: 0px !important;
        }

    </style>
    <link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/bootstrap-fileinput/bootstrap-fileinput.css') }}" />

    <link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
    @endpush

@section('content')

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <!-- alert messages -->
                @include('admin.layouts.flash-message')
                <!-- End alert messages -->
                <div class="card">
                    <div class="card-header card-header-primary">
                        <a href="{{route('email_templates')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                        <h4 class="card-title">@lang('messages.edit_email_template')</h4>
                    </div>
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="myTab">
                            @php
                            $i = 0;
                            @endphp
                            @foreach($languagecodes as $languagecode)
                            @php
                            $i++;
                            @endphp
                            <li class="@if($i==1) active @endif">
                                <a data-toggle="tab" href="#{{$languagecode->name}}" class="@if($i==1) active @endif">{{$languagecode->name}}</a>
                            </li>
                            @endforeach
                        </ul>
						<form method="post" action="{{route('edit_email_template', $template->emailtemplate_id)}}" enctype="multipart/form-data">
						@method('PUT')
						@csrf
						<input type="hidden" name="emailtemplate_id" value="{{$template->emailtemplate_id}}" />
                        <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group label-floating is-empty is-fileinput">
                                                <label class="control-label">@lang('messages.header_image')</label>
                                                <div class="input file">
                                                    <label for="header-image"></label>
                                                </div>

                                                <div class="fileinput fileinput-exists" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail header_image" style="width: 100%; height: auto;">
                                                        <img src="{{asset('content/img/image-placeholder.png')}}" alt="Header Image">
                                                    </div>
                                                    @php
                                                        $header_image  =  Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->header_image ?? '';
                                                        $header_image_img = asset('content/img/image-placeholder.png');
                                                        if(!empty($header_image)){
                                                            $header_image_img = url('application/public/uploads/emailtemplates/'.$header_image);
                                                        }
                                                    @endphp
                                                    <div class="fileinput-preview fileinput-exists thumbnail header_image" style="width: 100%; height: auto;">
                                                        <img src="{{ $header_image_img }}" alt="Header Image">
                                                    </div>
                                                    <div>
                                                    <span class="btn btn-primary custom-file-upload default btn-file">
                                                    <span class="fileinput-new"><i class="fa fa-upload"></i> @lang('messages.selectimage') </span>
                                                    <span class="fileinput-exists"><i class="fa fa-upload"></i> @lang('messages.edit_image') </span>
                                                    <input type="file" name="header_image" accept="image/*">
                                                    </span>                                                    
                                                    </div>
                                                </div>

                                                <span class="material-input"></span>
                                                @error('header_image_'.strtolower($languagecode->name))
                                                <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group label-floating is-fileinput">
                                                <label class="control-label">@lang('messages.white_logo')</label>
                                                <div class="input file">
                                                <label for="white-logo"></label>
                                                </div>

                                                <div class="fileinput fileinput-exists" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail white_logo" style="width: 120px; height: auto; background: #{{Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->main_color ?? ''}}">
                                                <img src="{{asset('content/img/image-placeholder.png')}}" alt="">
                                                </div>
                                                @php
                                                    $white_logo  =  Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->white_logo ?? '';
                                                    $white_logo_img = asset('content/img/image-placeholder.png');
                                                    if(!empty($white_logo)){

                                                        $white_logo_img = url('application/public/uploads/emailtemplates/'.$white_logo);
                                                    }
                                                @endphp
                                                <div class="fileinput-preview fileinput-exists thumbnail white_logo_{{$languagecode->name}}" style="width: 120px; height: auto; background: #{{Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->main_color ?? ''}};"><img src="{{ $white_logo_img }}" alt="White logo"></div>
                                                    <div>
                                                    <span class="btn btn-primary custom-file-upload default btn-file">
                                                    <span class="fileinput-new"><i class="fa fa-upload"></i> @lang('messages.selectimage') </span>
                                                    <span class="fileinput-exists"><i class="fa fa-upload"></i> @lang('messages.edit_image') </span>
                                                    <input type="file" name="white_logo" accept="image/*">
                                                    </span>                                                    
                                                    </div>
                                                </div>

                                                <span class="material-input"></span>
                                                @error('white_logo_'.strtolower($languagecode->name))
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                        <div class="tab-content">
                            @php
                            $i = 0;
                            @endphp
                            @foreach($languagecodes as $languagecode)
                            @php
							$lc_name = strtolower($languagecode->name);
                            $i++;
                            @endphp
                            <div id="{{$languagecode->name}}" class="tab-pane fade in @if($i==1) active @endif">
                                
                                    <input type="hidden" name="languagecode[{{$lc_name}}]" value="{{$languagecode->id}}">                                    
                                    <input type="hidden" name="languagecode_name[{{$lc_name}}]" value="{{$languagecode->name}}">
                                    <input type="hidden" name="template_id[{{$lc_name}}]" value="{{ Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->id ?? '' }}">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group label-floating">
                                                <label class="control-label">@lang('messages.subject')</label>
                                                <div class="input text required">
                                                    <label for="subject"></label>
                                                    <input type="text" name="subject[{{$lc_name}}]" class="form-control titleclass" maxlength="191" value="{{ Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->subject ?? '' }}" required="required">
                                                </div>
                                                <span class="material-input"></span>
                                                @error('subject_'.strtolower($languagecode->name))
                                                <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group label-floating">
                                                <label class="control-label">@lang('messages.sender_name')</label>
                                                <div class="input text required">
                                                    <label for="sender_name"></label>
                                                    <input type="text" name="sender_name[{{$lc_name}}]" class="form-control titleclass" required="required" maxlength="191" value="{{ Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->sender_name ?? '' }}">
                                                </div>
                                                <span class="material-input"></span>
                                                @error('sender_name_'.strtolower($languagecode->name))
                                                <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group label-floating">
                                                <label class="control-label">@lang('messages.main_color')</label>
                                                <div class="input text">
                                                    <label for="main-color"></label>
                                                    <input type="text" name="main_color[{{$lc_name}}]" class="form-control titleclass jscolor" maxlength="50" value="{{ Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->main_color ?? '' }}" id="main-color_{{$languagecode->name}}" autocomplete="off" style="background-image: none; background-color: rgb(63, 233, 192); color: rgb(0, 0, 0);">
                                                </div>
                                                <span class="material-input"></span>
                                                @error('main_color_'.strtolower($languagecode->name))
                                                <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group label-floating">
                                                <label class="control-label">@lang('messages.secondary_color')</label>
                                                <div class="input text">
                                                    <label for="secondary-color"></label>
                                                    <input type="text" name="secondary_color[{{$lc_name}}]" class="form-control titleclass jscolor" maxlength="50" value="{{ Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->secondary_color ?? '' }}" autocomplete="off" style="background-image: none; background-color: rgb(63, 233, 192); color: rgb(0, 0, 0);">
                                                </div>
                                                <span class="material-input"></span>
                                                @error('secondary_color_'.strtolower($languagecode->name))
                                                <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    
                                    

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group label-floating">
                                                <label class="control-label content-label">@lang('messages.description')</label>
                                                <div class="input textarea required">
                                                    <label for="txtEditor"></label>
                                                    <textarea class="form-control" id="txtEditor_{{$languagecode->name}}" name="description[{{$lc_name}}]">{{ Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->description ?? '' }}</textarea>
                                                </div>
                                                <span class="material-input"></span>
                                                @error('description_'.strtolower($languagecode->name))
                                                <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-md-12">
                                            <div class="form-group label-floating">
                                                <label class="control-label content-label">@lang('messages.Text version of the email')</label>
                                                <div class="input textarea required">
                                                    <label for="txtEditor"></label>
                                                    <textarea class="form-control" name="text_part[{{$lc_name}}]" rows="8">{{ Helper::getemailtemplateDetail($template->emailtemplate_id, $languagecode->id)->text_part ?? '' }}</textarea>
                                                </div>
                                                <span class="material-input"></span>
                                                @error('text_part_'.strtolower($languagecode->name))
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>

                                    </div>

                            </div>
                            @endforeach
                        </div>
						<button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
						<div class="clearfix"></div>
					</form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


@push('js')
    <script type="text/javascript" src="{{asset('content/assets/js/jscolor.js')}}"></script>
    <script type="text/javascript" src="{{asset('content/assets/ckeditor/ckeditor.js')}}"></script>
    <script>
        $(function(){
            <?php
                foreach($languagecodes as $languagecode){
            ?>
            CKEDITOR.replace('txtEditor_<?php echo $languagecode->name; ?>', {
                fullPage: true,
                // want to  freely enter any HTML content in source mode without any limitations.
                allowedContent: true,
                height:520,
            });
            <?php } ?>
        });

        $(document).ready(function () {
            <?php
                foreach($languagecodes as $languagecode){
            ?>
            //Add backound color in header image
            $('#main-color_<?php echo $languagecode->name; ?>').on('keyup keypress blur change', function(e) {
                var main_color = $(this).val();
                $(".white_logo_{{$languagecode->name}}").css("background-color", "#"+main_color+"");
            });
            <?php } ?>

            //Add backound color in white logo image
            $('#secondary-color').on('keyup keypress blur change', function(e) {
                //var main_color = $(this).val();
                //$(".white_logo").css("background-color", "#"+main_color+"");
            });   
        });
    </script>

    <script>

        $(document).ready(function(){

            $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
                localStorage.setItem('activeTab', $(e.target).attr('href'));
            });

            var activeTab = localStorage.getItem('activeTab');

            if(activeTab){
                $('#myTab a[href="' + activeTab + '"]').tab('show');
            }
        });
    </script>

    <script type="text/javascript" src="{{ asset('content/assets/back-end/bootstrap-fileinput/bootstrap-fileinput.js')}}"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

@endpush
