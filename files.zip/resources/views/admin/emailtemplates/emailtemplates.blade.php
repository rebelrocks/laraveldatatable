@extends('admin.layouts.app')
@section('title', trans('messages.email_templates'))
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('add_email_template')}}" title="@lang('messages.add_new_template')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_new_template')<div class="ripple-container"></div></a>
                                <h4 class="card-title "><i class="material-icons iconset">email</i> @lang('messages.email_templates')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>#</th>
                                            <th>@lang('messages.title')</th>
                                            <th>@lang('messages.subject')</th>
                                            <th>@lang('messages.status')</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
                                            @php
                                                $i = 1;
                                            @endphp
                                            @forelse($emailtemplates as $emailtemplate)
                                            <tr>
                                                @php 
                                                    $emailtemplatetitle =  str_replace('_', ' ', $emailtemplate->title);
                                                @endphp
                                                <td>{{ $i++ }}</td>
                                                <td>{{ ucwords($emailtemplatetitle) }}</td>
                                                <td>{{ $emailtemplate->subject }}</td>
                                                <td>
                                                    <a id="atag{{$emailtemplate->id}}"  class="btn btn-{{ $emailtemplate->status == 1 ? 'success' : 'danger' }}" data-id="{{$emailtemplate->id}}" data-status="{{$emailtemplate->status}}" href="javascript:void(0)" onclick="updateemailtemplateStatus(this)">
                                                        {{ $emailtemplate->status == 1 ? __('messages.statusactive') : __('messages.statusinactive') }}
                                                    </a>
                                                </td>
                                                <td class="text-right">
                                                    <a href="{{route('edit_email_template', $emailtemplate->emailtemplate_id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                    <a href="{{route('sendtestemail', ['id' => $emailtemplate->id])}}" class="btn btn-primary"><i class="material-icons">send</i> Envoyer un test<div class="ripple-container"></div></a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
