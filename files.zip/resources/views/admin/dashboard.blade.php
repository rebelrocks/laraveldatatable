@inject('canchk', 'App\Repositories\ChepremissionClassForBlade')
@extends('admin.layouts.app')
@section('title', 'Dashboard') 
@push('css')
<style>
   .button.DTTT_button, div.DTTT_button, a.DTTT_button {
      display: none !important;
   }
   select[name="example_length"] {
      padding: 5px;
      border: 1px solid gray;
   }
   @media only screen and (min-width: 980px) and (max-width: 1080px) {
      
   }
</style>
@endpush
@section('content')
<div class="content">
   <div class="container-fluid">
      @include('admin.layouts.flash-message')
      <div class="row">
         @if($canchk->checkPermission(Auth::user()->role_id, 'users', 'is_read') || (Auth::user()->role_id == 4))
         <div class="col-lg-4 col-md-6 col-sm-6">
            <a href="{{route('users')}}">
            <div class="card card-stats">
               <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                     <i class="material-icons">person</i>
                  </div>
                  <p class="card-category">
                     @lang('Total Voters')
                  </p>
                  <h3 class="card-title">{{$total_users}}</h3>
               </div>
               <div class="card-footer">
                  <div class="stats">
                     <i class="material-icons">send</i>
                     @lang('View')
                  </div>
               </div>
            </div>
            </a>
         </div>
         
         <div class="col-lg-4 col-md-6 col-sm-6">
            <a href="{{route('users',[3])}}">
            <div class="card card-stats">
               <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                     <i class="material-icons">person</i>
                  </div>
                  <p class="card-category">
                     @lang('Total Updated Voters')
                  </p>
                  <h3 class="card-title">{{$total_updated_users}}</h3>
               </div>
               <div class="card-footer">
                  <div class="stats">
                     <i class="material-icons">send</i>
                     @lang('View')
                  </div>
               </div>
            </div>
            </a>
         </div>
         
         <div class="col-lg-4 col-md-6 col-sm-6">
            <a href="{{route('users',[2])}}">
            <div class="card card-stats">
               <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                     <i class="material-icons">person</i>
                  </div>
                  <p class="card-category">
                     @lang('New Voter Request')
                  </p>
                  <h3 class="card-title">{{$total_requests}}</h3>
               </div>
               <div class="card-footer">
                  <div class="stats">
                     <i class="material-icons">send</i>
                     @lang('View')
                  </div>
               </div>
            </div>
            </a>
         </div>

         <div class="col-lg-4 col-md-6 col-sm-6">
            <a href="{{route('users',[1])}}">
            <div class="card card-stats">
               <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                     <i class="material-icons">person</i>
                  </div>
                  <p class="card-category">
                     @lang('Total Updated Request')
                  </p>
                  <h3 class="card-title">{{$total_updated_requests}}</h3>
               </div>
               <div class="card-footer">
                  <div class="stats">
                     <i class="material-icons">send</i>
                     @lang('View')
                  </div>
               </div>
            </div>
            </a>
         </div>

         <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="card card-stats" style="min-height:125px;">
               <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                     <i class="material-icons">person</i>
                  </div>
                  <p class="card-category">
                     @lang('Total Ratings')
                  </p>
                  <h3 class="card-title">{{$total_ratings}}<sup>({{$total_count}})</sup></h3>
               </div>
               <div class="card-footer">
                  <div class="stats">
                     
                  </div>
               </div>
            </div>
         </div>

         
         <!-- <div class="col-lg-4 col-md-6 col-sm-6">
            <a href="{{route('users',[2])}}">
            <div class="card card-stats">
               <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                     <i class="material-icons">person</i>
                  </div>
                  <p class="card-category">
                     @lang('New Voter Request')
                  </p>
                  <h3 class="card-title">{{$total_requests}}</h3>
               </div>
               <div class="card-footer">
                  <div class="stats">
                     <i class="material-icons">send</i>
                     @lang('View')
                  </div>
               </div>
            </div>
            </a>
         </div> -->

         @endif
      </div>
      <div class="row">
      @if($canchk->checkPermission(Auth::user()->role_id, 'users', 'is_read') || (Auth::user()->role_id == 4 ))
      
      <!-- <div class="col-lg-4 col-md-12">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">@lang('messages.new_users')</h4>
               <p class="card-category">@lang('New Voters List')</p>
            </div>
            <div class="card-body table-responsive">
               <table class="table table-hover">
                  <thead class="text-warning">
                     <th>#</th>
                     <th>@lang('messages.first_name')</th>
                     <th>@lang('messages.created')</th>
                  </thead>
                  <tbody>
                     @php $id=1; @endphp
                     @forelse($users as $user)
                     
                     <tr>
                        <td>{{$id}}</td>
                        <td><a href="{{ route('viewuser', $user->id) }}">{{ ucwords($user->first_name)}}</a></td>
                        <td>
                           @if(!empty($user->created_at))
                           {{ \Carbon\Carbon::parse($user->created_at)->format('d/m/Y') ?? '-' }}
                           @else
                           -    
                           @endif
                        </td>
                     </tr>
                     @php $id++; @endphp
                     @empty
                     <tr>
                        <td colspan="4" class="text-center">@lang('messages.user_not_found')</td>
                     </tr>
                     @endforelse
                  </tbody>
               </table>
            </div>
         </div>
      </div> -->
      @endif

      @if($canchk->checkPermission(Auth::user()->role_id, 'activities', 'is_read') || (Auth::user()->role_id >= 4))
      
      <div class="col-lg-12 col-md-12">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">@lang('User Activities')</h4>
               <p class="card-category">@lang('New activity List')</p>
            </div>
            <div class="card-body table-responsive">
               <table class="table table-hover" id="example">
                  <thead class="text-warning">
                     <th>#</th>
                     <th>@lang('Activity')</th>
                     <th>@lang('Performed By')</th>
                     <th>@lang('Role')</th>
                     <th>@lang('messages.created')</th>
                  </thead>
                  <tbody>
                     @php $id=1; @endphp
                     @forelse($activities as $activity)
                     <tr>
                        <td>{{$id}}</td>
                        <td><b>{{ ucwords($activity->activities)}}</b></td>
                        <td>{{ ucwords($activity->first_name.' '.$activity->last_name)}}</td>
                        <td>{{ ucwords($activity->name)}}</td>
                        <td>
                           @if(!empty($activity->created_at))
                           {{ \Carbon\Carbon::parse($activity->created_at)->format('d/m/Y H:i:s') ?? '-' }}
                           @else
                           -    
                           @endif
                        </td>
                     </tr>
                     @php $id++; @endphp
                     @empty
                     <tr>
                        <td colspan="4" class="text-center">@lang('NO Activity Available...')</td>
                     </tr>
                     @endforelse
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      @endif
      </div>
     				
   </div>
</div>

@endsection

@push('js')
<!-- DataTables CSS -->

<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.css">

<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/tabletools/2.2.2/css/dataTables.tableTools.css">



<script type="text/javascript" charset="utf8" src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.js"></script>

<script type="text/javascript" charset="utf8" src="http://cdn.datatables.net/tabletools/2.2.2/js/dataTables.tableTools.min.js"></script>
<script>

$(document).ready( function () {
    $('#example').dataTable( {
        "dom": 'T<"clear">lfrtip',
        "tableTools": {
            "sSwfPath": "http://cdn.datatables.net/tabletools/2.2.2/swf/copy_csv_xls_pdf.swf"
        }
    } );
} );
</script>
@endpush