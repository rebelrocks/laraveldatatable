@extends('admin.layouts.app')
@section('title', 'Social Links')
@push('css')
<style type="text/css">
    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->
                        
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><i class="material-icons iconset">people</i> @lang('messages.social_links')</h4>
                            </div>
                            <div class="card-body">
                                <form method="post" action="{{ route('social_links') }}">
                                    @method('PUT')
                                    @csrf

                                    @foreach($sociallinks as $sociallink)
                                    <div class="row">

                                        <div class="col-md-8">
                                            <div class="form-group bmd-label-floating">
                                                <label class="control-label">
                                                    @php
                                                        $lable_name = \Str::slug($sociallink->label, '_')
                                                    @endphp
                                                    {{ __('messages.'.$lable_name) }}
                                                </label>
                                                <div class="input text">
                                                    <input type="text" name="name[{{$sociallink->id}}]" class="form-control" id="name-{{$sociallink->id}}" value="{{$sociallink->value}}">
                                                </div>                                
                                                <span class="material-input"></span>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group label-floating togglebutton">
                                                <label class="switch">
                                                    <input type="checkbox" name="status[{{$sociallink->id}}]" value="1" {{ $sociallink->status ? 'checked' : '' }}><span class="toggle"></span>
                                                </label>                                        
                                            </div>
                                        </div>

                                    </div>
                                    @endforeach

                                    <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                    <div class="clearfix"></div>
                                    
                                </form>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
@endsection
