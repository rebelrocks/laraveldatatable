@extends('admin.layouts.app')
@section('title', 'Managers')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->
                        
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('add_manager')}}" title="@lang('messages.add_manager')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_manager')<div class="ripple-container"></div></a>
                                <h4 class="card-title ">@lang('messages.managers')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>@lang('messages.name')</th>
                                            <th>@lang('messages.status')</th>
                                            <th>@lang('messages.created')</th>
                                            <th>@lang('messages.modified')</th>
                                            <!--th class="text-right">Actions</th-->
                                        </thead>
                                        <tbody>
                                            @forelse($managers as $manager)
                                            <tr>
                                                <td>{{$manager->name}}</td>
                                                <td>
                                                    <a class="btn btn-{{ $manager->status == 1 ? 'success' : 'danger' }}" data-id="{{$manager->id}}" data-status="{{$manager->status}}" href="javascript:;">
                                                        {{ $manager->status == 1 ? __('messages.statusactive') : __('messages.statusinactive') }}
                                                    </a>
                                                </td>
                                                <td>{{ $manager->created_at }}</td>
                                                <td>{{ $manager->updated_at }}</td>
                                                <!--td class="text-right">
                                                    <a href="{{route('edit_manager', $manager->id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                    <a href="{{ route('delete_manager', $manager->id) }}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a>
                                                </td-->
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
