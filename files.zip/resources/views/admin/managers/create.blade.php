@extends('admin.layouts.app')
@section('title', 'Add Manager')
@push('css')
<style type="text/css">

    .invalid-feedback{
        display: block !important;
    }
</style>

@endpush

@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <a href="{{route('managers')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
                                    <h4 class="card-title">@lang('messages.add_manager')</h4>
                                </div>
                                <div class="card-body">
                                    <form method="post" action="{{route('add_manager')}}">
                                        @csrf
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="bmd-label-floating">@lang('messages.name')</label>
                                                    <input type="text" name="name" value="{{old('name') }}" class="form-control" maxlength="255" id="name" autofocus >
                                                    @error('name')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="bmd-label-floating">@lang('messages.status')</label>
                                                    <select class="form-control" name="status">
                                                        <option value="">--Select Status--</option>
                                                        <option {{ old('status') == '1' ? 'selected' : '' }} value="1">Active</option>
                                                        <option {{ old('status') == '0' ? 'selected' : '' }} value="0">Inactive</option>
                                                    </select>

                                                    @error('status')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                            </div>
                                     
                                        </div>
                                        <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
