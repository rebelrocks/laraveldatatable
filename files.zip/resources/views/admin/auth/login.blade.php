<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{Helper::getapplicationName()}} - Admin Login</title>
    <link rel="apple-touch-icon" sizes="57x57" href="{{ asset('content/img/apple-icon-57x57.png') }}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{ asset('content/img/apple-icon-60x60.png') }}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{ asset('content/img/apple-icon-72x72.png') }}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('content/img/apple-icon-76x76.png') }}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{ asset('content/img/apple-icon-114x114.png') }}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{ asset('content/img/apple-icon-120x120.png') }}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{ asset('content/img/apple-icon-144x144.png') }}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{ asset('content/img/apple-icon-152x152.png') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('content/img/apple-icon-180x180.png') }}">
    <link rel="icon" type="image/png" sizes="192x192"  href="{{ asset('content/img/android-icon-192x192.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('content/img/favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="96x96" href="{{ asset('content/img/favicon-96x96.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('content/img/favicon-16x16.png') }}">
    <link rel="manifest" href="{{ asset('content/img/manifest.json') }}">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{ asset('content/img/ms-icon-144x144.png') }}">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- Material Dashboard CSS -->
    <link href="{{asset('content/assets/login/css/material-dashboard.min.css')}}" rel="stylesheet"/>
    <script type="text/javascript" src="{{asset('content/assets/login/js/jquery-3.1.0.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('content/assets/login/js/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('content/assets/login/js/material.min.js')}}"></script>
    <style>
        .custom-css-header{
            padding-bottom: 0px;
        }
        .action-button {
        width: 200px;
        background: linear-gradient(to right, #99cd43 0%,#3f7501 100%);
        color: #ffffff;
        border: 0 none;
        border-radius: 7px;
        cursor: pointer;
        font-weight: 400;
        padding: 10px 50px;
        margin: 20px 0 0;
        font-size: 20px;
        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
        height: 50px;
        box-shadow:0 0 10px lightgrey;
        font-weight: 500;
    }
    .navigation-register {
        font-size: 16px !important;
        color: #000 !important;
        margin-top: 10px;
        float: left;
        text-align: center;
        padding-bottom: 5px !important;
        width: 100%;
    }

    .navigation-register a {
        font-size: 16px !important;
        color: #000 !important;
        text-decoration: underline;
    }
	#LoginCards{
		padding-top:25px;
		padding-bottom:25px;
	}
    </style>
</head>

<body class="off-canvas-sidebar">

    <div class="wrapper wrapper-full-page">
        @php
            $sitesetting = Helper::siteSettings();
            $loginbackground = $sitesetting['site.login_background'] ?? '';
            $logo = $sitesetting['site.logo'] ?? '';
        @endphp
        <div class="page-header login-page header-filter" filter-color="black" style="background-image: url({{asset('application/public/uploads/settings/'.$loginbackground)}}); background-size: cover; background-position: top center;">
        
            <!-- Begin Page Content -->
            <div class="container" style="margin-bottom: 50px;">
                <div class="col-lg-4 col-md-6 col-sm-6 ml-auto mr-auto">
                    <form method="post" action="{{ route('login') }}">
                        @csrf
                        @error('email')
                            <div class="message error hidden">
                                {{ $message }}
                            </div>
                         @enderror
                        <div class="card card-login" id="LoginCards">
                            <div class="card-header card-header-rose text-center custom-css-header">
                                <h4 class="card-title">
                                    <img src="{{asset('application/public/uploads/settings/'.$logo)}}" title="{{Helper::getapplicationName()}}" alt="{{Helper::getapplicationName()}}" style="width: 80px; margin-top: 25px; border-radius: 10px;"/>
                                </h4>
                            </div>

                            <div class="card-body " style="margin-top:-35px;">
                                <span class="bmd-form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                          <span class="input-group-text">
                                            <i class="material-icons">email</i>
                                          </span>
                                        </div>
                                        <input type="email" name="email" class="form-control" placeholder="@lang('messages.email')" value="{{ old('email') }}" id="email" required autocomplete="email" autofocus />
                                    </div>
                                </span>

                                <span class="bmd-form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">lock_outline</i>
                                            </span>
                                        </div>
                                        <input type="password" name="password" class="form-control" placeholder="@lang('messages.password')" id="password" required autocomplete="current-password"/>
                                    </div>
                                </span>
                                @if (Route::has('password.request'))
                                <span class="bmd-form-group" style="float: right; width: 100%; margin: 5px 0 0; color: rgb(0, 0, 0); font-size: 12px; padding-right: 5px;">
                                <a href="{{ route('password.request') }}" class="forgot_admin_btn pull-right" style="text-decoration: none; color: rgb(0, 0, 0);">@lang('messages.forgot_password')</a>
                                <!-- <br>
                                <a href="" class="forgot_admin_btn pull-right" style="text-decoration: none; color: rgb(0, 0, 0);">@lang('messages.register_providors_text')</a> -->
                                </span>
                                @endif
                            </div>

                            <div class="card-footer justify-content-center">
								<button type="submit" class="btn btn-rose btn-link btn-lg">
                                    @lang('messages.login') <i class="m-icon-swapright m-icon-white"></i>
                                </button> 
                            </div>
                                
                                
                        </div>
                    </form>
                </div>
            </div>        
            <!-- End Page Content -->
        
            <footer class="footer" style="margin-top:50px;">
                <div class="container">
                    <div class="copyright">
                        <small>{{date('Y')}} &copy; {{ Helper::getapplicationName() }}</small>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
</html>
