<div class="sidebar" data-color="purple" data-background-color="white">
            
            <!--
                Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

                Tip 2: you can also add an image using data-image tag
            -->

            <div class="logo">
                <a href="{{route('admin_dashboard')}}">
                    <img src="{{ asset('application/public/uploads/settings/'.$logo) }}" title="{{Helper::getapplicationName()}}" style="width: 110px;" alt="{{Helper::getapplicationName()}}">
                </a>    
            </div>

            <div class="sidebar-wrapper">
                <ul class="nav">
                    
                    <li class="nav-item {{ Route::currentRouteName() == 'admin_dashboard' ? 'active' : '' }}">
                        <a class="nav-link" href="{{route('admin_dashboard')}}">
                            <i class="material-icons">dashboard</i>
                            <p>@lang('messages.dashboard')</p>
                        </a>
                    </li>	
					
					@if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
					<li class="nav-item {{ (request()->is('admin/users*')) ? 'active' : ''}}">
						<a class="nav-link" data-toggle="collapse" href="#users" aria-expanded="{{ (request()->is('admin/users*')) ? 'true' : '' }}">
							<i class="material-icons">person</i>
							<p>@lang('Voters List')  <b class="caret"></b></p>
						</a>
						<div class="collapse {{ (request()->is('admin/users*')) ? 'show' : '' }}" id="users">
							<ul class="nav subul">
								@if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
								<!-- voters -->
								<li class="nav-item {{ (request()->is('admin/users')) ? 'active' : '' }}">
									<a class="nav-link" href="{{route('users')}}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal">@lang('Total Voter User') </span>
									</a>
								</li>
								@endif
								@if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
								<li class="nav-item {{ (request()->is('admin/users/3')) ? 'active' : ''}}">
									<a class="nav-link" href="{{ route('users',[3]) }}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> @lang('Total Updated Voter') </span>
									</a>
								</li>	
								@endif
								<!-- Requests -->
								@if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
								<li class="nav-item {{ (request()->is('admin/users/2')) ? 'active' : ''}}">
									<a class="nav-link" href="{{ route('users',[2]) }}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> @lang('Voter Request') </span>
									</a>
								</li>	
								@endif
								@if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
								<li class="nav-item {{ (request()->is('admin/users/1')) ? 'active' : ''}}">
									<a class="nav-link" href="{{ route('users',[1]) }}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> @lang('Updated Voter Request') </span>
									</a>
								</li>	
								@endif
								
							</ul>
						</div>
					</li>
					@endif

					<!-- @if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'users' || Route::currentRouteName() == 'edituser' || Route::currentRouteName() == 'adduser') ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('users') }}">
								<i class="material-icons">layers</i>
								<p> @lang('Constituency Management') </p>
							</a>
						</li>
					@endif -->

					<!-- @if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'users' || Route::currentRouteName() == 'edituser' || Route::currentRouteName() == 'adduser') ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('users') }}">
								<i class="material-icons">assessment</i>
								<p> @lang('Booths Management') </p>
							</a>
						</li>
					@endif  -->

					<!-- @if($can->checkPermission(Auth::user()->role_id, 'blocks', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'blocks' || Route::currentRouteName() == 'add_block' || Route::currentRouteName() == 'update_block') ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('blocks') }}">
								<i class="material-icons">apps</i>
								<p> @lang('Blocks Management') </p>
							</a>
						</li>
					@endif -->

					<!-- @if($can->checkPermission(Auth::user()->role_id, 'sub-blocks', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'sub_blocks' || Route::currentRouteName() == 'add_sub_block' || Route::currentRouteName() == 'update_sub_block') ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('users') }}">
								<i class="material-icons">apps</i>
								<p> @lang('Sub-Blocks Management') </p>
							</a>
						</li>
					@endif -->

					@if($can->checkPermission(Auth::user()->role_id, 'import', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'importExportView' || Route::currentRouteName() == 'import' || Route::currentRouteName() == 'export') ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('importExportView') }}">
								<i class="material-icons">backup</i>
								<p> @lang('Import Voter Data') </p>
							</a>
						</li>
					@endif

					@if($can->checkPermission(Auth::user()->role_id, 'FAQ', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'faqs' || Route::currentRouteName() == 'create_faqs' || Route::currentRouteName() == 'edit_faqs'|| Route::currentRouteName() == 'faqcategories' || Route::currentRouteName() == 'update_faqcategory' || Route::currentRouteName() == 'add_faqcategory' ) ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('faqs') }}">
							<i class="material-icons">message</i>
								<p> @lang('FAQs') </p>
							</a>
						</li>
					@endif 
					<!-- @if($can->checkPermission(Auth::user()->role_id, 'users', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'databases' || Route::currentRouteName() == 'edidatabase' || Route::currentRouteName() == 'adddatabase') ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('users') }}">
								<i class="material-icons">backup</i>
								<p> @lang('Voter Database') </p>
							</a>
						</li>
					@endif -->
						
                    @if($can->checkPermission(Auth::user()->role_id, 'cmsmanagement', 'is_read'))
						<li class="nav-item {{ (Route::currentRouteName() == 'cms_pages' || Route::currentRouteName() == 'editpage') ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('cms_pages') }}">
								<i class="material-icons">view_list</i>
								<p>@lang('messages.cms_management')</p>
							</a>
						</li>  
					@endif                    
					
					@if($can->checkPermission(Auth::user()->role_id, 'notifications', 'is_read'))
						<li class="nav-item {{ (request()->is('admin/notifications*')) ? 'active' : '' }}">
							<a class="nav-link" href="{{ route('notifications') }}">
								<i class="material-icons">notifications</i>
								<p>@lang('messages.notifications')</p>
							</a>
						</li>
					@endif                   
                    @if($can->checkPermission(Auth::user()->role_id, 'settings', 'is_read') || $can->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_read') || $can->checkPermission(Auth::user()->role_id, 'sociallinks', 'is_read') || $can->checkPermission(Auth::user()->role_id, 'language', 'is_read'))
                    <li class="nav-item {{ (Route::currentRouteName() == 'web_settings'  || (request()->is('admin/emailtemplates*'))  || (request()->is('admin/notificationtext*'))  || Route::currentRouteName() == 'social_links'  || (request()->is('admin/languages*'))  ) ? 'active' : '' }}">
						<a class="nav-link" data-toggle="collapse" href="#settings" aria-expanded="{{ (Route::currentRouteName() == 'web_settings'  || (request()->is('admin/emailtemplates*'))  || (request()->is('admin/notificationtext*')) || Route::currentRouteName() == 'social_links'  || (request()->is('admin/languages*')) ) ? 'true' : '' }}">
							<i class="material-icons">settings</i>
							<p>@lang('messages.settings') <b class="caret"></b></p>
						</a>
						<div class="collapse {{ (Route::currentRouteName() == 'web_settings'  || (request()->is('admin/emailtemplates*')) || (request()->is('admin/notificationtext*')) || Route::currentRouteName() == 'social_links' || (request()->is('admin/languages*')) ) ? 'show' : '' }}" id="settings">
							<ul class="nav subul">
								<!-- Settings -->
								@if($can->checkPermission(Auth::user()->role_id, 'settings', 'is_read'))
									<li class="nav-item {{ Route::currentRouteName() == 'web_settings' ? 'active' : '' }}">
										<a class="nav-link" href="{{ route('web_settings') }}">
											<span class="sidebar-mini">&nbsp;</span>
											<span class="sidebar-normal"> @lang('messages.settings') </span>
										</a>
									</li>
								@endif

								<!-- Email templates -->
								@if($can->checkPermission(Auth::user()->role_id, 'emailtemplates', 'is_read'))
								<li class="nav-item {{ (request()->is('admin/emailtemplates*')) ? 'active' : '' }}">
									<a class="nav-link" href="{{ route('email_templates') }}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> @lang('messages.email_templates') </span>
									</a>
								</li>
								@endif
								<!-- Social links -->
								@if($can->checkPermission(Auth::user()->role_id, 'sociallinks', 'is_read'))
								<li class="nav-item {{ Route::currentRouteName() == 'social_links' ? 'active' : '' }}">
									<a class="nav-link" href="{{ route('social_links') }}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> @lang('messages.social_links') </span>
									</a>
								</li>
								@endif
								<!-- Language -->
								<!-- @if($can->checkPermission(Auth::user()->role_id, 'language', 'is_read'))								
								<li class="nav-item {{ (request()->is('admin/languages*')) ? 'active' : '' }}">
									<a class="nav-link" href="{{route('languages')}}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> @lang('messages.language') </span>
									</a>
								</li>
								@endif -->
							</ul>
						</div>
					</li>
					@endif
					@if($can->checkPermission(Auth::user()->role_id, 'adminusers', 'is_read') || $can->checkPermission(Auth::user()->role_id, 'roles', 'is_read'))
					<li class="nav-item {{ (request()->is('admin/adminusers*') || request()->is('admin/roles*') || request()->is('admin/sitepermissions*')) ? 'active' : ''}}">
						<a class="nav-link" data-toggle="collapse" href="#usersroles" aria-expanded="{{ (request()->is('admin/adminusers*') || request()->is('admin/roles*') || request()->is('admin/sitepermissions*')) ? 'true' : '' }}">
							<i class="material-icons">bubble_chart</i>
							<p>Accès <b class="caret"></b></p>
						</a>
						<div class="collapse {{ (request()->is('admin/adminusers*') || request()->is('admin/roles*') || request()->is('admin/sitepermissions*')) ? 'show' : '' }}" id="usersroles">
							<ul class="nav subul">
								@if($can->checkPermission(Auth::user()->role_id, 'adminusers', 'is_read'))
								<!-- admin users -->
								<li class="nav-item {{ (request()->is('admin/adminusers*')) ? 'active' : '' }}">
									<a class="nav-link" href="{{route('admin_users')}}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> Admin Users </span>
									</a>
								</li>
								@endif
								<!-- Roles -->
								@if($can->checkPermission(Auth::user()->role_id, 'roles', 'is_read'))
								<li class="nav-item {{ (request()->is('admin/roles*') || request()->is('admin/sitepermissions*')) ? 'active' : ''}}">
									<a class="nav-link" href="{{ route('roles') }}">
										<span class="sidebar-mini">&nbsp;</span>
										<span class="sidebar-normal"> Roles </span>
									</a>
								</li>	
								@endif
							</ul>
						</div>
					</li>
					@endif
					
					<li class="nav-item">
						<a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
							<i class="material-icons">keyboard_return</i>
							<p> @lang('Logout') </p>
						</a>
						<br>
						<br>
					</li>	
                    <li class="nav-item">&nbsp;</li>

                </ul>
            </div>
        </div>
		<style>
			@media only screen and (max-width: 989px) {
				.sidebar .nav li a, .sidebar .nav li .dropdown-menu a {
					margin: 10px 15px 0;
					border-radius: 3px;
					color: #fff !important;
					padding-left: 10px;
					padding-right: 10px;
					text-transform: capitalize;
					font-size: 13px;
					padding: 10px 15px;
				}
      
	        }
			
		</style>