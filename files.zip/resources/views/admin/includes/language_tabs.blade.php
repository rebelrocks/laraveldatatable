                                    <ul class="nav nav-tabs" id="myTab">
                                        @php
                                            $i = 0;
                                        @endphp
                                        @foreach($languagecodes as $languagecode)
                                        @php
                                            $i++;
                                        @endphp
                                        <li class="@if($i==1) active @endif"><a data-toggle="tab" href="#{{$languagecode->name}}">{{$languagecode->name}}</a></li>
                                        @endforeach
                                    </ul>