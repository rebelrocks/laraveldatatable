@extends('admin.layouts.app')
@section('title', trans('messages.edit_subcategory'))
@push('css')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style type="text/css">
   .invalid-feedback{
   display: block !important;
   }
   #map {
   width: 100%;
   height: 295px;
   margin-top:10px;
   }
   #location{
   z-index: 999;
   position: relative;
   left: 0px !important;
   top: 0px;
   width: 100% !important;
   border: 1px solid #ccc;
   background: #fff;
   padding:4px;
   }
   .gmnoprint{
   margin-top: 33px !important;
   }
   #AdsSelectImageType{
   width:100%;
   }
   .form-group input[type=file] {
   opacity: 1 !important;
   position: inherit !important;
   top: 0px;
   right: 0;
   bottom: 0;
   left: 0;
   width: 100%;
   height: 100%;
   z-index: 100;
   }
   #ui-datepicker-div{
   z-index : 9999999 !important;	
   }		
   .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
   float: left;
   }

   .select2-container--default .select2-selection--multiple {
        background-color: white;
        border: 0px solid #aaa !important;
        border-bottom: 1px solid #aaa !important;
        border-radius: 0px;
        cursor: text;
        padding-bottom: 5px;
        padding-right: 5px;
        position: relative;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
@endpush
@section('content')
<div class="content">
<div class="container-fluid">
   <div class="row">
      <div class="col-md-12">
         <!-- alert messages -->
         @include('admin.layouts.flash-message')
         <!-- End alert messages -->
         <div class="card">
            <div class="card-header card-header-primary">
               <a href="{{route('blocks')}}" class="btn btn-add pull-right">
                  <i class="material-icons">reply</i> @lang('messages.back')
                  <div class="ripple-container"></div>
               </a>
               <h4 class="card-title"><i class="material-icons iconset">add_to_photos</i> @lang('Edit sub block')</h4>
            </div>
            <div class="card-body">
               <!-- Language tabs -->
              
               <form method="post" action="{{route('update_sub_block', $category->id)}}" enctype="multipart/form-data">
				      @csrf
                  {{ method_field('PUT') }}
                  <div class="tab-content">
									
                     <div class="row">
                        
                        <div class="col-md-6">
                           <div class="form-group label-floating is-empty">
                              <label for="title" class="">@lang('messages.category_title')</label>
                              <input type="text" name="title" value="{{ old('title',$category->title) }}" class="form-control" maxlength="191" id="title" autocomplete="off" autofocus >
                              @if($errors->has('title'))
                                 <span class="invalid-feedback" role="alert">
                                    @php
                                       $title_error_message = str_replace('.', ' ', $errors->first('title'));
                                    @endphp
                                    <strong>{{ $title_error_message }}</strong>
                                 </span>
                              @endif
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group label-floating is-empty">
                              <label for="title" class="">@lang('messages.training_subtitle')</label>
                              <input type="text" name="subtitle" value="{{ old('subtitle',$category->Subtitle_training) }}" class="form-control" id="title" autocomplete="off" autofocus >
                              @if($errors->has('subtitle'))
                                 <span class="invalid-feedback" role="alert">
                                    @php
                                       $title_error_message = str_replace('.', ' ', $errors->first('subtitle'));
                                    @endphp
                                    <strong>{{ $title_error_message }}</strong>
                                 </span>
                              @endif
                           </div>
                        </div>
                     </div>	
                     <div class="row">
                        @php
                        $slide_image = asset('content/img/image-placeholder.png');
                        
                        if(!empty( $category->img_default) && File::exists('application/public/uploads/categories/'. $category->img_default)){

                        $slide_image = url('application/public/uploads/categories/'. $category->img_default);
                        
                        }													
                        @endphp
                        <div class="col-md-6" id="image_container">
                           <div class="form-group label-floating">
                              <label for="slide_image" class="">{{ __('messages.banner_image') }}</label>
                                 <br>
                                 <span class="btn btn-primary custom-file-upload default btn-file">
                                    <span class="fileinput-new"><i class="fa fa-upload"></i> @lang('messages.select_image') </span>
                                    <span class="fileinput-exists"><i class="fa fa-upload"></i> @lang('messages.edit_image') </span>
                                    <input type="file" name="slide_image" id="fileToUpload" onchange="return fileValidation()" accept="image/*" style="display:none">
                                          <input type="hidden" value="{{ $category->img_default }}" name="previous_slide_image" id="previous_image_file">
                                 </span>
                                    <a href="javascript:;" class="btn red clear-file-btn" onclick="ClearMediaFile()" data-dismiss="fileinput"><i class="fa fa-trash"></i> @lang('messages.remove') </a>
                                    <br>
                                    <small style="color:red;padding-top:2px;" id="UploadFileError"></small>
                              </div>
                              <div class="thumbnail" id="" style="width: 100%; height: auto;">
                                 <img src="{{$slide_image}}" alt="" style="width: 100px;" id="ImagePreview">
                              </div>
                              <br>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">@lang('messages.number_of_questions')</label>
                              <div class="input text">
                                 <label for="secondary-color"></label>
                                 <input type="number" value="{{ old('number_of_question',$category->number_of_questions) }}" name="number_of_question" class="form-control titleclass" maxlength="50">
                              </div>
                              <span class="material-input"></span>
                              @error('number_of_question')
                              <span class="invalid-feedback" role="alert">
                              <strong>{{ $message }}</strong>
                              </span>
                              @enderror
                           </div>
                        </div>
               
                     </div>
                     <div class="row">
                        <div class="col-md-4">
                        <div class="form-group label-floating is-empty">
                           <label for="category_id" class="">@lang('Choose Block')</label>
                           <select name="category_id" class="form-control">
                           <option value="">Choose one Block</option>
                           <?php
                           if(count($categories) > 0){
                              foreach($categories as $categorys){
                              ?>
                              <option value="{{ $categorys->id }}" <?php if($categorys->id == $category->category_id){ echo 'selected';} ?>>{{ $categorys->title}}</option>
                              <?php
                              }
                           } ?>
                           </select>
                           
                        </div>
                     </div>	
                       <div class="col-md-4 mt-4">
                        <?php $content_type=$category->content_type;?>	
                           <div class="form-group bmd-form-group is-filled">
                              <label class="bmd-label-floating">@lang('messages.select_content_type')</label>
                              <select name="content_type" class=" form-control" required id="content_type">
                              <option class="form-control" value="">{{ __('messages.select_content_type') }}</option>
                                 <option class="form-control" value="VTC" <?php if('VTC' == $content_type){ echo 'selected'; }?>>{{ __('VTC') }}</option>
                                 <option class="form-control" value="Taxi" <?php if('Taxi' == $content_type){ echo 'selected'; }?>>{{ __('Taxi') }}</option>
                              </select>
                              @error('content_type')
                                    <span class="invalid-feedback" role="alert">
                                       <strong>{{ $message }}</strong>
                                    </span>
                              @enderror
                           </div>
                        </div>	
                        
                        <div class="col-md-4 mt-4">
                           <?php $content_type=explode(',',$category->department);
                           if($category->content_type == 'VTC'){
                              $content_types=['VTC'];
                           }elseif($category->content_type == 'Taxi'){
                              $content_types=['Taxi 75','Taxi 93'];
                           }else{
                              $content_types=['VTC','Taxi 75','Taxi 93'];
                           }

                           ?>	
                           <div class="form-group bmd-form-group is-filled">
                              <label class="bmd-label-floating">@lang('messages.department')</label>
                              <select name="department[]" multiple class=" form-control select2" required id="department">
                                 <?php foreach($content_types as $key => $value) { ?>
                                    <option class="form-control" value="{{ $value }}" <?php if(in_array($value,$content_type)){ echo 'selected'; }?>>{{ $value }}</option>
                                 <?php } ?>
                              </select>
                              @error('content_type')
                                    <span class="invalid-feedback" role="alert">
                                       <strong>{{ $message }}</strong>
                                    </span>
                              @enderror
                           </div>
                        </div>	
                  </div>					
                     <div class="row">
                        <div class="col-md-12">
                           <div class="form-check form-check-inline">
                              <label class="form-check-label">
                                 <input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status',$category->status) ? 'checked' : '' }}> @lang('messages.status')
                                 <span class="form-check-sign">
                                    <span class="check"></span>
                                 </span>
                              </label>
                           </div>
                        </div>
                     </div>	
                  </div>
                  <button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
                  <div class="clearfix"></div>
                  
               </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@push('js')
<script></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- Language script -->
<script type="text/javascript" src="{{ asset('content/assets/back-end/jquery-ui-master/ui/i18n/datepicker-fr.js') }}"></script>
<script type="text/javascript" src="{{asset('content/assets/js/jscolor.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
	$(document).ready(function(){
		$('.select2').select2();

		$('#content_type').change(function(){
			var content_type= $('#content_type').val();
			var HTMLDom='';
			if(content_type == 'VTC'){
				HTMLDom+=`
				<option class="form-control" value="VTC">{{ __('VTC') }}</option>
                `;

			}else if(content_type == 'Taxi'){
				HTMLDom+=`
				<option class="form-control" value="Taxi 75">{{ __('Taxi 75') }}</option>
                <option class="form-control" value="Taxi 93">{{ __('Taxi 93') }}</option>
				`;

			}else{
				
			}
			$('#department').html(HTMLDom);
		});
	});
</script>
<script>
    $(document).ready(function(){
      <?php 
         if(!empty($category->img_default)){
      ?>
      $('.fileinput-new').hide();
      $('.fileinput-exists').show();
		$('.clear-file-btn').show();
      <?php
         }else{
      ?>
      $('.fileinput-exists').hide();
		$('.clear-file-btn').hide();
      $('.fileinput-new').show();
      <?php
         }
      ?>
		
		$('.fileinput-new').click(function(){
			$('#fileToUpload').click();
		});
		$('.fileinput-exists').click(function(){
			$('#fileToUpload').click();
		});

	});
    function getFileExt(filename){
       return /[^.]+$/.exec(filename);
    }
   
    function FileSizeValidation(){ 
        
        const fi = document.getElementById('fileToUpload'); 
        if (fi.files.length > 0) { 
            for (const i = 0; i <= fi.files.length - 1; i++) { 
                const fsize = fi.files.item(i).size; 
                const file = Math.round((fsize / 1024)); 
                if (file >= 2048) { 
                  var file_size_validation="{{ trans('messages.file_size_validation') }}";

                  $('#UploadFileError').html(file_size_validation);
			         $('.fileinput-exists').hide();
		            $('.fileinput-new').show(); 
				      $('.clear-file-btn').hide();
                  $('#ImagePreview').attr('src',"{{asset('content/img/image-placeholder.png')}}");
				  return false;
                }else{ 
                  $('#UploadFileError').html("");
                  $('.fileinput-exists').show();
                  $('.clear-file-btn').show();
		            $('.fileinput-new').hide();
                  return true; 
                } 
            } 
        }
    }
    
    function fileValidation() { 
        var fileInput = document.getElementById('fileToUpload'); 
          
        var filePath = fileInput.value; 
      
        var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i; 
          
        if (!allowedExtensions.exec(filePath)) { 
         var image_validation_msg="{{ trans('messages.image_validation_msg') }}";

            $('#UploadFileError').html(image_validation_msg); 
            fileInput.value = ''; 
			   $('.fileinput-exists').hide();
		      $('.fileinput-new').show();
			   $('.clear-file-btn').hide();
            $('#ImagePreview').attr('src',"{{asset('content/img/image-placeholder.png')}}");
            return false; 
        }  
        else  
        { 
           if (fileInput.files && fileInput.files[0]) { 
                var reader = new FileReader(); 
                reader.onload = function(e) { 
					   $('.fileinput-exists').show();
		            $('.fileinput-new').hide();
					   $('.clear-file-btn').show(); 
                  $('#ImagePreview').attr('src',e.target.result);
                }; 
                  
                reader.readAsDataURL(fileInput.files[0]);
                $('#UploadFileError').html('');
                
            } 
        } 
    }
    
    function ClearMediaFile(){
         $('#fileToUpload').val('');
         $('#UploadFileError').html('');
         $('.fileinput-exists').hide();
         $('.fileinput-new').show();
         $('.clear-file-btn').hide();
         $('#ImagePreview').attr('src',"{{asset('content/img/image-placeholder.png')}}");
         $('#previous_image_file').val('');
    }
</script>
@endpush