@extends('admin.layouts.app')
@section('title', 'Add Ad')
@push('css')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<style type="text/css">
    .invalid-feedback{
        display: block !important;
    }
	#map {
        width: 100%;
        height: 295px;
        margin-top:10px;
    }

    #location{
        z-index: 999;
        position: relative;
        left: 0px !important;
        top: 0px;
        width: 100% !important;
        border: 1px solid #ccc;
        background: #fff;
        padding:4px;
    }
	.gmnoprint{
        margin-top: 33px !important;
    }
	#AdsSelectImageType{
		width:100%;
	}
	.form-group input[type=file] {
		opacity: 1 !important;
		position: inherit !important;
		top: 0px;
		right: 0;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 100;
	}
	#ui-datepicker-div{
		z-index : 9999999 !important;	
	}		
	.col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
        float: left;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />

@endpush

@section('content')
            
	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<!-- alert messages -->
					@include('admin.layouts.flash-message')
					<!-- End alert messages -->
					<div class="card">
						<div class="card-header card-header-primary">
							<a href="{{route('manage_ads')}}" class="btn btn-add pull-right"><i class="material-icons">reply</i> @lang('messages.back')<div class="ripple-container"></div></a>
							<h4 class="card-title"><i class="material-icons iconset">notifications</i> @lang('messages.add_ads')</h4>
						</div>
						<div class="card-body">
						
							<!-- Language tabs -->
							@include('admin.includes.language_tabs')
							
							<form method="post" action="{{route('create_new_ad')}}" enctype="multipart/form-data">
								@csrf
							
								<div class="tab-content">
									
									@php
										$i = 0;
									@endphp
									@foreach($languagecodes as $languagecode)
									@php
										$i++;
									@endphp
									<div id="{{$languagecode->name}}" class="tab-pane fade in @if($i==1) active @endif">
									
										@php
											$lang_name = strtolower($languagecode->name);
										@endphp
										
										<input type="hidden" name="local[{{$lang_name}}]" value="{{ $languagecode->is_default }}" >
										
										<input type="hidden" name="languagecode[{{$lang_name}}]" value="{{$languagecode->id}}">
										
											<div class="row">
												@if($i==1)
												<div class="col-md-6">
													<div class="form-group label-floating is-empty">
														<label for="" class="">@lang('messages.ads_type')</label>
														<select name="ad_type" id="AdsAdType" class="form-control" required>
															@foreach($optionsAr as $key=>$optionstype)
																<option value="{{$key}}" {{ old('ad_type') == $key ? 'selected' : '' }}>{{ $optionstype }}</option>
															@endforeach													
														</select>
														@error('ad_type')
															<span class="invalid-feedback" role="alert">
																<strong>{{ $message }}</strong>
															</span>
														@endif
													</div>
												</div>
												@endif
												<div class="col-md-6">
													<div class="form-group label-floating is-empty">
														<label for="title_{{$languagecode->name}}" class="">@lang('messages.title')</label>
														<input type="text" name="title[{{$lang_name}}]" value="{{ old('title.'.$lang_name) }}" class="form-control" maxlength="191" id="title_{{$languagecode->name}}" autocomplete="off" {{ $languagecode->is_default == 1 ? 'required' : '' }} autofocus >
														@if($errors->has('title.'.$lang_name))
															<span class="invalid-feedback" role="alert">
																@php
																	$title_error_message = str_replace('.', ' ', $errors->first('title.'.$lang_name));
																@endphp
																<strong>{{ $title_error_message }}</strong>
															</span>
														@endif
													</div>
												</div>
											</div>	
										
											
										<div class="row">
											
										</div>
										<div class="row">
											<div class="col-md-4" id="BannerImg_{{$lang_name}}">
												<div class="form-group label-floating">
													<label for="banner-image_{{$lang_name}}" class="">{{ __('messages.Banner image') }}</label>
													<input type="file" name="banner[{{$lang_name}}]" class="form-control slugclass" id="banner-image_{{$lang_name}}" onchange="return displayPreview(this.files,'banner')" accept="image/*" {{ $languagecode->is_default == 1 ? 'required' : '' }} >
													<p style="opacity: 0.4;">{{ __('messages.Image size should be 720x162') }}</p>
													@if($errors->has('url.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$url_error_message = str_replace('.', ' ', $errors->first('url.'.$lang_name));
															@endphp
															<strong>{{ $url_error_message }}</strong>
														</span>
													@endif
													@if($errors->has('banner.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$banner_error_message = str_replace('.', ' ', $errors->first('banner.'.$lang_name));
															@endphp
															<strong>{{ $banner_error_message }}</strong>
														</span>
													@endif
												</div>
											</div>
											
											<div class="col-md-4" id="FullWidthImg_{{$lang_name}}">
												<div class="form-group label-floating">
													<label for="fullwidth-image_{{$lang_name}}" class="">{{ __('messages.Full Width Image (iphone x Max)') }}</label>
													<input type="file" name="fullwidth_image[{{$lang_name}}]" class="form-control slugclass" id="fullwidth-image_{{$lang_name}}" onchange="return displayPreview(this.files,'fullwidth_image')" accept="image/*" {{ $languagecode->is_default == 1 ? 'required' : '' }} >
													<p style="opacity: 0.4;">{{ __('messages.Image size should be 750x1624') }}</p>
													@if($errors->has('url.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$url_error_message = str_replace('.', ' ', $errors->first('url.'.$lang_name));
															@endphp
															<strong>{{ $url_error_message }}</strong>
														</span>
													@endif
													@if($errors->has('fullwidth_image.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$fullwidth_image_error_message = str_replace('.', ' ', $errors->first('fullwidth_image.'.$lang_name));
															@endphp
															<strong>{{ $fullwidth_image_error_message }}</strong>
														</span>
													@endif
												</div>
											</div>
											<div class="col-md-4" id="FullWidthImgAndroid_{{$lang_name}}">
												<div class="form-group label-floating">
													<label for="android-fullwidth-image_{{$lang_name}}" class="">{{ __('messages.Full Width Image (iphone 8 size)') }}</label>
													<input type="file" name="android_fullwidth_image[{{$lang_name}}]" onchange="return displayPreview(this.files,'android_fullwidth_image')" class="form-control slugclass" id="android-fullwidth-image_{{$lang_name}}" accept="image/*" {{ $languagecode->is_default == 1 ? 'required' : '' }} >
													<p style="opacity: 0.4;">{{ __('messages.Image size should be 720x1280') }}</p>
													@error('android_fullwidth_image')
														<span class="invalid-feedback" role="alert">
															<strong>{{ $message }}</strong>
														</span>
													@enderror
													@if($errors->has('android_fullwidth_image.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$android_fullwidth_image_error_message = str_replace('.', ' ', $errors->first('android_fullwidth_image.'.$lang_name));
															@endphp
															<strong>{{ $android_fullwidth_image_error_message }}</strong>
														</span>
													@endif
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-md-6">
												<div class="form-group label-floating" style="margin-top: 5px;">
													<label class="">{{ __('messages.url') }}</label>
													<input type="url" class="form-control" name="url[{{$lang_name}}]" value="{{old('url.'.$lang_name) }}" id="url[{{$lang_name}}]" {{ $languagecode->is_default == 1 ? 'required' : '' }} autocomplete="off" >
													@if($errors->has('url.'.$lang_name))
														<span class="invalid-feedback" role="alert">
															@php
																$url_error_message = str_replace('.', ' ', $errors->first('url.'.$lang_name));
															@endphp
															<strong>{{ $url_error_message }}</strong>
														</span>
													@endif
												</div>
											</div>
										</div>
									</div>
									@endforeach
									
									<div class="row">
										<div class="col-md-7">
											<div class="form-group label-floating">
												@error('location')
													<span class="invalid-feedback" role="alert">
														<strong>{{ $message }}</strong>
													</span>
												@enderror
												<label class="">{{ __('messages.location') }}</label>
												<input type="text" class="form-control" name="location" value="{{old('location') }}" id="location" autocomplete="off" required="required" >
												<div id="map"></div>
											</div>
											<ul id="geoData" style="display:none;">
												<span id="location"></span>
												<span id="postal_code"></span>
												<span id="country"></span>
											</ul>
										</div>
										
										<div class="col-md-5">
											<div class="row">
												<div class="col-md-12">
													<div class="form-group label-floating">
														<label class="">{{ __('messages.latitude') }}</label>
														<input type="text" class="form-control" name="latitude" value="{{old('latitude') }}" id="latitude" readonly autocomplete="off" required="required" >
														@error('latitude')
															<span class="invalid-feedback" role="alert">
																<strong>{{ $message }}</strong>
															</span>
														@enderror
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="form-group label-floating" style="margin-top: 5px;">
														<label class="">{{ __('messages.longitude') }}</label>
														<input type="text" class="form-control" name="longitude" value="{{old('longitude') }}" id="longitude" readonly autocomplete="off" required="required" >
														@error('longitude')
															<span class="invalid-feedback" role="alert">
																<strong>{{ $message }}</strong>
															</span>
														@enderror
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="form-group label-floating" style="margin-top: 5px;">
														<label class="">{{ __('messages.Radius (KM)') }}</label>
														<input type="number" class="form-control" name="radius" value="{{old('radius') }}" id="radius" autocomplete="off" required="required" >
														@error('radius')
															<span class="invalid-feedback" role="alert">
																<strong>{{ $message }}</strong>
															</span>
														@enderror
													</div>
												</div>
											</div>
										</div>
									</div>									
									<div class="row">
										<div class="col-md-6">
											<div class="form-group label-floating">
												<label class="">{{ __('messages.start_date') }}</label>
												<input type="text" name="start_date" value="{{old('start_date') }}" class="form-control start-date" id="start-date" autocomplete="off" required="required" >
												@error('start_date')
													<span class="invalid-feedback" role="alert">
														<strong>{{ $message }}</strong>
													</span>
												@enderror
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group label-floating">
												<label class="">{{ __('messages.end_date') }}</label>
												<input type="text" name="end_date" value="{{old('end_date') }}" class="form-control end-date" id="end-date" autocomplete="off" required="required" >
												@error('end_date')
													<span class="invalid-feedback" role="alert">
														<strong>{{ $message }}</strong>
													</span>
												@enderror
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status') ? 'checked' : '' }}> @lang('messages.status')
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
									</div>	
								</div>
								<button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
								<div class="clearfix"></div>
							</form>
						</div>
					</div>                        
				</div>
			</div>
		</div>
	</div>
@endsection

@push('js')

<script>
	$(document).ready(function(){

		var addTYPE = $('#AdsAdType').val();
		if(addTYPE == 1){		
			$('#BannerImg_french').hide();
			$('#FullWidthImg_french').show();
			$('#FullWidthImgAndroid_french').show();
			$('#banner-image_french').removeAttr('required');
			$('#fullwidth-image_french').attr("required","required");
			$('#android-fullwidth-image_french').attr("required","required");
			
			$('#BannerImg_english').hide();			
			$('#FullWidthImg_english').show();
			$('#FullWidthImgAndroid_english').show();
			$('#banner-image_english').removeAttr('required');
			$('#fullwidth-image_english').attr("required","required");
			$('#android-fullwidth-image_english').attr("required","required");
		}
		else if(addTYPE == 2 || addTYPE == 3){		
			$('#BannerImg_french').show();
			$('#FullWidthImg_french').hide();
			$('#FullWidthImgAndroid_french').hide();
			$('#banner-image_french').attr("required","required");
			$('#fullwidth-image_french').removeAttr('required');
			$('#android-fullwidth-image_french').removeAttr('required');
			
			$('#BannerImg_english').show();
			$('#FullWidthImg_english').hide();
			$('#FullWidthImgAndroid_english').hide();
			$('#banner-image_english').attr("required","required");
			$('#fullwidth-image_english').removeAttr('required');
			$('#android-fullwidth-image_english').removeAttr('required');
		}

		$('#AdsAdType').change(function(){
			var addType = $(this).val();
			
			if(addType == 1){			
				$('#BannerImg_french').hide();
				$('#FullWidthImg_french').show();
				$('#FullWidthImgAndroid_french').show();
				$('#banner-image_french').removeAttr('required');
				$('#fullwidth-image_french').attr("required","required");
				$('#android-fullwidth-image_french').attr("required","required");
				
				$('#BannerImg_english').hide();			
				$('#FullWidthImg_english').show();
				$('#FullWidthImgAndroid_english').show();
				$('#banner-image_english').removeAttr('required');
				$('#fullwidth-image_english').attr("required","required");
				$('#android-fullwidth-image_english').attr("required","required");
			}
			else if(addType == 2 || addType == 3){			
				$('#BannerImg_french').show();
				$('#FullWidthImg_french').hide();
				$('#FullWidthImgAndroid_french').hide();
				$('#banner-image_french').attr("required","required");
				$('#fullwidth-image_french').removeAttr('required');
				$('#android-fullwidth-image_french').removeAttr('required');
				
				$('#BannerImg_english').show();
				$('#FullWidthImg_english').hide();
				$('#FullWidthImgAndroid_english').hide();
				$('#banner-image_english').attr("required","required");
				$('#fullwidth-image_english').removeAttr('required');
				$('#android-fullwidth-image_english').removeAttr('required');
			}

		});
	});

	var _URL = window.URL || window.webkitURL;
	function displayPreview(files,filtype) 
	{   
	
	   var file = files[0];
	   
	   var field_name;
	   var field_id;
	   var img_width;
	   var img_height;
	   
	   var type = files[0].type; 
	   var type_reg = /^image\/(jpg|png|jpeg)$/;
	   
	   var img = new Image();   
	   var sizeKB = file.size / 1024;
	   switch (filtype) {
			case 'banner':
				field_name = "banner";
				field_id = "banner";
				img_width = 720;
				img_height = 162;
				break;
			case 'fullwidth_image':
				field_name = "fullwidth-image";
				field_id = "fullwidth-image";
				img_width = 750;
				img_height = 1624;
				break;
			case 'android_fullwidth_image':
				field_name = "android-fullwidth-image";
				field_id = "android-fullwidth-image";
				img_width = 720;
				img_height = 1280;
				break;
		}
				
	   if (type_reg.test(type)) 
	   {   
		  img.onload = function() {	
		  if(img.width == img_width && img.height == img_height)
				{

				}
				else
				{
				$('#'+field_id).val(''); 					
				alert("L’image sélectionnée n’est pas au bon format.");
				return false;
				}
		   }
	   }
	   else
	   {
		 $('#'+field_id).val(''); 
		 alert("L’image sélectionnée n’est pas au bon format.");		 
		 return false;
	   }
	   img.src = _URL.createObjectURL(file);
	}
	
	function initMap() {
		var map = new google.maps.Map(document.getElementById('map'), {
		  center: {lat: -33.8688, lng: 151.2195},
		  zoom: 13
		});
		var input = document.getElementById('location');
		map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

		var autocomplete = new google.maps.places.Autocomplete(input);
		autocomplete.bindTo('bounds', map);

		var infowindow = new google.maps.InfoWindow();
		var marker = new google.maps.Marker({
			map: map,
			anchorPoint: new google.maps.Point(0, -29)
		});

		autocomplete.addListener('place_changed', function() {
			infowindow.close();
			marker.setVisible(false);
			var place = autocomplete.getPlace();
			if (!place.geometry) {
				window.alert("Autocomplete's returned place contains no geometry");
				return;
			}
	  
			// If the place has a geometry, then present it on a map.
			if (place.geometry.viewport) {
				map.fitBounds(place.geometry.viewport);
			} else {
				map.setCenter(place.geometry.location);
				map.setZoom(17);
			}
			marker.setIcon(({
				url: place.icon,
				size: new google.maps.Size(71, 71),
				origin: new google.maps.Point(0, 0),
				anchor: new google.maps.Point(17, 34),
				scaledSize: new google.maps.Size(35, 35)
			}));
			marker.setPosition(place.geometry.location);
			marker.setVisible(true);
		
			var address = '';
			if (place.address_components) {
				address = [
				  (place.address_components[0] && place.address_components[0].short_name || ''),
				  (place.address_components[1] && place.address_components[1].short_name || ''),
				  (place.address_components[2] && place.address_components[2].short_name || '')
				].join(' ');
			}
		
			infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
			infowindow.open(map, marker);
		  
			//Location details
			for (var i = 0; i < place.address_components.length; i++) {
				if(place.address_components[i].types[0] == 'postal_code'){
					document.getElementById('postal_code').innerHTML = place.address_components[i].long_name;
				}
				if(place.address_components[i].types[0] == 'country'){
					document.getElementById('country').innerHTML = place.address_components[i].long_name;
				}
			}
			document.getElementById('location').value = place.formatted_address;
			document.getElementById('latitude').value = place.geometry.location.lat();
			document.getElementById('longitude').value = place.geometry.location.lng();
		});
	}
</script>
	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- Language script -->
<script type="text/javascript" src="{{ asset('content/assets/back-end/jquery-ui-master/ui/i18n/datepicker-fr.js') }}"></script>
<script>
	$(function() {
		$(".start-date, .end-date").datepicker({
			dateFormat: "dd/mm/yy",
			changeYear: true,
			changeMonth: true 
		});

		// Initialize and change language to France
		$('.start-date, .end-date').datepicker($.datepicker.regional["fr"]);
	});
</script>
@endpush
