@extends('admin.layouts.app')
@section('title', 'Ads')
@section('content')
            
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <!-- alert messages -->
                        @include('admin.layouts.flash-message')
                        <!-- End alert messages -->

                        <div class="card">
                            <div class="card-header card-header-primary">
                                <a href="{{route('create_new_ad')}}" title="@lang('messages.add_ads')" class="btn btn-add pull-right"><i class="material-icons">add_circle</i> @lang('messages.add_ads')<div class="ripple-container"></div></a>
                                <h4 class="card-title"><i class="material-icons iconset">announcement</i> @lang('messages.list_ads')</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class=" text-primary">
                                            <th>@lang('messages.ads_type')</th>
                                            <th>@lang('messages.title')</th>
                                            <th>@lang('messages.start_date')</th>
                                            <th>@lang('messages.end_date')</th>
                                            <th>@lang('messages.ads_location')</th>
                                            <th>@lang('messages.radius')</th>
                                            <th>@lang('messages.status')</th>
                                            <th class="text-right">Actions</th>
                                        </thead>
                                        <tbody>
                                            @forelse($ads as $ad)
                                            <tr>
                                                <td>
												{{ $ad->ad_type == 1 ? __('messages.splashscreen') : __('messages.banner') }}
												</td>
                                                <td>{{$ad->title}}</td>
                                                <td>{{ Helper::dateformatDmy($ad->start_date) }}</td>
                                                <td>{{ Helper::dateformatDmy($ad->end_date) }}</td>
                                                <td>{{$ad->location}}</td>
                                                <td>{{$ad->radius}}</td>
                                                <td>
                                                    <a id="atag{{$ad->id}}" class="btn btn-{{ $ad->status == 1 ? 'success' : 'danger' }}" data-id="{{$ad->id}}" data-status="{{$ad->status}}" href="javascript:void(0)" onclick="updateadStatus(this)">
                                                        {{ $ad->status == 1 ? __('messages.statusactive') : __('messages.statusinactive') }}
                                                    </a>
                                                </td>
                                                <td class="text-right">
                                                    <a href="{{route('edit_ad', $ad->id)}}" class="btn btn-warning"><i class="material-icons">border_color</i> MODIFIER<div class="ripple-container"></div></a>
                                                    <a href="{{ route('delete_ads', $ad->ad_id) }}" class="btn btn-danger" onclick="return confirm('{{ __('messages.are_you_sure_want_to_delete') }}')"><i class="material-icons">clear</i> SUPPRIMER</a>
                                                </td>
                                            </tr>
                                            @empty
                                            <tr>
                                                <td colspan="6" class="text-center">@lang('messages.data_not_found')</td>
                                            </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection

