@extends('admin.layouts.app')
@section('title', 'Edit Actualiites')
@push('css')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<style type="text/css">
   .invalid-feedback{
   display: block !important;
   }
   #map {
   width: 100%;
   height: 295px;
   margin-top:10px;
   }
   #location{
   z-index: 999;
   position: relative;
   left: 0px !important;
   top: 0px;
   width: 100% !important;
   border: 1px solid #ccc;
   background: #fff;
   padding:4px;
   }
   .gmnoprint{
   margin-top: 33px !important;
   }
   #AdsSelectImageType{
   width:100%;
   }
   .form-group input[type=file] {
   opacity: 1 !important;
   position: inherit !important;
   top: 0px;
   right: 0;
   bottom: 0;
   left: 0;
   width: 100%;
   height: 100%;
   z-index: 100;
   }
   #ui-datepicker-div{
   z-index : 9999999 !important;	
   }		
   .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
   float: left;
   }
</style>
<link rel="stylesheet" type="text/css" href="{{ asset('content/assets/back-end/css/style.css') }}" />
@endpush
@section('content')
<div class="content">
<div class="container-fluid">
   <div class="row">
      <div class="col-md-12">
         <!-- alert messages -->
         @include('admin.layouts.flash-message')
         <!-- End alert messages -->
         <div class="card">
            <div class="card-header card-header-primary">
               <a href="{{route('actualites')}}" class="btn btn-add pull-right">
                  <i class="material-icons">reply</i> @lang('messages.back')
                  <div class="ripple-container"></div>
               </a>
               <h4 class="card-title"><i class="material-icons iconset">add_to_photos</i> @lang('messages.edit_actualites')</h4>
            </div>
            <div class="card-body">
               <!-- Language tabs -->
              
			  
               <form method="post" action="{{route('update_actualites', $Actualites->id)}}" enctype="multipart/form-data">
                 
                  @csrf
                  {{ method_field('PUT') }}
                  <div class="tab-content">
																	
									<div class="row">
										
										<div class="col-md-6">
											<div class="form-group label-floating is-empty">
												<label for="title" class="">@lang('messages.title')</label>
												<input type="text" name="title" value="{{ old('title',$Actualites->title) }}" class="form-control" maxlength="191" id="title" autocomplete="off" required >
												@if($errors->has('title'))
													<span class="invalid-feedback" role="alert">
														@php
															$title_error_message = str_replace('.', ' ', $errors->first('title'));
														@endphp
														<strong>{{ $title_error_message }}</strong>
													</span>
												@endif
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group label-floating is-empty">
												<label for="title" class="">@lang('messages.description')</label>
												<textarea name="subtitle" class="form-control" id="title" autocomplete="off" required> {{ old('subtitle',$Actualites->description) }} </textarea>
												@if($errors->has('subtitle'))
													<span class="invalid-feedback" role="alert">
														@php
															$title_error_message = str_replace('.', ' ', $errors->first('subtitle'));
														@endphp
														<strong>{{ $title_error_message }}</strong>
													</span>
												@endif
											</div>
										</div>
									</div>	
								   @php
									$slide_image = asset('content/img/image-placeholder.png');
									
									if(!empty($Actualites->image) && File::exists('application/public/uploads/actualites/'.$Actualites->image)){

									$slide_image = url('application/public/uploads/actualites/'.$Actualites->image);
									
									}													
									@endphp
									<div class="row">
										
										<div class="col-md-6" id="image_container">
											<div class="form-group label-floating">
												<label for="slide_image" class="">{{ __('messages.banner_image') }}</label>
													<br>
													<span class="btn btn-primary custom-file-upload default btn-file">
														<span class="fileinput-new"><i class="fa fa-upload"></i> @lang('messages.select_image') </span>
														<span class="fileinput-exists"><i class="fa fa-upload"></i> @lang('messages.edit_image') </span>
														<input type="file" name="slide_image" id="fileToUpload" onchange="return fileValidation()" accept="image/*" style="display:none">
										                <input type="hidden" value="{{ $Actualites->image}}" name="previous_slide_image" id="previous_image_file">
													</span>
														<a href="javascript:;" class="btn red clear-file-btn" onclick="ClearMediaFile()" data-dismiss="fileinput"><i class="fa fa-trash"></i> @lang('messages.remove') </a>
														<br>
														<small style="color:red;padding-top:2px;" id="UploadFileError"></small>
												</div>
												<div class="thumbnail" id="" style="width: 100%; height: auto;">
												  <img src="{{$slide_image}}" alt="" style="width: 100px;" id="ImagePreview">
												</div>
										      <br>
										</div>
										

										<div class="col-md-6">
											<div class="form-group label-floating">
												<label class="control-label">@lang('messages.link')</label>
												<div class="input text">
													<label for="secondary-color"></label>
													<input type="url" name="link" class="form-control titleclass" value="{{ old('subtitle',$Actualites->link) }}">
												</div>
												<span class="material-input"></span>
												@error('link')
												<span class="invalid-feedback" role="alert">
												<strong>{{ $message }}</strong>
												</span>
												@enderror
											</div>
										</div>
							
									</div>
																
									<div class="row">
										<div class="col-md-12">
											<div class="form-check form-check-inline">
												<label class="form-check-label">
													<input class="form-check-input" type="checkbox" name="status" value="1" {{ old('status',$Actualites->status) ? 'checked' : '' }}> @lang('messages.status')
													<span class="form-check-sign">
														<span class="check"></span>
													</span>
												</label>
											</div>
										</div>
									</div>	
								</div>
								<button type="submit" class="btn btn-primary pull-right">@lang('messages.save')</button>
								<div class="clearfix"></div>

                  
               </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@push('js')
<script></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- Language script -->
<script type="text/javascript" src="{{ asset('content/assets/back-end/jquery-ui-master/ui/i18n/datepicker-fr.js') }}"></script>
<script type="text/javascript" src="{{asset('content/assets/js/jscolor.js')}}"></script>

<script>
    $(document).ready(function(){
      var pdf_validation_msg="{{ trans('messages.pdf_validation_msg') }}";
      var file_size_validation="{{ trans('messages.file_size_validation') }}";
      var image_validation_msg="{{ trans('messages.image_validation_msg') }}";
	
      <?php 
         if(!empty($Actualites->image)){
      ?>
      $('.fileinput-new').hide();
      $('.fileinput-exists').show();
		$('.clear-file-btn').show();
      <?php
         }else{
      ?>
      $('.fileinput-exists').hide();
		$('.clear-file-btn').hide();
      $('.fileinput-new').show();
      <?php
         }
      ?>
		
		$('.fileinput-new').click(function(){
			$('#fileToUpload').click();
		});
		$('.fileinput-exists').click(function(){
			$('#fileToUpload').click();
		});

	});
    function getFileExt(filename){
       return /[^.]+$/.exec(filename);
    }
   
    function FileSizeValidation(){ 
        
        const fi = document.getElementById('fileToUpload'); 
        if (fi.files.length > 0) { 
            for (const i = 0; i <= fi.files.length - 1; i++) { 
                const fsize = fi.files.item(i).size; 
                const file = Math.round((fsize / 1024)); 
                if (file >= 2048) { 
                  $('#UploadFileError').html(file_size_validation);
			         $('.fileinput-exists').hide();
		            $('.fileinput-new').show(); 
				      $('.clear-file-btn').hide();
                  $('#ImagePreview').attr('src',"{{asset('content/img/image-placeholder.png')}}");
				  return false;
                }else{ 
                  $('#UploadFileError').html("");
                  $('.fileinput-exists').show();
                  $('.clear-file-btn').show();
		            $('.fileinput-new').hide();
                  return true; 
                } 
            } 
        }
    }
    
    function fileValidation() { 
        var fileInput = document.getElementById('fileToUpload'); 
          
        var filePath = fileInput.value; 
      
        var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i; 
          
        if (!allowedExtensions.exec(filePath)) { 
            $('#UploadFileError').html(image_validation_msg); 
            fileInput.value = ''; 
			   $('.fileinput-exists').hide();
		      $('.fileinput-new').show();
			   $('.clear-file-btn').hide();
            $('#ImagePreview').attr('src',"{{asset('content/img/image-placeholder.png')}}");
            return false; 
        }  
        else  
        { 
           if (fileInput.files && fileInput.files[0]) { 
                var reader = new FileReader(); 
                reader.onload = function(e) { 
					   $('.fileinput-exists').show();
		            $('.fileinput-new').hide();
					   $('.clear-file-btn').show(); 
                  $('#ImagePreview').attr('src',e.target.result);
                }; 
                  
                reader.readAsDataURL(fileInput.files[0]);
                $('#UploadFileError').html('');
                
            } 
        } 
    }
    
    function ClearMediaFile(){
         $('#fileToUpload').val('');
         $('#UploadFileError').html('');
         $('.fileinput-exists').hide();
         $('.fileinput-new').show();
         $('.clear-file-btn').hide();
         $('#ImagePreview').attr('src',"{{asset('content/img/image-placeholder.png')}}");
         $('#previous_image_file').val('');
    }
</script>
@endpush