<?php

return [

    'user_status_update' => "Le statut de l'utilisateur a été mis à jour avec succès.",
    'user_detail_not' => 'Détails utilisateur non trouvés.',
    'change_status' => 'Voulez-vous vraiment changer de statut?',
    'data_not_found' => 'Données non trouvées.',
    'page_not_found' => 'Page non trouvée.',

    //Admin Dashboard
    'new_users' => 'Nouveaux utilisateurs',
    'list_of_last_registered_users' => 'Liste des derniers utilisateurs inscris.',

    //Side nav bar
    'dashboard' => 'Tableau de bord',
    'users' => 'Utilisateurs',
    'language' => 'Langues',
    'cms_management' => 'Pages CMS',
    'notifications' => 'Notifications',
    'settings' => 'Paramètres',
    "email_templates" => "Modèles d'emails",
    "social_links" => "Liens sociaux",
	"restaturents" => "Restaurants",
	"providers" => "Fournisseurs",
    //Side nav bar end


    'login' => 'Connexion',

    'my_search' => 'MA RECHERCHE',

    'gender' => 'Sexe',

    'man' => 'Homme',

    'women' => 'Femme',

    'genre' => 'Genre',

    'password' => 'Mot de passe',

    'forgot_password' => 'Mot de passe oublié ?',

    'reset_my_password' => 'Reinnitialiser mon mot de passe',

    'Back to the login' => 'Retour à la page de connexion',

    'reset_password' => 'Réinitialiser le mot de passe',

    'profile' => 'Profil',

    'addusers' => 'Ajouter des utilisateurs',

    'first_name' => 'Prénom',

    'name' => 'Nom',

    'email' => 'Email',

    'status' => 'Statut',

    'action' => 'Actions',

    'dob' => 'Date de naissance',

    'date_of_birth' => 'Date de naissance',

    'position' => 'Titre du poste',

    'training' => 'Formation',

    'about_me' => 'À propos de moi',

    'telephone' => 'Téléphone',

    'logout' => 'Se déconnecter',

    'change_password' => 'Modifier mon mot de passe',

    'edit_profile' => 'Editer mon profil',

    'old_password' => 'Ancien mot de passe',

    'new_password' => 'Nouveau mot de passe',

    'confirm_password' => 'Confirmez le mot de passe',

    'profile_image' => 'Image de profil',

    'add_new_user' => 'Nouvel utilisateur',

    'edit_user' => 'Modifier l\'utilisateur',

    'back' => 'Retour',

    'valider' => 'Valider',

    'update' => 'Mise à jour',

    'view_users' => 'Afficher les utilisateurs',
	'view_restaurants' => 'Afficher les restaurants',
	'view_providers' => 'Afficher les fournisseurs',

    'categories' => 'Catégories',

    'new_register_users_from_app' => 'Nouveaux utilisateurs',

    'title' => 'Titre',

    'created' => 'Inscription le',
    
    'modified' => 'Modified',
    'view_notification' => 'Voir la notification',

    'number_of_person' => 'Nombre de personnes',

    'please_enter_your_email_address' => 'Veuillez entrer votre adresse e-mail',

    'email_already_exists' => 'L\'email existe déjà',

    'these_files_extension_are_allowed' => 'L\'extension de ces fichiers est autorisée',

    'invalid_username_or_password' => 'Nom d\'utilisateur ou mot de passe invalide, veuillez réessayez s\'il vous plait',
    
    'not_allowed_to_sign_in' => 'Vous n\'êtes pas autorisé à vous connecter, veuillez essayez à nouveau s\'il vous plait',
    
    'profile_updated' => 'Votre profil a été mis a jour',
    
    'unable_update_profile' => 'Impossible de mettre à jour votre profil, veuillez réessayez s\'il vous plait',
    
    'reset_sent_email_password' => 'Un nouveau mot de passe a été envoyé dans votre boite mail',
    
    'email_no_exists' => 'Merci de fournir une adresse e-mail inexistante',
    
    'reset_password_link_not_valid' => 'Ce lien est invalide, veuillez réessayez s\'il vous plait',
    
    'the_password_is_successfully_changed' => 'Le mot de passe a été modifié avec succès',
    
    'user_has_been_successfully_added' => 'L\'utilisateur a été ajouté avec succès',
    
    'user_has_been_updated' => 'L\'utilisateur a été mis à jour',
    
    'user_successfully_deleted' => 'Utilisateur supprimé avec succès',
    
    'unable_to_delete_user' => 'Impossible de supprimer l\'utilisateur, veuillez réessayez s\'il vous plait',
    
    'user_account_status_now_update' =>  "Statut mis à mis à jour",
    
    'category_has_been_successfully_added' =>  "La catégorie a été ajoutée avec succès",
    
    'category_has_been_updated' =>  "Votre catégorie a été mise à jour",
    
    'unable_to_update_your_category' =>  "Impossible de mettre à jour votre catégorie",
    
    'order_changed_successfully' =>  "Impossible de mettre à jour votre catégorie",

    'the_category_has_been_deleted' =>  "La catégorie a été supprimée",
    
    'unable_to_delete_category' =>  "Impossible de supprimer la catégorie",
    
    'category_status_now_update' =>  "Statut mis à jour avec succès",
    
    'your_page_has_been_updated' =>  "Votre page a été mise à jour",
    
    'unable_to_update_your_page' =>  "Impossible de mettre à jour votre page",
    
    'page_successfully_deleted' =>  "Page supprimée avec succès",
    
    'unable_to_delete_page' =>  "Impossible de supprimer la page",

    'page_status_now_update' =>  "État de la page maintenant mis à jour",

    'your_setting_has_been_updated' =>  "Vos paramètres ont bien été mis à jour",

    'statusactive' =>  "Actif",
    
    'statusinactive' =>  "Inactif",
	
	'active' =>  "ACTIVÉ",
    
    'inactive' =>  "DÉSACTIVÉ",
	
	'all_active' =>  "Toutes ACTIVÉ",
    
    'all_inactive' =>  "Toutes DÉSACTIVÉ",
	
	'all_status' =>  "Toutes",
    
    'listcategories' =>  "Liste des catégories",

    'addcategory' => "Ajouter une catégorie",
    
    'editcategory' =>  "Modifier la catégorie",

    'back' =>  "Retour",
    
    'are_you_sure_want_to_delete' =>  "Êtes-vous sûr de vouloir supprimer cela?",

    'delete' =>  "Effacer",

    'edit' =>  "Modifier",

    'up' =>  "Vers le haut",

    'down' =>  "Vers le bas",

    'category' =>  "Catégorie",
	'choose_category' =>  "Choisissez une catégorie",
    
    'location' =>  "Localisation",

    'description' =>  "Description",

    'postcode' => "Code postal",

    'full_address' => "Adresse complète",

    'add_more_ticket_type' => "Ajouter un nouveau type de billet",

    'select_category' => "Choisir une catégorie",

    'something_error_please_try_again' => "Une erreur c'est produite, veuillez réessayer.",

    'cms_page_listing' => "Pages CMS",

    'content' => "Contenu",

    'edit_page' => "Modifier la page",

    'list_notifications' =>  "Historique des notifications",
    
    'add_notification' => "Envoyer une notification",

    'Notification receive users' => 'Destinataires',

    'send_to' => "Envoyer à",

    'message' => "Message",

    'link' => "Lien",

    'address' =>  "Localisation",

    'localisation' => "Localisation",

    'total_users' => "Nombre total d'utilisateurs",

    'select_user_type' => "Choisissez le type d'utilisateur",

    'find_user' => "Trouver un utilisateur",

    'select_user' => "Sélectionnez un utilisateur",

    'send_notification' => "Envoyer une notification",

    'user_not_found' => "Utilisateur non trouvé!",

    'all_app_users' => "Tous les utilisateurs",

    'send_to_selected_user' => "Envoyer aux utilisateurs suivant",

    'add_new_notification' => "Ajouter une nouvelle notification",

    'view_notification' => "Afficher la notification",

    'posted' => "Envoyer",

    'facebook_url' => "Adresse URL de la page Facebook",

    'snapchat_url' => "Adresse URL de votre profil Snapchat",

    'here_you_can_add_your_snapchat_url' => "Ici vous pouvez ajouter votre url Snapchat",

    'site_name' => "Nom de l'application",

    'you_can_make_changes_in_site_name_by_using_this_value' => "Vous pouvez modifier le nom de l'application en utilisant cette valeur.",

    'site_url' => "Adresse URL de votre site internet",

    'here_you_can_manage_your_website_url' => "Ici, vous pouvez gérer l'url de votre site Web",

    'admin_email' => "Email administrateur",

    'you_can_make_changes_in_admin_email_address_by_using_this_value' => "Adresse électronique de l'administrateur de l'application",

    'contact_us_email' => "Contactez nous",

    'you_can_make_changes_in_admin_contact_us_email_address_by_using_this_value' => "Adresse électronique de contact de l'application",

    'support_email' => "Email de support",

    'here_you_can_manage_your_support_email' => "Adresse électronique de support de l'application",


    //10-12-19
    "from_email" => "Expéditeur email",

    "here_you_can_manage_your_from_email" => "Nom de l'expediteur des emails",

    "report_a_bug_email" => "Email des rapport",

    "here_you_can_manage_the_report_email" => "Adresse électronique des signalement de l'application",

    "contact_us_email" => "Nous contacter",

    "here_you_can_manage_the_contact_us_email" => "Ici, vous pouvez gérer le courriel Contactez-nous",

    "force_users_to_update_android_app" => "Forcer les utilisateurs à mettre à jour l'application Android",

    "here_you_can_force_users_to_update_android_app" => "Vous pouvez forcer les utilisateurs à mettre à jour l'application Android",

    "android_app_version" => "Version de l'application Android",

    "here_you_can_manage_the_latest_android_app_version" => "Vous pouvez gérer la dernière version de l'application Android",

    "force_users_to_update_ios_app" => "Forcer les utilisateurs à mettre à jour l'application iOS",

    "here_you_can_force_users_to_update_ios_app" => "Vous pouvez forcer les utilisateurs à mettre à jour l'application ios",

    "latest_ios_app_version" => "Dernière version de l'application iOS",

    "here_you_can_manage_the_latest_ios_app_version" => "Vous pouvez gérer la dernière version de l'application ios",

    "notify_users_of_a_new_update" => "Avertir les utilisateurs d'une nouvelle mise à jour.",

    "here_you_can_notify_users_of_a_new_update" => "Ici, vous pouvez informer les utilisateurs d'une nouvelle mise à jour.",

    "please_select_category" => "Veuillez sélectionner une catégorie",

    "something_worng" => "Quelque chose ne va pas, veuillez réessayez s'il vous plait",

    "notification_added" => "La notification a été envoyée avec succès",

    "notification_updated" => "Votre notification a été prise en compte",

    "notification_deleted" => "La notification a été supprimée",

    "unable_notification_deleted" => "Impossible de supprimer la notification",

    "general_settings" => "Réglages généraux",

    "edit_email_template" => "Modifier le modèle de courrier électronique",

    "subject" => "Sujet",

    "sender_name" => "Nom de l'expéditeur",

    "support_email" => "Email de support",

    "contact_email" => "Email du contact",

    "main_color" => "Couleur principale",

    "secondary_color" => "Couleur secondaire",

    "header_image" => "Image d'en-tête",

    "white_logo" => "Logo blanc",

    "email_templates_updated" => "Vos modèles de courrier électronique ont été mis à jour",

    "unable_update_email_template" => "Impossible de mettre à jour votre modèle de courrier électronique",

    "edit_image" => "Modifier l’image",

    //Socail links
    "web_url" => "URL Web",
    "facebook_link" => "Lien Facebook",
    "instagram_link" => "Lien Instagram",
    "twitter_link" => "Lien Twitter",
    "linkedin" => "Lien LinkedIn",
    "snapchat" => "Lien Snapchat",
	"suggest_an_idea" => "Suggérer une idée",
	"tiktok_link" => "Lien TikTok",
    "social_links_updated" => "Les liens sociaux ont été mis à jour.",
    //End socail links language

    "registration_date" => "Date d'inscription",

    "admin_profile_update" => "Votre profil a été mis a jour.",


    //CMS page status
    "page_status" => "État de la page maintenant mis à jour",

    //Notification Create
    "save_notification" => "La notification a été ajoutée avec succès.",


    //General setting form validation message
    'This field is required' => 'Ce champ est requis.',


    'are_you_sure_want_to_delete' => 'Êtes-vous sûr de vouloir supprimer cela?',


    //language code
    'code' => 'Code',
    'add_language' => 'Ajouter une langue',
    'edit_language' => 'Modifier la langue',
    'create_new_language' => 'Nouveau code de langue ajouté avec succès.',
    'update_language' => 'Le code de langue a été mis à jour avec succès.',
    'delete_language' => 'Le code de langue a bien été supprimé.',
    'The selected language code does not exist' => 'Le code de langue sélectionné n\'existe pas.',
	'update_language_status' => 'La langue par défaut a été définie avec succès.',
	'set_detault_language' => 'PRINCIPALE',

    //Email templates
    'add_new_template' => 'Ajouter un modèle',

    //Error message
    'oops' => 'oups quelque chose s\'est mal passé, veuillez réessayer',

    //save new record
    'save' => 'Enregistrer',

    //Managers
    'manager' => 'Manager',
    'managers' => 'Directrice',
    'add_manager' => 'Ajouter un gestionnaire',
    'edit_manager' => 'Edit Manager',
    'New Manager Created Successfully' => 'Nouveau gestionnaire créé avec succès.',
    'Manager Updated Successfully' => 'Gestionnaire mis à jour avec succès.',
	'manager_deleted_successfully' => 'Le gestionnaire a bien été supprimé.',

    //site_permissions
    'site_permissions' => 'Autorisations de site',
    'add_site_permission' => 'Ajouter une autorisation de site',
    'edit_site_permission' => 'Modifier l\'autorisation du site',
    'role' => 'Rôle',
    'permission_for' => 'Autorisation',
    'is_read' => 'Voir',
    'is_add' => 'Ajouter',
    'is_edit' => 'Modifier',
    'is_delete' => 'Supprimer',
    'yes' => 'Oui',
    'no' => 'Non',
    'selectrole' => 'Sélectionnez un rôle',
    'selectmanager' => 'Sélectionnez Manager',
    'view_data' => 'Vue', 
    'add_data' => 'Ajouter', 
    'edit_data' => 'Éditer', 
    'delete_data' => 'Supprimer',
	'site_permission_already_exits' => 'L\'autorisation de site existe déjà. avec ce rôle et manager',
	'new_site_permission_created_successfully' => 'Nouvelle autorisation de site créée avec succès.',
	'site_permission_updated_successfully' => 'L\'autorisation du site a été mise à jour avec succès.',
	'site_permissions_deleted_successfully' => 'Les autorisations du site ont bien été supprimées.',
	
    //General setting
    'contact_email_address' => 'Adresse e-mail de contact',
    'add_the_main_contact_email_for_the_app' => 'Ajouter l’e-mail de contact principal de l’application.',
    'support_email_address' => 'Adresse e-mail de support',
    'add_the_application_customer_support_email' => 'Ajouter l’e-mail du support client de l’application.',
    'email_address_of_reports' => 'Adresse e-mail des rapports',
    'add_the_email_recipient_of_the_application_reports' => 'Ajouter l’e-mail destinataire des signalements de l’application.',
    'sending_email_address' => 'Adresse e-mail d’envoi',
    'add_the_email_sender_of_the_emails_to_the_application' => 'Ajouter l’e-mail expéditeur des e-mails l’application.',
	'login_background_image' => 'Image de fond',
	'add_the_login_background_cover_image' => 'Modifier ici l\'image de fond de la page de connexion.',
	'site_logo' => 'Logo',
	'add_the_site_logo' => 'Modifier ici le logo du back-office de l\'application.',
	'stripe_payment_status' => 'Mode de paiement Stripe',
	'here_you_can_manage_the_stripe_payment_status' => 'Vous pouvez modifier ici la mise en production des paiements Stripe.',
	'stripe_publishable_api_key' => "[Production] Clé API publique Stripe",
	'here_you_can_manage_the_stripe_publishable_api_key' => "Vous pouvez modifier ici la clé API publique Stripe (Mode production).",
	'stripe_secret_api_key' => "[Production] Clé API secrète Stripe",
	'here_you_can_manage_the_stripe_secret_api_key' => "Vous pouvez modifier ici la clé API secrète Stripe (Mode production).",
	'stripe_test_publishable_api_key' => "[Test] Clé API publique Stripe",
	'here_you_can_manage_the_stripe_test_publishable_api_key' => "Vous pouvez modifier ici la clé API publique Stripe (Mode test).",
	'stripe_test_secret_api_key' => "[Test] Clé API secrète Stripe",
	'here_you_can_manage_the_stripe_test_secret_api_key' => "Vous pouvez modifier ici la clé API secrète Stripe (Mode test).",
	'price_for_restaurant' => 'Prix pour le restaurant',
	'here_you_can_manage_the_price_for_restaurant' => "Ici, vous pouvez gérer le prix du restaurant.",
	'price_for_provider' => 'Prix fournisseur',
	'here_you_can_manage_the_price_for_provider' => "Ici, vous pouvez gérer le prix du fournisseur.",

    //Email templates
    'selectimage' => 'Sélectionnez l\'image',
    'remove' => 'Retirer',
    'No' => 'Non',
    'image' => 'image',

    //datatable pagination
    'Pre' => 'Précédent',
    'Next' => 'Suivant',
    'No data available' => 'Pas de données disponibles',
    'Processing' => 'En traitement',
    'No matching records found' => 'Aucun enregistrements correspondants trouvés',
    'Search' => 'Rechercher',

    //words list
    'word_list' => 'Word list',
    'listwords' => 'Liste des mots',
    'addword' => 'Ajouter un mot',
    'Key Name' => 'Nom clé',
    'Key Value' => 'Valeur clé',
    'Language Code' => 'Code de langue',
    'Edit Word' => 'Modifier le mot',
    'word_list_status_updated_successfully' => 'L\'état de la liste de mots a été mis à jour avec succès.',
    'word_list_deleted' => 'La liste de mots a bien été supprimée.',
    'word_detail_update' => 'Les détails de Word ont été mis à jour avec succès.',
    'new_word_detail_add' => 'Nouveau mot créé avec succès.',
    
    //Newsletters
    'newsletter' => 'Newsletter',
    'newsletters' => 'Newsletters',
	'create_new_newsletter' => 'Envoyer une newsletter',
    'username' => 'Nom d\'utilisateur',
    'profileimage' => 'Image de profil',
    'numberofusernotsend' => 'Nombre d\'utilisateurs non envoyés',
    'numberofusersent' => 'Nombre d\'utilisateurs envoyés',
    'send_newsletter' => 'Envoyer la newsletter',
    'user_list' => 'Destinataires',
    'statuts' => 'Statuts',
    'news_created_at' => 'Envoyée le',
    'news_subject' => 'Sujet',
	'newsletter_send_successfully' => 'Newsletter envoyée avec succès.',
	'email_sent_successfully' => 'E-mail envoyé avec succès.',
	'send_test_email' => 'Envoyer un test',
	
	//Send Test Email
	'Test email sended successfully' => 'L\'e-mail de test a été envoyé avec succès.',
	
	//Notificationtext
	'Notificationtext' => 'Notifications',
	'add_notification_text' => 'Ajouter une notification',
	'notificationtext_created_successfully' => 'Notification créée avec succès.',
	'notificationtext_updated_successfully' => 'Notification mise à jour avec succès.',
	'notificationtext_deleted_successfully' => 'Notification supprimée avec succès.',
	'manage_notification_text' => 'Modèles de notifications',
	'notification_text_added' => 'Créée le',
	//Status
	'status_updated_successfully' => 'Statut mis à jour avec succès.',
    //
	'user_has_been_successfully_deleted' => 'L\'utilisateur a été supprimé avec succès.',
	'user_image_has_been_successfully_deleted' => 'L\'image utilisateur a été supprimée avec succès.',
	
	'notification_sent_successfully' => 'Notification envoyée avec succès.',
    
    'Text version of the email' => 'Version texte de l\'email',

	'You are not authorised to access that location' => 'You are not authorised to access that location',

    //Roles
    'roles' => 'Rôles',
    'acces_utilisateurs_roles' => 'Accès Utilisateurs Rôles',
    'manage_roles' => 'Gérer les rôles',
    'add_role' => 'Nouveau rôle',
    'edit_role' => 'Modifier le rôle',
    'Role Name' => 'Nom du rôle',
    'new_role_add' => 'Nouveau rôle créé avec succès.',
    'role_update' => 'Rôle mis à jour avec succès.',
	'role_delete' => 'Rôle supprimé avec succès.',
	'Edit permissions' => 'Modifier les autorisations',

    //Admin users
    'last_name' => 'Nom',
    'user_type' => 'Rôle',
    'create_new_user' => 'Ajouter un nouvel utilisateur',

    //Ads
    'ads' => 'Ads',
	'manage_ads' => 'Annonces',
	'splashScreen' => 'Splashscreen',
	'banner' => 'Bannière',
    'list_ads' => 'Toutes les annonces',
    'add_ads' => 'Ajouter une annonce',
    'ads_type' => 'Type d\'annonce',
    'start_date' => 'Date de début',
    'end_date' => 'Date de fin',
    'ads_location' => 'Localisation',
    'radius' => 'Rayon',
	'Banner image' => 'Image de la bannière',
    'Image size should be 720x162' => 'La taille de l\'image doit être 720px x 162px',
    'Full Width Image (iphone x Max)' => 'Image pleine largeur (iphone x max)',
    'Image size should be 750x1624' => 'La taille de l\'image doit être de 750px x 1624px',
    'Full Width Image (iphone 8 size)' => 'Image pleine largeur (taille iphone 8)',
    'Image size should be 720x1280' => 'La taille de l\'image doit être de 720px x 1280px',
    'latitude' => 'Latitude',
    'longitude' => 'Longitude',
    'Radius (KM)' => 'Rayon (KM)',
    'url' => 'Url',
    'Add status now update' => 'Le statut de votre annonce a bien été mis à jour.',
    'The Add has been deleted' => 'Votre annonce a été supprimée avec succès.',
    'Your adsentity has been updated' => 'Votre annonce a été modifiée avec succès.',
    'Add has been successfully added' => 'Votre annonce a été ajoutée avec succès.',
	
	//
	'User image has been successfully deleted' => 'L\'image utilisateur a été supprimée avec succès.',

	'sent_on' => 'Envoyée le',
	
	'Content field is required' => 'Le champ de contenu est obligatoire.',
	'Email field is required' => 'Le champ e-mail est obligatoire.',
	'Email must be a valid email address' => 'L\'e-mail doit être une adresse e-mail valide.',
	'Subject field is required' => 'Le champ sujet est obligatoire.',
	'select_image' => 'Sélectionner une image',
	'restaturent' => 'Restaturent',
	'price' => 'Prix',
	'dishes' => 'Plats du jour',
	'manage_dishes' => 'Plats du jour',
	'add_dish' => 'Ajouter un plat',
	'edit_dish' => 'Modifier un plat',
	'manage_deals' => 'Bons plans',	
	'add_deal' => 'Ajouter un bon plan',
	'edit_deal' => 'Modifier un bon plan',
	'price_type' => 'Type de prix',
    'add_providerdeals' => 'Add Provider Deals',
	'providerdeals' => 'Provider Deals',
    'deals' => 'Deals',
    'provider_deal_deleted' => 'Ce bon plan a bien été supprimé.',
    'deal_deleted_successfully' => 'Deal Delete successfully.',
    'opportunity' => 'Opportunity',
    'edit_provider_deal' => 'Ce bon plan a bien été modifié.',
    'created_at' => 'Date de création',
   
    
    'apple_review_mode'=>'Apple review mode',
    'here_you_can_manage_apple_review_mode'=>'Vous pouvez activer ici le mode revision Apple.',
    'search_id'=>'Rechercher ID',
    'search_first_name'=>'Rechercher Prénom',
    'search_last_name'=>' Rechercher Nom',
    'search_email'=>'Rechercher Email',
    'search_username'=>'Rechercher Pseudo',
    'search_txts'=>'Rechercher ',
    'default_vote_limit_for_user'=>'Nombre de votes donnés initialement',
    'here_you_can_manage_the_default_vote_limit_for_user'=> "Vous pouvez modifier ici le nombre de votes données à l'utilisateur initialement.",
    'here_you_can_manage_the_vote_point_after_watch_video'=>'Vous pouvez modifier ici le nombre de votes donnés après visionnage de la publicité.',
    'manage_the_vote_point_after_watch_video'=>'Nb de votes donnés après visionnage de la publicité',

    'here_you_can_manage_the_vote_point_after_rate_app'=>"Vous pouvez modifier ici le nombre de votes donnés après évaluation de l'app.",
    'manage_the_vote_point_after_rate_app'=>"Nb de votes donnés après évaluation de l'app",

    'here_you_can_manage_the_vote_point_after_purchase_premium'=>'Vous pouvez modifier ici le nombre de votes donnés après un achat du Premium',
    'manage_the_vote_point_after_purchase_premium'=>'Nb de votes donnés après un achat du Premium',

    'here_you_can_manage_the_time_for_revote_in_hours'=>'Vous pouvez modifier ici le délai nécessaire pour retrouver le nombre de votes initial',
    'manage_the_time_for_revote'=>'Durée nécessaire pour la réinitialisation du nombre de votes',

    'here_you_can_manage_the_vote_point_after_share_the_app'=>'ici, vous pouvez gérer le point de vote après avoir partagé l\'application avec les gens',

    'manage_the_vote_point_after_share_the_app'=>'Gérez le point de vote après avoir partagé l\'application avec l\'utilisateur',
    
    'username'=>'Pseudo',
    'premium'=>'Premium',
    'rank'=>'Rang',
    'likes'=>'aime',
    'slider_type'=>'Type de curseur',
    'coefficient'=>'Coefficient',
    'position'=>'Position',
    'comments'=>'commentaires',
    'commented_by'=>'Commenté par',
    'commented_to'=>'Commenté à',
    'reports'=>'Rapports',
    'subtitle'=>'Sous-titre',
    'add_new_slider'=>'Ajouter de nouvelles diapositives Premium',
    'banner_image'=>'Image',
    'edit_comment'=>'Modifier le commentaire',
    'liked_by'=>'J\'aime',
    'response_user_comments'=>'Réponses aux commentaires des utilisateurs',
    'Auteure'=>'Auteur',
    'profile_comments_of'=>'Commentaires sur le profil de',
    'list_of_emoji'=>' Liste des emojis',
    'add_an_emoji'=>'AJOUTER UN EMOJI',
    'premium_slides'=>'Diapositives Premium',
    'manage_the_show_add_after_n_slides'=>'Nombre de votes entre chaque annonce',
    'here_you_can_manage_show_ads_after_n_number_of_users_slides'=>'Vous pouvez modifier ici le nombre de votes entre chaque annonce',
    'manage_the_vote_point_re_vote'=>'Nombre de changement de vote (par jour)',
    'here_you_can_manage_the_vote_point_re_vote'=>'Vous pouvez modifier ici le nombre de changement de vote par jour pour les utilisateurs Premium',
    'manage_the_super_snap_request_per_day' => 'Nombre de Super Demande de Snap (par jour)',
    'here_you_can_manage_super_snap_chat_request_count_per_day' => 'Vous pouvez modifier ici le nombre de Super Demande de Snap par jour pour les utilisateurs Premium',
    'manage_the_vote_point_after_share_app_with_people'=>'Nb de votes donnés après partage du lien',
    'here_you_can_manage_the_vote_point_after_share_app_to_peoples'=>'Vous pouvez modifier ici le nombre de votes donnés après partage du lien',
    'sms_text' => 'Message invitation SMS',
    'here_you_can_manage_sms_text' => 'Vous pouvez modifier ici le texte envoyé pour les invitations SMS.',
    'sms_invitation_vote' => 'Nb de votes donné après envoie des invitations SMS.',
    'here_you_can_manage_sms_invitation_vote' => 'Vous pouvez modifier ici le nombre de votes donné après envoie des invitations SMS.',
    
    'Actualites been successfully added' => 'L\'actualité a bien été ajoutée.',
    'Actualites been successfully deleted' => 'L\'actualité a bien été supprimée.',
    'Actualites been successfully updated' => 'L\'actualité a bien été mise à jour.',
    
    'Category been successfully deleted' => 'La catégorie a bien été supprimée.',
    'Category been successfully updated' => 'La catégorie a bien été mise à jour.',
    'Category been successfully added' => 'La catégorie a bien été ajoutée.',
    
    'Pdf been successfully deleted' => 'Le cours a bien été supprimé.',
    'Pdf been successfully updated' => 'Le cours a bien été mis à jour.',
    'Pdf been successfully added' => 'Le cours a bien été ajouté.',
    
    'FAQ Has  been successfully added' => 'La FAQ a bien été ajoutée.',
    'FAQ has  been successfully updated' => 'La FAQ a bien été mise à jour.',
    'FAQ has been successfully deleted' => 'La FAQ a bien été supprimée.',
   
    'edit new Premium slides' => 'Modifier une slide',
    'Edit new FAQs' => 'Modifier une FAQ',
    'boost_countdown' => 'Durée du Boost',
    'here_you_can_manage_boost_countdown' => 'Vous pouvez modifier ici la durée du Boost.',
    'per_day_boost_click' => 'Nb de boosts quotidiens',
    'indicate_here_the_number_of_daily_boosts_allowed_for_premium_users' => 'Indiquez ici le nombre de boosts quotidiens autorisés pour les utilisateurs Premium.',
    'manage_vote_point_after_share_app_people' => 'Nb de votes donnés après partage du lien',
    'manage_the_vote_point_re_vote'=>'Nombre de changement de vote (par jour)',
    'manage_the_vote_point_revote'=>'Nombre de changement de vote (par jour)',
    'number_of_sms_invitation_after_registration'=>"Nombre d'invitation SMS après inscription",
    'here_you_can_modify_the_number_of_invitation_sent_by_sms_24_hours_after_user_registration'=>"Vous pouvez modifier ici le nombre d'invitation envoyé par sms 24h après inscription de l'utilisateur.",
    'listfaqcategories'=>"Catégories FAQ",
	'view_faqlist'=>"VOIR LES QUESTIONS",
	'faqcategory_has_been_successfully_added' =>  "La catégorie a bien été crée.",    
    'faqcategory_has_been_updated' =>  "La catégorie a bien été mise à jour.",
	'the_faqcategory_has_been_deleted' =>  "La catégorie a bien été supprimée.",
    'user_delete_successfully'=>"L’utilisateur a bien été supprimé.",
    'comments'=>"Signalements",
	'select_mode_for_pem_file' => 'Mode de gestion des notifications',
    'here_you_can_chnage_mode_for_pem_file' => 'Vous pouvez choisi ici si les notifications seront envoyées en mode production ou développement.',
    'sms_text_en' => 'Message invitation SMS (EN)',
    'here_you_can_manage_sms_text_en' => 'Vous pouvez modifier ici le texte envoyé pour les invitations SMS (EN).',
	'edit_invitation_sms' => 'Modifier Invitation Sms',
	'invitation_sms' => 'Invitation Sms',
	'Invitation has  been successfully updated' => 'Le message d’invitation a bien été modifié.',
	'invitation_sms_message' => "Message d'invitation",
    'country_code' => 'Code pays',
    'select_country_code' => 'Choisissez un code pays',
	'center_status' => 'Principal',


    'user_lists'=>'Liste des utilisateurs',
    'add_actualites'=>'Ajouter une actualité',
    'edit_actualites'=>'Modifier une actualité',
    'actualites_list'=>'Liste des actualités',
    'banner_image_importer'=>' Image',
    'add_pdf'=>'Ajouter un cours',
    'pdf_list'=>'Tous les cours',
    'edit_pdf'=>'Modifier le cours',
    'select_content_type'=>'Type de contenu',
    'expired_at'=>'Date d\'expiration',
    'content_type'=>'Type de contenu',

    'add_questions'=>'Ajouter une question',
    'questions'=>'Questions QCM',
    'edit_question'=>'Modifier la question',
    'question_title'=>'Question',

    'subcategory'=>'sous-catégorie',
    'level'=>'Niveau',
    'first_option'=>'Réponse A',
    'second_option'=>'Réponse B',
    'third_option'=>'Réponse C',
    'fourth_option'=>'Réponse D',
    'correct_option'=>'Bonne réponse',

    'add_badges'=>'Ajouter un Badge',
    'badges'=>'Badges',
    'edit_badges'=>'Modifier le Badge',

    'Question been successfully deleted' => 'La question a été supprimée.',
    'Question been successfully updated' => 'La question a été mise à jour.',
    'Question been successfully added' => 'La question a bien été ajoutée.',
    
    'Preparation been successfully deleted' => 'La page a bien été supprimée.',
    'Preparation been successfully updated' => 'La page a bien été mise à jour.',
    'Preparation been successfully added' => 'La page a bien été ajoutée.',
    

    'Badges been successfully deleted' => 'Le badge a bien été supprimé.',
    'Badges been successfully updated' => 'Le badge a bien été mis à jour.',
    'Badges been successfully added' => 'Le badge a bien été ajouté.',
    
    'choose_option'=>'choisis un d\'entre eux',

    'see_question_details'=>'Voir les questions',
    'see_course_details'=>'Voir tous les cours',

    'total_questions'=>'Nombre de questions',
    'total_course'=>'Nombre de cours',
    
    'Images de profil'=>'Images de profil',
    
    
    'add_new_category'=>'Nouvelle catégorie',
    'department'=>'Département',

    'category_title'=>'Titre de la catégorie',
    'training_subtitle'=>'Sous-titre entraînement',
    'number_of_questions'=>'Nombre de questions par session',

    'user_types'=>'Type d\'utilisateur',
    'explications'=>'Explications',
    'badge_title'=>'Titre du badge',
    'add_new_pdf'=>'ajouter un nouveau cours',
    'preparation_page_name'=>'Nom',
    'preparation_page'=>'Pages d\'aide',
    'add_new_preparation'=>'Ajouter une page',
    'edit_preparation'=>'Modifier la page',
    'choose_level'=>'Choisissez le niveau',
    'view_subcategories'=>'Voir les sous-catégories',
    'button_as_template'=>'button as template',

    'add_subcategory'=>'Ajouter une sous-catégorie ',
    'edit_subcategory'=>'Modifier la sous-catégorie',
    'subcategory_title'=>'Titre de la sous-catégorie',
    'import_pdf'=>'Importer un PDF',
    'cours_rapides'=>'Cours rapides',
    'here_you_can_manage_cours_rapides'=>'here you can manage cours rapides',
    'incontournables'=>'Incontournables',
    'here_you_can_manage_incontournables'=>'here you can manage Incontournables',

    'pdf_validation_msg'=>'Vous devez ajouter votre cours en version PDF uniquement.',
    'image_validation_msg'=>'Merci de bien vouloir ajouter une image au format JPG, JPEG ou PNG.',
    'file_size_validation'=>'Le fichier est trop volumineux, veuillez sélectionner un fichier de moins de 2 Mo',


    'video_validation_msg'=>'Merci de bien vouloir ajouter une video au format mp4 ou webm.',
    'video_size_validation'=>'Le fichier est trop volumineux, veuillez sélectionner un fichier de moins de 50 Mo',
    'import_video'=>'Importer une vidéo',
    'import_thumbnail'=>'Importer une thumbnail',
    'easy_level'=>'Débutant',
    'medium_level'=>'Avancé',
    'expert_level'=>'Expert',
];
