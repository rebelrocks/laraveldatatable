<?php

return [

    //
    'dob' => 'Dob',
    'man' => 'Man',
    'name' => 'Name',
    'email' => 'Email',
    'users' => 'Users',
    'login' => 'Login',
    'women' => 'Women',
    'genre' => 'Genre',
    'action' => 'Action',
    'status' => 'Status',
    'gender' => 'Gender',
    'logout' => 'Logout',
    'profile' => 'Profile',
    'position' => 'Position',
    'training' => 'Training',
    'about_me' => 'About me',
    'telephone' => 'Telephone',
    'addusers' => 'Add User',
    'language' => 'Language',
    'password' => 'Password',
    'settings' => 'Settings',
    'my_search' => 'MY SEARCH',
    'dashboard' => 'Dashboard',
    'new_users' => 'Users',
    "providers" => "Provider",
    'first_name' => 'First Name',
    'date_of_birth' => 'Your date of birth',
    "restaturents" => "Restaurants",
    "social_links" => "Social Links",
    'edit_profile' => 'Edit Profile',
    'old_password' => 'Old Password',
    'new_password' => 'New Password',
    'change_status' => 'Are you sure you want to change status?',
    'notifications' => 'Notifications',
    'cms_management' => 'Cms management',
    'data_not_found' => 'Data not found.',
    'page_not_found' => 'Page not found.',
    'user_detail_not' => 'User detail not found.',
    'forgot_password' => 'Forgot Password',
    "email_templates" => "Email Templates",
    'reset_password' => 'Reset Password',
    'reset_my_password' => 'Reset my password',
    'Back to the login' => 'Back to the login',
    'user_status_update' => 'User status updated successfully.',
    'list_of_last_registered_users' => 'New Register User From App',


    'change_password' => 'Change Password',
    'confirm_password' => 'Confirm Password',
    'profile_image' => 'Profile Image',
    'add_new_user' => 'Add New User',
    'edit_user' => 'Edit User',
    'back' => 'Back',
    'valider' => 'Valider',
    'update' => 'Update',
    'view_users' => 'View Users',
    'categories' => 'Categories',
    'new_register_users_from_app' => 'New Register Users From App',
    'title' => 'Title',
    'created' => 'Created',
    'modified' => 'Modified',
    'view_notification' => 'View Notification',
    'number_of_person' => 'Number of Person',

    'please_enter_your_email_address' => 'Please Enter Your Email Address',
    
    'email_already_exists' => 'Email Already Exists',

    'these_files_extension_are_allowed' => 'These Files Extension Are Allowed',    

    'invalid_username_or_password' => 'Invalid username or password, try again',
    
    'not_allowed_to_sign_in' => 'You are not allowed to sign in, try again',
    
    'profile_updated' => 'You profile has been updated',
    
    'unable_update_profile' => 'Unable to update your profile',
    
    'reset_sent_email_password' => 'Reset password sent in your email address',
    
    'email_no_exists' => 'Provide email address not exists',
    
    'reset_password_link_not_valid' => 'Reset password link not valid',
    
    'the_password_is_successfully_changed' => 'The password is successfully changed',
    
    'user_has_been_successfully_added' => 'User has been successfully added',
    
    'user_has_been_updated' => 'User has been updated',
    
    'user_successfully_deleted' => 'User successfully deleted',
    
    'unable_to_delete_user' => 'Unable to delete user',
    
    'user_account_status_now_update' =>  "User account status now update",
    
    'category_has_been_successfully_added' =>  "Category has been successfully added",
    
    'category_has_been_updated' =>  "Your category has been updated",
    
    'unable_to_update_your_category' =>  "Unable to update your category",
    
    'order_changed_successfully' =>  "Order Changed successfully",
    
    'the_category_has_been_deleted' =>  "The Category has been deleted",
    
    'unable_to_delete_category' =>  "Unable to delete category",
    
    'category_status_now_update' =>  "Category status now update",
    
    'your_page_has_been_updated' =>  "Your page has been updated",
    
    'unable_to_update_your_page' =>  "Unable to update your page",
    
    'page_successfully_deleted' =>  "Page successfully deleted",
    
    'unable_to_delete_page' =>  "Unable to delete page",
    
    'page_status_now_update' =>  "Page status now update",
    
    'your_setting_has_been_updated' =>  "Your setting has been updated",
    
    'statusactive' =>  "Active",

    'statusinactive' =>  "Inactive",
	
    'active' =>  "Active",
    
    'inactive' =>  "Deactivate",
	
	'all_active' =>  "All active",
    
    'all_inactive' =>  "All deactivate",
	
	'all_status' =>  "All",
    
    'listcategories' =>  "List Categories",
    
    'addcategory' =>  "Add category",
    
    'editcategory' =>  "Edit Category",
    'editcategory' =>  "Choose a category",
    
    'back' =>  "Back",
    
    'are_you_sure_want_to_delete' =>  "Are you sure want to Delete ?",
    
    'delete' =>  "Delete",
    
    'edit' =>  "Edit",
    
    'up' =>  "Up",
    
    'down' =>  "Down",
    
    'category' =>  "Category",    

    'location' =>  "Location",
    
    'description' =>  "Description",
    
    'postcode' =>  "Post Code",
    
    'full_address' =>  "Full Address",
    
    'add_more_ticket_type' =>  "Add More Ticket Type",
    
    'select_category' =>  "Select Category",
    
    'something_error_please_try_again' =>  "Something error please try again",
    
    'cms_page_listing' =>  "CMS Page Listing",
    
    'content' =>  "Content",
    
    'edit_page' =>  "Edit Page",
    
    'list_notifications' =>  "List Notifications",
    
    'add_notification' =>  "Add Notification",

    'Notification receive users' => 'Recipients',
    
    'send_to' =>  "Send To",
    
    'message' =>  "Message",
    
    'link' =>  "Link",
    
    'address' =>  "Address",
    
    'total_users' =>  "Total Users",
    
    'select_user_type' =>  "Select User Type",
    
    'find_user' =>  "Find User",
    
    'select_user' =>  "Seect User",
    
    'send_notification' =>  "Send Notification",
    
    'user_not_found' =>  "User not found",
    
    'all_app_users' =>  "All app users",
    
    'send_to_selected_user' =>  "Send To Selected User",
    
    'add_new_notification' =>  "Add New Notification",
    
    'view_notification' =>  "View Notification",
    
    'posted' =>  "posted",
    
    'facebook_url' =>  "Facebook Url",    

    'snapchat_url' =>  "Snapchat Url",    

    'here_you_can_add_your_snapchat_url' =>  "Here You Can Add Your Snapchat Url",    


    'site_name' =>  "Site Name",    

    'you_can_make_changes_in_site_name_by_using_this_value' =>  "You can make changes in site name by using this value",
    
    'site_url' =>  "Site Url",
    
    'here_you_can_manage_your_website_url' =>  "Here you can manage your website url",
    
    'admin_email' =>  "Admin Email",
    
    'you_can_make_changes_in_admin_email_address_by_using_this_value' =>  "You can make changes in admin email address by using this value",

    'contact_us_email' =>  "Contact Us Email",

    'you_can_make_changes_in_admin_contact_us_email_address_by_using_this_value' =>  "You Can Make Changes In Admin Contact Us Email Address By Using This Value",

    'support_email' =>  "Support Email",

    'here_you_can_manage_your_support_email' =>  "Here You Can Manage Your Support Email",

    //10-12-19
    "from_email" => "From Email",
    
    "here_you_can_manage_your_from_email" => "Here you can manage your from email",
    
    "report_a_bug_email" => "Report a bug email",
    
    "here_you_can_manage_the_report_email" => "Here Yyou Can manage the report email",
    
    "contact_us_email" => "Contact us email",
    
    "here_you_can_manage_the_contact_us_email" => "Here you can manage the contact us email",
    
    "force_users_to_update_android_app" => "Force users to update the Android app",
    
    "here_you_can_force_users_to_update_android_app" => "Here You Can Force Users To Update Android app",
    
    "android_app_version" => "android_app_version",
    
    "here_you_can_manage_the_latest_android_app_version" => "Here you can manage the latest android app version",
    
    "force_users_to_update_ios_app" => "Force users to update the iOS app",
    
    "here_you_can_force_users_to_update_ios_app" => "You can force users to update ios app",
    
    "latest_ios_app_version" => "Latest version of the iOS app",
    
    "here_you_can_manage_the_latest_ios_app_version" => "You can manage the latest version of the ios app",
    
    "notify_users_of_a_new_update" => "Notify users of a new update.",
    
    "here_you_can_notify_users_of_a_new_update" => "Here you can notify users of a new update.",
    
    "please_select_category" => "Please select category",
    
    "something_worng" => "Something worng, try again",
    
    "notification_added" => "Notification has been successfully added",
    
    "notification_updated" => "Your notification has been updated",
    
    "notification_deleted" => "The Notification has been deleted",
    
    "unable_notification_deleted" => "Unable to delete notification",
    
    "general_settings" => "General Settings",
    
    "edit_email_template" => "Edit Email Template",
    
    "subject" => "Subject",
    
    "sender_name" => "Sender Name",
    
    "support_email" => "Support Email",
    
    "contact_email" => "Contact Email",
    
    "main_color" => "Main Color",
    
    "secondary_color" => "Secondary Color",
    
    "header_image" => "Header Image",
    
    "white_logo" => "White Logo",
    
    "email_templates_updated" => "Your email templates has been updated",
    
    "unable_update_email_template" => "Unable to update your email template",
    
    "edit_image" => "Edit image",
    
    //Socail links
    "web_url" => "Web Url",    

    "facebook_link" => "Facebook Link",    

    "instagram_link" => "Instagram Link",    

    "twitter_link" => "Twitter Link",    

    "linkedin" => "Linkedin",  

    "snapchat" => "Snapchat Link",    

    "social_links_updated" => "Social links has been updated",    
    //End socail links language

    "please_enter_message" => "Please Enter Message",
    "please_enter_message" => "S'il vous plaît entrer un message",


    "registration_date" => "Registration date",
    

    "admin_profile_update" => "You profile has been updated",
    "admin_profile_update" => "Votre profil a été mis a jour.",

    //CMS page status
    "page_status" => "Page status now update",
    
    //Notification Create
    "save_notification" => "Notification has been successfully added",
     
    //General setting form validation message
    'This field is required' => 'This field is required.',  
    
    //language code
    'code' => 'Code',
    'add_language' => 'Add Language',
    'edit_language' => 'Edit Language',
    'create_new_language' => 'New language code added successfully.',
    'update_language' => 'Language code updated successfully.',
    'delete_language' => 'Language code deleted successfully.',
    'The selected language code does not exist' => 'The selected language code does not exist.',
	'update_language_status' => 'La langue par défaut a été définie avec succès.',
	'set_detault_language' => 'PRINCIPALE',

    //Email templates
    'add_new_template' => 'Add Template',

    //Error message
    'oops' => 'Oops. something went wrong. please try again.',

    //save new record
    'save' => 'Save',

    //Managers
    'manager' => 'Manager',
    'managers' => 'Managers',
    'add_manager' => 'Add Manager',
    'edit_manager' => 'Edit Manager',
    'New Manager Created Successfully' => 'New manager created successfully.',
    'Manager Updated Successfully' => 'Manager Updated Successfully.',
	'manager_deleted_successfully' => 'Manager deleted successfully.',
	
    //site_permissions
    'site_permissions' => 'Site Permissions',
    'add_site_permission' => 'Add Site Permission',
    'edit_site_permission' => 'Edit Site Permission',
    'role' => 'Role',
    'permission_for' => 'Authorization',
    'is_read' => 'Is Read',
    'is_add' => 'Is Add',
    'is_edit' => 'Is Edit',
    'is_delete' => 'Is Delete',
    'yes' => 'Yes',
    'no' => 'No',
    'selectrole' => 'Select Role',
    'selectmanager' => 'Select Manager',
    'view_data' => 'View', 
    'add_data' => 'Add', 
    'edit_data' => 'Edit', 
    'delete_data' => 'Delete',
	'site_permission_already_exits' => 'Site permission already exits. with this role & manager',
	'new_site_permission_created_successfully' => 'New site permission created successfully.',
	'site_permission_updated_successfully' => 'Site permission updated successfully.',
	'site_permissions_deleted_successfully' => 'Site permissions deleted successfully.',
    
    //General setting
    'contact_email_address' => 'Contact email address',
    'add_the_main_contact_email_for_the_app' => 'Add the main contact email for the app.',
    'support_email_address' => 'Support email address',
    'add_the_application_customer_support_email' => 'Add the application customer support email.',
    'email_address_of_reports' => 'Email address of reports',
    'add_the_email_recipient_of_the_application_reports' => 'Add the email recipient of the application reports.',
    'sending_email_address' => 'Sending email address',
    'add_the_email_sender_of_the_emails_to_the_application' => 'Add the email sender of the emails to the application.',
	'login_background_image' => 'Background picture',
	'add_the_login_background_cover_image' => 'Change the background image of the login page here.',
	'site_logo' => 'Logo',
	'add_the_site_logo' => 'Change the logo of the application back office here.',

    //Email templates
    'selectimage' => 'Select image',
    'remove' => 'Remove',
    'No' => 'No',
    'image' => 'image',
    
    //datatable pagination
    'Pre' => 'Pre',
    'Next' => 'Next',
    'No data available' => 'No data available',
    'Processing' => 'Processing',
    'No matching records found' => 'No matching records found',
    'Search' => 'Search',

    //words list
    'word_list' => 'Word list',
    'listwords' => 'List Words',
    'addword' => 'Add Word',
    'Key Name' => 'Key Name',
    'Key Value' => 'Key Value',
    'Language Code' => 'Language Code',
    'Edit Word' => 'Edit Word',
    'word_list_status_updated_successfully' => 'Word list status updated successfully.',
    'word_list_deleted' => 'Word list deleted successfully.',
    'word_detail_update' => 'Word detail updated successfully.',
    'new_word_detail_add' => 'New word created successfully.',

    //Newsletters
    'newsletters' => 'Newsletters',
    'newsletter' => 'Newsletter',
    'create_new_newsletter' => 'Envoyer une newsletter',
    'username' => 'User Name',
    'profileimage' => 'Profile Image',
    'numberofusernotsend' => 'Number of user not send',
    'numberofusersent' => 'Number of user sent',
    'send_newsletter' => 'Send Newsletter',
    'user_list' => 'User List',
    'statuts' => 'Statuts',
    'news_created_at' => 'Created',
    'news_subject' => 'Subject',
	'newsletter_send_successfully' => 'Newsletter send successfully.',
	'email_sent_successfully' => 'Email sent successfully.',
	'send_test_email' => 'Envoyer un test',
	
	//Send Test Email
	'Test email sended successfully' => 'Test email sended successfully.',
	
	//Notificationtext
	'Notificationtext' => 'Notifications',
	'add_notification_text' => 'Add Notification Text',
	'notificationtext_created_successfully' => 'Notification text created successfully.',
	'notificationtext_updated_successfully' => 'Notificationtext updated successfully.',
	'notificationtext_deleted_successfully' => 'Notificationtext deleted successfully.',
	'manage_notification_text' => 'Manage notification text',
	'notification_text_added' => 'Créée le',
	
	//Status
	'status_updated_successfully' => 'Status updated successfully.',
    //
	'user_has_been_successfully_deleted' => 'User has been successfully deleted.',
	'user_image_has_been_successfully_deleted' => 'User image has been successfully deleted.',
		
	'notification_sent_successfully' => 'Notification sent successfully.',
	
    'Text version of the email' => 'Text version of the email',

    'You are not authorised to access that location' => 'You are not authorised to access that location',

    //Roles
    'roles' => 'Roles',
	'acces_utilisateurs_roles' => 'Accès Utilisateurs Rôles',
    'manage_roles' => 'Manage Roles',
    'add_role' => 'New Role',
    'edit_role' => 'Edit Role',
    'Role Name' => 'Role Name',
    'new_role_add' => 'New role created successfully.',
    'role_update' => 'Role updated successfully.',
    'role_delete' => 'Role deleted successfully.',
	'Edit permissions' => 'Edit permissions',
	

    //Admin users
    'last_name' => 'Last Name',
    'user_type' => 'Role',
    'create_new_user' => 'Add New User',

    //Ads
    'ads' => 'Ads',
	'add_ads' => 'Add Ads',
	'splashscreen' => 'Splashscreen',
	'banner' => 'Banner',
	'manage_ads' => 'Ads',
    'list_ads' => 'List Ads',
    'add_ads' => 'Add Ads',
    'ads_type' => 'Ads Type',
    'start_date' => 'Start Date',
    'end_date' => 'End Date',
    'ads_location' => 'Location',
    'radius' => 'Radius',
    'Full Width Image (iphone x Max)' => 'Full Width Image (iphone x Max)',
    'Image size should be 750x1624' => 'Image size should be 750x1624',
    'Full Width Image (iphone 8 size)' => 'Full Width Image (iphone 8 size)',
    'Image size should be 720x1280' => 'Image size should be 720x1280',
    'latitude' => 'Latitude',
    'longitude' => 'Longitude',
    'Radius (KM)' => 'Radius (KM)',
    'url' => 'Url',
    'Add status now update' => 'Add status now update.',
    'The Add has been deleted' => 'The Add has been deleted.',
    'Your adsentity has been updated' => 'Your adsentity has been updated.',
    'Add has been successfully added' => 'Add has been successfully added.',

    //
	'User image has been successfully deleted' => 'User image has been successfully deleted.',
	
	'sent_on' => 'Sent on',
	
	'Content field is required' => 'Content field is required.',
	'Email field is required' => 'Email field is required.',
	'Email must be a valid email address' => 'Email must be a valid email address.',
	'Subject field is required' => 'Subject field is required.',
	
	'apple_review_mode'=>'Apple review mode',
    'here_you_can_manage_apple_review_mode'=>'You can activate the Apple review mode here.',
    'search_id'=>'Search ID',
    'search_first_name'=>'Search First Name',
    'search_last_name'=>'Search Last Name',
    'search_email'=>'Search Email',
    'search_username'=>'Search Username',
    'search_txts'=>'Search ',
    'default_vote_limit_for_user'=>'Number of votes initially given',
    'here_you_can_manage_the_default_vote_limit_for_user'=>'Here you can modify the number of votes given to the user initially.',

    'here_you_can_manage_the_vote_point_after_watch_video'=>'Here you can modify the number of votes given after viewing the advertisement.',
    'manage_the_vote_point_after_watch_video'=>'Number of votes given after sending viewing of the advertisement',

    'here_you_can_manage_the_vote_point_after_rate_app'=>'Here you can modify the number of votes given after evaluating the app.',
    'manage_the_vote_point_after_rate_app'=>'Number of votes given after app evaluation',
    
    'here_you_can_manage_the_vote_point_after_purchase_premium'=>'Here you can modify the number of votes given after purchasing the Premium',
    'manage_the_vote_point_after_purchase_premium'=>'Number of votes given after purchasing the Premium',

    'here_you_can_manage_the_time_for_revote_in_hours'=>'Here you can modify the time required to find the initial number of votes',
    'manage_the_time_for_revote'=>'Time needed to reset the number of votes',

    'here_you_can_manage_the_vote_point_after_share_app_to_peoples'=>'here you can manage the vote point after share app to peoples',

    'manage_the_vote_point_after_share_the_app'=>'Manage the vote point after share the app with user',

    'username'=>'Username',
    'premium'=>'Premium',
    'rank'=>'Rank',
    'likes'=>'Likes',
    'slider_type'=>'Slider Type',
    'coefficient'=>'Coefficient',
    'position'=>'Position',
    'comments'=>'Comments',
    'commented_by'=>'Commented By',
    'commented_to'=>'Commented To',
    'reports'=>'Reports',
    'subtitle'=>'Sub-Title',
    'add_new_slider'=>'Add New Premium Slider',
    'banner_image'=>'Image',
    'edit_comment'=>'Edit Comment',
    'liked_by'=>'Liked By',
    'response_user_comments'=>'Responses to user\'s comment',
    'Auteure'=>'Author',
    'profile_comments_of'=>'Profile comments of ',
    'list_of_emoji'=>'List of emojis',
    'add_an_emoji'=>'ADD AN EMOJI',
    'premium_slides'=>'Premium Sliders',
    'manage_the_show_add_after_n_slides'=>'Number of votes between each ad',
    'here_you_can_manage_show_ads_after_n_number_of_users_slides'=>'You can modify here the number of votes between each advertisement',
    'here_you_can_manage_the_vote_point_after_share_the_app'=>'Here you can manage the vote point after share the app',
    
	'is_premium'=>'Activate a Premium offer',
	'login_header_text'=>'Login',
	'subscription_end_date'=>'Offer end date',
	'default_time_for_revote'=>'Default time for re-vote',
	'here_you_can_manage_the_vote_point_re_vote'=>'Here you can change the number of voting changes per day for Premium users',
	'manage_the_vote_point_after_share_app_with_people'=>'Number of votes given after sharing the link',
	'manage_the_vote_point_re_vote'=>'Number of voting changes (per day)',
    'manage_the_vote_point_revote'=>'Number of voting changes (per day)',
	'facebook_page_id'=>'Page ID Facebook',
	'facebook_app_id'=>'Messenger ID',
    'manage_the_super_snap_request_per_day' => 'Number of Super Snap Requests (per day)',
    'here_you_can_manage_super_snap_chat_request_count_per_day' => 'Here you can change the number of Super Snap Requests per day for Premium users',
    'sms_text' => 'SMS invitation message',
    'here_you_can_manage_sms_text' => 'Here you can change the text sent for SMS invitations.',
    'sms_invitation_vote' => 'Number of votes given after sending SMS invitations.',
    'here_you_can_manage_sms_invitation_vote' => 'Here you can modify the number of votes given after sending SMS invitations.',
    
    'Actualites been successfully added' => 'The actualites has been added.',
    'Actualites been successfully deleted' => 'The actualites has been deleted.',
    'Actualites been successfully updated' => 'The actualites has been updated successfully.',
    
    'Category been successfully deleted' => 'The Category has been deleted.',
    'Category been successfully updated' => 'The Category has been updated.',
    'Category been successfully added' => 'The Category has been added.',
    
    'Pdf been successfully deleted' => 'The Pdf has been deleted.',
    'Pdf been successfully updated' => 'The Pdf has been updated.',
    'Pdf been successfully added' => 'The Pdf has been added.',
    
    'FAQ Has  been successfully added' => 'The question has been added.',
    'FAQ has  been successfully updated' => 'The question has been updated.',
    'FAQ has been successfully deleted' => 'The question has been deleted.',
    
    'edit new Premium slides' => 'edit new Premium slides',
    'Edit new FAQs' => 'Edit new FAQs',
    'boost_countdown' => 'Duration of the Boost',
    'here_you_can_manage_boost_countdown' => 'You can change the duration of the Boost here.',
    'per_day_boost_click' => 'Number of daily boosts',
    'indicate_here_the_number_of_daily_boosts_allowed_for_premium_users' => 'Indicate here the number of daily boosts allowed for Premium users.',
    'manage_vote_point_after_share_app_people' => 'Number of votes given after sharing the link',
    'number_of_sms_invitation_after_registration'=>"Number of SMS invitation after registration",
    'here_you_can_modify_the_number_of_invitation_sent_by_sms_24_hours_after_user_registration'=>"Here you can modify the number of invitation sent by sms 24 hours after user registration.",
	'listfaqcategories'=>"FAQ's Categories",
	'view_faqlist'=>"SEE THE QUESTIONS",
    'user_delete_successfully'=>"The user has been successfully deleted.",
    'comments'=>"Signalements",
	'select_mode_for_pem_file' => 'Notification management mode',
    'here_you_can_chnage_mode_for_pem_file' => 'Here you can choose whether the notifications will be sent in production or development mode.',
    'sms_text_en' => 'SMS invitation message (EN)',
    'here_you_can_manage_sms_text_en' => 'Here you can change the text sent for SMS invitations (EN).',
    'edit_invitation_sms' => 'Edit Invitation Sms',
    'invitation_sms' => 'Invitation Sms',
    'Invitation has  been successfully updated' => 'Invitation has  been successfully updated',
    'invitation_sms_message' => 'Invitation message',
    'country_code' => 'Country code',
    'select_country_code' => 'Choose a country code',
	

    'user_lists'=>'Users List',
    'add_actualites'=>'Add New Actualite',
    'edit_actualites'=>'Edit actualite',
    'actualites_list'=>'Actualites',
    'banner_image_importer'=>' Image',
    'add_pdf'=>'Add course',
    'pdf_list'=>'Courses list',
    'edit_pdf'=>'Modify course',
    'select_content_type'=>'Content Type',
    'expired_at'=>'Expired at',
    'content_type'=>'Content Type',

    'add_questions'=>'Add New Question',
    'questions'=>'Questions QCM',
    'edit_question'=>'Edit Question',
    'question_title'=>'Question ',

    'Question been successfully deleted' => 'The Question has been deleted.',
    'Question been successfully updated' => 'The Question has been updated.',
    'Question been successfully added' => 'The Question has been added.',
    
    'Preparation been successfully deleted' => 'The Preparation has been deleted.',
    'Preparation been successfully updated' => 'The Preparation has been updated.',
    'Preparation been successfully added' => 'The Preparation has been added.',
    
    'Badges been successfully deleted' => 'The Badges has been deleted.',
    'Badges been successfully updated' => 'The Badges has been updated.',
    'Badges been successfully deleted' => 'The Badges has been deleted.',
    
    'choose_option'=>'Select one of them',

    'see_course_details'=>'View all courses',
    'see_question_details'=>'View all questions',


    'total_questions'=>'Total Questions',
    'total_course'=>'Total Courses',
    'choose_category' =>  "Choose a category",

    'Images de profil'=>'Profile Image',
    
    'add_new_category'=>'Add a new category',

    'department'=>'Department',

    'category_title'=>'Title of categorie',
    'training_subtitle'=>'Training sub-title',
    'number_of_questions'=>'Number of question for training of this category',
    
    'user_types'=>'User Type',
    'explications'=>'Explanations',
    'badge_title'=>'Badge Title',
    'subcategory'=>'Sub-Category',
    'add_new_pdf'=>'Add a new course',
    'preparation_page_name'=>'Name of page',
    'preparation_page'=>'Pages Prepare for the exam',
    'add_new_preparation'=>'Add a new page',
    'edit_preparation'=>'modify a page',
    'choose_level'=>'Choose level',
    'view_subcategories'=>'See the subcategories',

    'add_subcategory'=>'Add sub-category ',
    'edit_subcategory'=>'Modify sub-categpry',
    'subcategory_title'=>'sub-category title',
    'import_pdf'=>'Import PDF',
    'cours_rapides'=>'Cours rapides',
    'here_you_can_manage_cours_rapides'=>'here you can manage cours rapides',
    'incontournables'=>'Incontournables',
    'here_you_can_manage_incontournables'=>'here you can manage Incontournables',

    'pdf_validation_msg'=>'Only pdf format is allowed.',
    'image_validation_msg'=>'Only jpg png and jpeg format are allowed.',
    'file_size_validation'=>'The file is too big, please select a file less than 2MB',


    'video_validation_msg'=>'Only mp4 and webm format are allowed.',
    'video_size_validation'=>'The file is too big, please select a file less than 50MB',
    'import_video'=>'Upload video',
    'import_thumbnail'=>'Upload thumbnail',
    'easy_level'=>'Easy',
    'medium_level'=>'Medium',
    'expert_level'=>'Expert',
    'prepair_for_exam'=>'Prepare for the exam',
    'after_the_exam'=>'After the exam',
];
